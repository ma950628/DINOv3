# 训练启动命令

## 单卡
python train.py

## 多卡（按需选择）
# 4 卡
CUDA_VISIBLE_DEVICES=0,1,2,3 torchrun --nproc_per_node=4 train.py

# 8 卡
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 torchrun --nproc_per_node=8 train.py

# 只用 4-7 号卡（跳过 0-3）
CUDA_VISIBLE_DEVICES=4,5,6,7 torchrun --nproc_per_node=4 train.py

## 断点续跑
python train.py --resume ./outputs/2026-06-15_10-30-00

## 临时覆盖某个参数（不改 CONFIG）
python train.py --data-root /another/path --epochs 50

## 有效 batch size
# 4 卡 × batch_size=2 → 有效 batch=8
# 8 卡 × batch_size=2 → 有效 batch=16
