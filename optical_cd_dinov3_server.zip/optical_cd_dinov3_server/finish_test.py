"""加载 best_model 跑 test + 出图（训练已完成，跳过重训）
用法：python finish_test.py [output_dir] [--data-root PATH] [--dataset levir|sysu] [--arch vit_large|dinov3_vitl] [--img-size N]
"""
import sys, os, argparse
import torch

# 自动定位项目根目录
project_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_dir)

from models.dinov3_optical_cd import build_optical_cd_model
from train import create_optical_loader, val_epoch

parser = argparse.ArgumentParser()
parser.add_argument('output_dir', nargs='?', default=None)
parser.add_argument('--data-root', default='E:/datasets/SYSU-CD')
parser.add_argument('--dataset', default='sysu', choices=['levir', 'sysu'])
parser.add_argument('--arch', default='dinov3_vitl', choices=['vit_base', 'vit_large', 'dinov3_vitl'])
parser.add_argument('--img-size', type=int, default=448)
parser.add_argument('--batch-size', type=int, default=2)
parser.add_argument('--num-classes', type=int, default=2)
args = parser.parse_args()

data_root = args.data_root
img_size = args.img_size
batch_size = args.batch_size
num_classes = args.num_classes

# 自动找最新的 output 目录
outputs_root = os.path.join(project_dir, 'outputs')
if args.output_dir:
    output_dir = args.output_dir
else:
    dirs = sorted([d for d in os.listdir(outputs_root)
                   if os.path.isdir(os.path.join(outputs_root, d))], reverse=True)
    output_dir = os.path.join(outputs_root, dirs[0]) if dirs else os.path.join(outputs_root, 'latest')
    print(f"Using latest output: {output_dir}")

model_path = os.path.join(output_dir, 'best_model.pth')
model = build_optical_cd_model(num_classes=num_classes, img_size=img_size, arch=args.arch)
model.load_state_dict(torch.load(model_path, weights_only=True))
model.cuda()
print(f"Best model loaded from {model_path}")

# Test
test_loader = create_optical_loader(data_root, 'test', batch_size, args.dataset,
                                     img_size=img_size, is_train=False)
result = val_epoch(model, test_loader, 'cuda', num_classes)
print(f"Test F1={result['f1']:.4f} | IoU={result['iou']:.4f} | P={result['precision']:.4f} | R={result['recall']:.4f}")

# 曲线
from tools.plot_curves import plot_from_metrics
figures_dir = os.path.join(output_dir, 'figures')
os.makedirs(figures_dir, exist_ok=True)
log_dir = os.path.join(project_dir, 'logs', os.path.basename(output_dir))
if os.path.isdir(log_dir):
    metrics_path = os.path.join(log_dir, 'metrics.txt')
else:
    metrics_path = os.path.join(project_dir, 'logs', 'metrics.txt')
plot_from_metrics(metrics_path, figures_dir)
print(f"Curves saved to {figures_dir}")

# 预测图
from tools.plot_results import visualize_predictions
visualize_predictions(model, data_root, figures_dir, device='cuda',
                      num_samples=8, img_size=img_size)
print(f"Predictions saved to {figures_dir}")
