"""
纯光学变化检测模型 v2：HR ViT + 真·多尺度特征金字塔 + UperNet

数据流：
  前时相 RGB → HR ViT(冻结) → feat [B,768,H/14,W/14]
  后时相 RGB → HR ViT(冻结) → feat [B,768,H/14,W/14]
                                   ↓ abs diff
                              [B,768,H/14,W/14]
                                   ↓
                         ViTFeaturePyramid (可训练)
                                   ↓
                p0 [B,128,4H/14,4W/14]   ← shallowest
                p1 [B,128,2H/14,2W/14]
                p2 [B,256, H/14, W/14]
                p3 [B,512, H/28,W/28]    ← deepest
                                   ↓
                              UperNet
                                   ↓
                         变化图 [B,2,H,W]

v2 改进：
- 不再用 HR ViT 中间层（全是同分辨率），改用真正的多尺度金字塔
- 特征金字塔从 ViT 输出逐层构建，浅层高分、深层低分
- UperNet 的 FPN 能正确工作于不同分辨率的输入
"""

import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import torch.nn as nn
import torch.nn.functional as F
from argparse import Namespace


# ============ ViT Feature Pyramid Builder ============

class ViTFeaturePyramid(nn.Module):
    """
    从 ViT 单尺度特征构建真正的多尺度金字塔。

    输入:  [B, in_dim, H, W]    — ViT 输出 (如 768, 16×16 for 224×224)
    输出:
        p0: [B, p0_dim, H×4, W×4]  — 最浅层，高分辨率
        p1: [B, p1_dim, H×2, W×2]
        p2: [B, p2_dim, H, W]       — 与输入同分辨率
        p3: [B, p3_dim, H/2, W/2]   — 最深层，低分辨率

    通道设计:
        p0=128, p1=128, p2=256, p3=512
        浅层小通道省计算（分辨率高），深层大通道保语义（分辨率低）
    """

    def __init__(self, in_dim=768):
        super().__init__()
        # GroupNorm: 不受 batch/spatial 维度限制，适合 batch=1 训练
        def _gn(ch):
            return nn.GroupNorm(min(32, ch), ch)

        # 通道压缩 → 统一进入 512 维
        self.reduce = nn.Sequential(
            nn.Conv2d(in_dim, 512, kernel_size=1),
            _gn(512),
            nn.ReLU(inplace=True),
        )

        # p2: 同分辨率，通道 256
        self.conv_p2 = nn.Sequential(
            nn.Conv2d(512, 256, kernel_size=3, padding=1),
            _gn(256),
            nn.ReLU(inplace=True),
        )

        # p3: stride-2 下采样，通道 512
        self.conv_p3 = nn.Sequential(
            nn.Conv2d(512, 512, kernel_size=3, stride=2, padding=1),
            _gn(512),
            nn.ReLU(inplace=True),
        )

        # p1: x2 上采样 → 通道 128
        self.conv_p1 = nn.Sequential(
            nn.Conv2d(256, 128, kernel_size=3, padding=1),
            _gn(128),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
        )

        # p0: x2 上采样 (从 p1 尺寸) → 通道 128
        self.conv_p0 = nn.Sequential(
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            _gn(128),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
        )

    def forward(self, x):
        """
        Args:
            x: [B, in_dim, H, W]  — ViT 特征图 (reshape 后的)
        Returns:
            list of [p0, p1, p2, p3]  — 浅层→深层
        """
        r = self.reduce(x)         # [B, 512, H, W]

        p2 = self.conv_p2(r)       # [B, 256, H, W]
        p3 = self.conv_p3(r)       # [B, 512, H/2, W/2]
        p1 = self.conv_p1(p2)      # [B, 128, H*2, W*2]
        p0 = self.conv_p0(p1)      # [B, 128, H*4, W*4]

        return [p0, p1, p2, p3]


# ============ HR ViT Backbone ============

def build_hr_backbone(weight_path, arch='vit_base', patch_size=14, n_storage_tokens=0):
    """构建 HR ViT backbone 并加载预训练权重。

    Args:
        weight_path: 预训练权重 .pth 路径
        arch: 'vit_base' | 'vit_large'
        patch_size: 14 (DINOv2) | 16 (DINOv3)
        n_storage_tokens: 0 (DINOv2) | 4 (DINOv3 registers)
    """
    vit_args = Namespace(
        arch=arch, patch_size=patch_size, img_size=224,
        pos_embed_rope_base=100, pos_embed_rope_min_period=None,
        pos_embed_rope_max_period=None,
        pos_embed_rope_normalize_coords="separate",
        pos_embed_rope_shift_coords=None, pos_embed_rope_jitter_coords=None,
        pos_embed_rope_rescale_coords=None,
        qkv_bias=True, layerscale=1e-5, norm_layer="layernorm",
        ffn_layer="mlp", ffn_bias=True, proj_bias=True,
        n_storage_tokens=n_storage_tokens, mask_k_bias=False,
        untie_cls_and_patch_norms=False, untie_global_and_local_cls_norm=False,
        drop_path_rate=0.0, fp8_enabled=False, fp8_filter=None,
    )
    from dinov3.models import build_model
    backbone, embed_dim = build_model(vit_args, only_teacher=True, img_size=224)
    backbone = backbone.cuda()
    backbone.eval()

    if os.path.exists(weight_path):
        state = torch.load(weight_path, map_location="cpu", weights_only=True)
        if 'student' in state:
            state = state['student']
        elif 'model' in state:
            state = state['model']
        msg = backbone.load_state_dict(state, strict=False)
        print(f"[HR ViT] loaded {weight_path}")
        print(f"  missing={len(msg.missing_keys)}, unexpected={len(msg.unexpected_keys)}")
    else:
        print(f"[HR ViT] weight not found: {weight_path}")

    for p in backbone.parameters():
        p.requires_grad = False

    return backbone, embed_dim


# ============ 变化检测模型 ============

class DINOv3OpticalCD(nn.Module):
    """
    纯光学变化检测模型 v2。

    HR ViT backbone (冻结) → diff → ViTFeaturePyramid (可训练) → UperNet
    """

    def __init__(self, weight_path, num_classes=2, decoder_channels=512,
                 img_size=224, arch='vit_base', finetune_backbone=False,
                 patch_size=14, n_storage_tokens=0):
        super().__init__()
        self.img_size = img_size
        self.backbone, self.embed_dim = build_hr_backbone(
            weight_path, arch=arch, patch_size=patch_size,
            n_storage_tokens=n_storage_tokens)

        # 全参微调：解冻 backbone
        if finetune_backbone:
            for p in self.backbone.parameters():
                p.requires_grad = True
            print(f"[HR ViT] backbone UNFROZEN for full finetuning")

        # 真·多尺度特征金字塔（可训练）
        self.pyramid = ViTFeaturePyramid(in_dim=self.embed_dim)

        # UperNet 解码头: 接收 4 层不同分辨率特征
        # p0: 128ch, p1: 128ch, p2: 256ch, p3: 512ch
        from models.cd_head import CDHead
        self.decoder = CDHead(
            in_channels=[128, 128, 256, 512],
            channels=decoder_channels,
            num_classes=num_classes,
            decoder_type='upernet',
            output_size=(img_size, img_size),
        )

    def forward(self, pre_img, post_img):
        """
        Args:
            pre_img:  前时相光学图 [B, 3, H, W]
            post_img: 后时相光学图 [B, 3, H, W]
        Returns:
            logits: [B, num_classes, H, W]
        """
        # 全参微调时 backbone 需要梯度，冻结时用 no_grad 省显存
        backbone_needs_grad = any(p.requires_grad for p in self.backbone.parameters())
        ctx = torch.no_grad if not backbone_needs_grad else torch.enable_grad

        with ctx():
            # 取最后一层 ViT 特征 (depth-1)
            last_idx = len(self.backbone.blocks) - 1
            pre_feat = self.backbone.get_intermediate_layers(
                pre_img, n=[last_idx], reshape=True, norm=True,
            )[0]
            post_feat = self.backbone.get_intermediate_layers(
                post_img, n=[last_idx], reshape=True, norm=True,
            )[0]

        # 差分配对
        diff = torch.abs(pre_feat - post_feat)

        # 构建真正的多尺度金字塔
        pyramid_feats = self.pyramid(diff)  # [p0, p1, p2, p3]

        return self.decoder(pyramid_feats)


def build_optical_cd_model(
    weight_path=None,
    num_classes=2,
    decoder_channels=512,
    img_size=224,
    arch='vit_base',
    finetune_backbone=False,
    patch_size=14,
    n_storage_tokens=0,
):
    """工厂函数：构建纯光学变化检测模型。

    Args:
        arch: 'vit_base' | 'vit_large'
        patch_size: 14 (DINOv2) | 16 (DINOv3)
        n_storage_tokens: 0 (DINOv2) | 4 (DINOv3)
        finetune_backbone: 解冻 ViT 全参微调
    """
    if weight_path is None:
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        weight_map = {
            ('vit_base', 14): 'dinov3_vitb14_pretrain.pth',
            ('vit_large', 14): 'dinov2_vitl14_pretrain.pth',
            ('vit_large', 16): 'dinov3_vitl16_sat493m.pth',
        }
        key = (arch, patch_size)
        if key not in weight_map:
            raise ValueError(f"No default weight for arch={arch} patch_size={patch_size}")
        weight_path = os.path.join(project_root, 'weights', weight_map[key])
    model = DINOv3OpticalCD(
        weight_path=weight_path,
        num_classes=num_classes,
        decoder_channels=decoder_channels,
        img_size=img_size,
        arch=arch,
        finetune_backbone=finetune_backbone,
        patch_size=patch_size,
        n_storage_tokens=n_storage_tokens,
    ).cuda()
    return model
