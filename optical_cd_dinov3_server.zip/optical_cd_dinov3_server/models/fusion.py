"""
简单特征融合模块 — 用于与 FusionViT 对比的基线方法。
"""

import torch
import torch.nn as nn


class SimpleFusion(nn.Module):
    """
    简单融合模块 — 用于对比 FusionViT 的效果。

    与 FusionViT 是互斥的：如果要测试纯差分效果，
    在配置中 backbone_type='simple' 时使用本模块。

    支持的融合方式:
        - 'diff':       |f1 - f2|
        - 'concat':     [f1, f2]
        - 'diff_concat': [f1, f2, |f1 - f2|]
    """

    def __init__(self, fusion_type: str = 'diff'):
        super().__init__()
        assert fusion_type in ('diff', 'concat', 'diff_concat'), \
            f"Unknown fusion_type: {fusion_type}"
        self.fusion_type = fusion_type

    def forward(self, feats_t1, feats_t2):
        """
        Args:
            feats_t1, feats_t2: list of 4 tensors [B, C, H, W]
        Returns:
            fused: list of 4 tensors
        """
        fused = []
        for f1, f2 in zip(feats_t1, feats_t2):
            if self.fusion_type == 'diff':
                fused.append(torch.abs(f1 - f2))
            elif self.fusion_type == 'concat':
                fused.append(torch.cat([f1, f2], dim=1))
            elif self.fusion_type == 'diff_concat':
                diff = torch.abs(f1 - f2)
                fused.append(torch.cat([f1, f2, diff], dim=1))
        return fused
