"""
变化检测模型：HR ViT（冻结）+ SimpleSAR CNN（训练）+ diff + UperNet

数据流（LEVIR-CD）：
  前时相 RGB → HR ViT(冻结) → 4层特征 [B,768,16,16]
  后时相 RGB → HR ViT(冻结) → 4层特征 [B,768,16,16]
                                   ↓ diff (逐层绝对值差)
                              UperNet → 变化图

数据流（BRIGHT）：
  光学前时相 → HR ViT(冻结) → 4层特征 [B,768,16,16]
  SAR后时相  → SAR CNN(训练) → 4层特征 [B,768,16,16]
                                   ↓ diff
                              UperNet → 损伤图
"""

import os
import sys
sys.path.insert(0, "E:/dinov3-main/dinov3-main")

import torch
import torch.nn as nn
import torch.nn.functional as F
from argparse import Namespace


class SimpleSAREncoder(nn.Module):
    """
    SAR 多尺度编码器（可训练）。
    输入: [B, 1, H, W] → 输出: 4层特征，每层上采样到 16×16
    """

    def __init__(self, in_channels=1, embed_dim=768):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(in_channels, 64, 7, 2, 3), nn.BatchNorm2d(64), nn.ReLU(True),
            nn.MaxPool2d(3, 2, 1),
        )
        # 4 个 stage, 不同分辨率
        self.layer1 = self._make_layer(64, 64, 2, 1)
        self.layer2 = self._make_layer(64, 128, 2, 2)
        self.layer3 = self._make_layer(128, 256, 2, 2)
        self.layer4 = self._make_layer(256, 512, 2, 2)
        # 投影到 embed_dim — 注意输入通道必须匹配每层的实际输出通道
        self.proj1 = nn.Conv2d(64, embed_dim, 1)     # stem输出: 64
        self.proj2 = nn.Conv2d(64, embed_dim, 1)     # layer1输出: 64
        self.proj3 = nn.Conv2d(128, embed_dim, 1)    # layer2输出: 128
        self.proj4 = nn.Conv2d(512, embed_dim, 1)    # layer4输出: 512

    def _make_layer(self, in_p, out_p, blocks, stride):
        layers = []
        layers += [nn.Conv2d(in_p, out_p, 3, stride, 1), nn.BatchNorm2d(out_p), nn.ReLU(True)]
        for _ in range(1, blocks):
            layers += [nn.Conv2d(out_p, out_p, 3, 1, 1), nn.BatchNorm2d(out_p), nn.ReLU(True)]
        return nn.Sequential(*layers)

    def forward(self, x):
        # x: [B,1,H,W] (224×224)
        x = self.stem(x)                                     # [B,64,56,56]
        f1 = self.proj1(x)                                   # [B,768,56,56]

        x = self.layer1(x)                                   # [B,64,56,56]
        f2 = self.proj2(x)                                   # [B,768,56,56]

        x = self.layer2(x)                                   # [B,128,28,28]
        f3 = self.proj3(x)                                   # [B,768,28,28]

        x = self.layer3(x)                                   # [B,256,14,14]

        x = self.layer4(x)                                   # [B,512,7,7]
        f4 = self.proj4(x)                                   # [B,768,7,7]

        # 全部上采样到 16×16，匹配 HR ViT 的特征图尺寸
        out = []
        for feat in [f1, f2, f3, f4]:
            out.append(F.interpolate(feat, size=(16, 16), mode='bilinear', align_corners=False))
        return out  # [B,768,16,16] × 4


class DINOv3CD(nn.Module):
    """HR ViT(冻结) + SAR CNN + UperNet 变化检测模型。"""

    def __init__(self, backbone, embed_dim=768, num_classes=2):
        super().__init__()
        self.backbone = backbone
        self.embed_dim = embed_dim

        # SAR 编码器（可训练）
        self.sar_encoder = SimpleSAREncoder(1, embed_dim)

        # UperNet 解码器
        from .cd_head import CDHead
        self.decoder = CDHead(
            in_channels=[embed_dim] * 4,
            num_classes=num_classes,
        )

        # 冻结 backbone
        self._freeze_backbone()

    def _freeze_backbone(self):
        for p in self.backbone.parameters():
            p.requires_grad = False
        self.backbone.eval()
        print("[CD] HR ViT frozen ok")

    def forward(self, optical_img, sar_img):
        """
        前向：BRIGHT 光学前时相 + SAR后时相 → 损伤图。
        
        Args:
            optical_img: [B, 3, 224, 224]
            sar_img:     [B, 1, 224, 224]
        Returns:
            logits: [B, C, 224, 224]
        """
        with torch.no_grad():
            hr_feats = self.backbone.get_intermediate_layers(
                optical_img, n=[2, 5, 8, 11], reshape=True, norm=True)

        sar_feats = self.sar_encoder(sar_img)

        fused = []
        for hf, sf in zip(hr_feats, sar_feats):
            if sf.shape[-2:] != hf.shape[-2:]:
                sf = F.interpolate(sf, size=hf.shape[-2:], mode='bilinear', align_corners=False)
            fused.append(torch.abs(hf - sf))

        return self.decoder(fused)


def build_hr_backbone(weight_path=None):
    """构建 HR ViT backbone（DINOv2 ViT-B/14）。"""
    if weight_path is None:
        weight_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                    'weights', 'dinov3_vitb14_pretrain.pth')
    vit_args = Namespace(
        arch="vit_base", patch_size=14, img_size=224,
        pos_embed_rope_base=100, pos_embed_rope_min_period=None,
        pos_embed_rope_max_period=None,
        pos_embed_rope_normalize_coords="separate",
        pos_embed_rope_shift_coords=None, pos_embed_rope_jitter_coords=None,
        pos_embed_rope_rescale_coords=None,
        qkv_bias=True, layerscale=1e-5, norm_layer="layernorm",
        ffn_layer="mlp", ffn_bias=True, proj_bias=True,
        n_storage_tokens=0, mask_k_bias=False,
        untie_cls_and_patch_norms=False, untie_global_and_local_cls_norm=False,
        drop_path_rate=0.0, fp8_enabled=False, fp8_filter=None,
    )
    from dinov3.models import build_model
    backbone, embed_dim = build_model(vit_args, only_teacher=True, img_size=224)

    if os.path.exists(weight_path):
        state = torch.load(weight_path, map_location="cpu", weights_only=True)
        # 兼容 dinov3 格式（含 student/teacher 嵌套）
        if 'student' in state:
            state = state['student']
        elif 'model' in state:
            state = state['model']
        msg = backbone.load_state_dict(state, strict=False)
        print(f"[HR ViT] 加载 {weight_path}")
        print(f"  missing={len(msg.missing_keys)}, unexpected={len(msg.unexpected_keys)}")
    else:
        print(f"[HR ViT] WARN: weights not found: {weight_path}")
    return backbone, embed_dim


def build_cd_model(weight_path=None, num_classes=2):
    """构建完整 CD 模型。"""
    backbone, embed_dim = build_hr_backbone(weight_path)
    model = DINOv3CD(backbone=backbone, embed_dim=embed_dim, num_classes=num_classes)

    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"[CD] Total={total/1e6:.2f}M, Trainable={trainable/1e6:.2f}M")
    return model
