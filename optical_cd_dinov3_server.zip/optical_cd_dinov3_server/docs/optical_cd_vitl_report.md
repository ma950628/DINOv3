# optical_cd_vitl — DINOv2 ViT-L/14 实验线（LEVIR-CD）

> 状态：⚠️ 已归档 | 数据集：LEVIR-CD | 结论：**ViT-L + LEVIR-CD 路线废弃**

---

## 📋 项目定位

探索 DINOv2 ViT-L/14 (342M 参数) 在 LEVIR-CD 上的全参微调。**三轮实验全部失败**，核心原因是 LEVIR-CD 训练集仅 445 张图，不足以支撑 ViT-L 全参收敛。本项目作为"数据饥饿"的经典反面教材保留。

> ⚠️ 该仓库的 train.py 从未被实际使用——ViT-L 训练实际在 `optical_cd_dinov3` 目录完成。本项目保留 ViT-L 代码改造（GN 化 + arch 参数），供架构参考。

---

## 🏗️ 架构

与 optical_cd v4 相同架构，将 ViT-B/14 替换为 ViT-L/14：

| 组件 | ViT-B | ViT-L |
|:--|:--|:--|
| 参数量 | 86M | **342M** |
| Embed Dim | 768 | **1024** |
| Layers | 12 | **24** |
| Heads | 12 | **16** |
| 全项目 BN→GN | ❌ (v4) | ✅ |

---

## 📊 三轮实验

| 轮次 | class_weight | Epochs | Best Val F1 | Test F1 | 结果 |
|:--|:--|:--|:--:|:--:|:--|
| R1 | 1.0, 10.0 | 100 | **0.733** | 0.733 | P 崩溃 (0.41)，太激进 |
| R2 | None | 37⁻ | 0.701 | — | P/R 狂振荡 ±0.25，模型迷路 |
| R3 | 1.0, 3.0 | 22⁻ | 0.689 | — | 方向正确但意外中断 |

> ⁻ 表示因训练不稳定手动终止或意外中断。

---

## 🧠 核心教训

### 1. ViT-L + 小数据集 = 结构性收敛失败

**445 张图喂 342M 参数，自由度远大于信号。** 三轮实验试遍了 class_weight 从 10→None→3，无一稳定：

- w=10：模型被"逼迫"关注变化类，P 掉到 0.41（大量误报）
- w=None：模型完全找不到方向，P/R 振幅 ±0.25
- w=3：方向对，但隔几个 epoch 就"归零"一次

### 2. class_weight ≠ 万能药

在小数据集上，class_weight 无法弥补数据量不足。它只能引导方向，不能在根本性信号不足时创造信息。

### 3. 真正的问题是数据，不是模型

LEVIR-CD 手里仅有 445 张训练图（非预期的 7120 张）。342M ViT-L 在这上面拿到 F1=0.733 已经是奇迹——这相当于"用博士教材教小学生"，不是博士不行。

---

## 🗑️ 路线废弃 → 转向 SYSU-CD

LEVIR-CD ViT-L 实验后，决定：

1. **放弃 LEVIR-CD 的 ViT-L 路线**
2. **转向 SYSU-CD**（12K 训练图，6.2% 正样本）作为 ViT-L 的主战场
3. 所有后续 ViT-L/DINOv3 训练在 `optical_cd_dinov3` 仓库完成

---

## 📁 文件结构

```
optical_cd_vitl/
├── train.py              # ViT-L 适配 (未实际使用)
├── models/
│   └── dinov3_optical_cd.py  # GN 化 + arch 支持
├── weights/
│   └── dinov2_vitl14_pretrain.pth (1.16GB)
├── outputs/
│   ├── 2026-06-10_vitl-w10_f1-0.733/    # R1
│   ├── 2026-06-10_vitl-noweight_f1-0.701/ # R2
│   └── 2026-06-10_vitl-w3_F1-0.689_aborted/ # R3
└── docs/
    └── optical_cd_vitl_report.md  # 本文档
```

---

## 🎯 参考价值

- ✅ ViT-L 代码改造（GN + arch + finetune_backbone）是有效的
- ✅ 可作为 **"大模型在小数据集崩溃"的教学案例**
- ❌ 不应用于任何实际训练
