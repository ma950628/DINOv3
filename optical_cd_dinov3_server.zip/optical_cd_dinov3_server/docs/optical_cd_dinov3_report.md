# optical_cd_dinov3 — 通用多架构变化检测（训练主场）

> 状态：✅ 完成 | 数据集：SYSU-CD | 最佳 Test F1：**0.892** (DINOv3 SAT)

---

## 📋 项目定位

**当前变化检测的主训练仓库**。支持三种架构（Vit-B / ViT-L / DINOv3 SAT），一键切换。本项目是 ViT-L 和 DINOv3 SAT 所有 SYSU-CD 训练的实际执行者。

---

## 🏗️ 架构

```
前时相 RGB → DINOv2 或 DINOv3 ViT (共享权重) → diff → ViTFeaturePyramid → UPerNet
后时相 RGB → DINOv2 或 DINOv3 ViT (共享权重) ↗
```

### 三架构对比

| 架构 | Backbone | Patch | 位置编码 | Register | 权重 |
|:--|:--|:--|:--|:--|:--|
| `vit_base` | DINOv2 ViT-B/14 | 14 | 可学习 | 0 | dinov3_vitb14 (346MB) |
| `vit_large` | DINOv2 ViT-L/14 | 14 | 可学习 | 0 | dinov2_vitl14 (1.16GB) |
| `dinov3_vitl` | DINOv3 ViT-L/16 SAT | **16** | **RoPE** | **4** | dinov3_vitl16_sat493m (1.13GB) 🛰️ |

| 组件 | 详情 |
|:--|:--|
| 特征金字塔 | ViTFeaturePyramid (真·多尺度) |
| Decoder | UPerNet + PPM |
| 全项目 | BN→GN (适配 batch=1) |
| 参数量 | ~342M (ViT-L), ~86M (ViT-B) |

---

## 📊 训练结果

### SYSU-CD 数据集
- 20,000 对 256×256 航拍（train 12K / val 4K / test 4K）
- 香港 2007-2014，地物变化（建筑+植被+道路+海岸）
- 6.2% 正样本像素（2× LEVIR-CD）

---

### 🏆 DINOv3 SAT-493M (100 epochs)

| 指标 | Val Best | Test |
|:--|:--|:--|
| **F1** | **0.888** (epoch 74) | **0.892** 🔥 |
| **IoU** | — | **0.713** |
| **Precision** | — | **0.868** |
| **Recall** | — | **0.800** |
| **mIoU** (估) | — | **~0.846** |

**训练曲线：**
| 阶段 | Epoch | 特征 |
|:--|:--|:--|
| 🚀 爆发 | 0~7 | E0 F1=0.843 首轮超越 DINOv2 终局 |
| 📈 上行 | 8~21 | 震荡中摸到 0.884 |
| 🏔️ 高原 | 22~38 | 0.86~0.88 反复磨 |
| 🌊 第二春 | 39~74 | 再破到 0.888 |
| ⏸️ 平盘 | 75~99 | 余弦 LR 衰减至零，稳定在 0.884~0.885 |

---

### 🏆 DINOv2 ViT-L/14 (100 epochs)

| 指标 | Val Best | Test |
|:--|:--|:--|
| **F1** | **0.842** (epoch 24) | **0.858** |
| **IoU** | — | **0.641** |
| **Precision** | — | **0.806** |
| **Recall** | — | **0.758** |

**特征：** Epoch 24 到顶后 49 轮零进展——余弦退火 LR 衰减至零，模型信号饱和。

---

### DINOv3 vs DINOv2 核心差异

| | DINOv2 ViT-L | DINOv3 SAT | 提升 |
|:--|:--|:--|:--|
| Test F1 | 0.858 | **0.892** | +0.034 |
| Test IoU | 0.641 | **0.713** | +0.072 |
| Epoch 0 P/R | 0.68/0.51 | **0.74/0.77** | 即平衡 |
| 收敛速度 | 4 轮才 P/R 平衡 | 首轮即平衡 | 4× |

**关键洞察：** DINOv3 SAT 的卫星预训练让模型"一睁眼就能看见变化"——不需要从 ImageNet 语义空间"翻译"航拍地物。RoPE 动态位置编码也比可学习 pos_embed 更不容易卡死。

---

## 🛠️ 训练基础设施

### 关键参数

| 参数 | ViT-L | DINOv3 SAT |
|:--|:--|:--|
| `--arch` | `vit_large` | `dinov3_vitl` |
| `--dataset` | `sysu` | `sysu` |
| `--img-size` | 448 | 448 |
| `--batch-size` | 3 | 2 |
| `--epochs` | 100 | 100 |
| `--max-samples` | 3000 | 3000 |
| `--lr` | 1e-4 | 1e-4 |
| Scheduler | CosineAnnealing(T_max=100) | 同 |
| AMP | fp16 | fp16 |
| 每轮耗时 | ~8.5 min | ~8.5 min |

### 已实现功能

- ✅ `--max-samples N` 每 epoch 随机重抽
- ✅ `--resume` 断点续跑 (optimizer+scheduler+scaler)
- ✅ AMP 混合精度 (cudnn.benchmark + autocast + GradScaler)
- ✅ `finish_test.py` 自动出图 (曲线 + 预测可视化)
- ✅ 时间戳输出目录 (每次训练独立，永不覆写)
- ✅ 三种架构一键切换

---

## 🧠 关键经验

### 1. 卫星预训练是降维打击
DINOv3 SAT Epoch 0 = 0.843 > DINOv2 100 轮 = 0.842。这不是微调技巧的胜利，是预训练数据分布的根本性优势。

### 2. ViT-L 需要数据量，不需要 class_weight
SYSU-CD 12K 张 + 6.2% 信号密度让 ViT-L 从 Epoch 0 就稳定收敛，完全不需要 LEVIR 上的 weight 调参。

### 3. 余弦退火在后期压制明显
Epoch 60 后 LR 降到 5e-5 以下，模型梯度更新效率急剧下降。DINOv2 ViT-L 的 49 轮平盘可能不是能力到头，而是 LR 不够。

### 4. 0.892 是当前框架的天花板
DINOv3 SAT + UPerNet + diff 融合在这个数据集上的天花板约 0.89~0.90。想突破需要架构级改进（时序 Transformer、多尺度注意力融合等）。

---

## 📁 文件结构

```
optical_cd_dinov3/
├── train.py                  # 训练入口 (三架构)
├── finish_test.py             # 测试 + 自动出图
├── models/
│   └── dinov3_optical_cd.py  # ViTFeaturePyramid + DINOv3OpticalCD
├── tools/
│   ├── plot_curves.py
│   ├── plot_results.py
│   └── metrics.py
├── weights/
│   ├── dinov3_vitb14_pretrain.pth (346MB)
│   ├── dinov2_vitl14_pretrain.pth (1.16GB)
│   └── dinov3_vitl16_sat493m.pth (1.13GB) 🛰️
├── outputs/
│   ├── 2026-06-10_16-22-02/  # DINOv2 ViT-L SYSU-CD (Test F1=0.858)
│   └── 2026-06-11_13-58-16/  # DINOv3 SAT SYSU-CD (Test F1=0.892) 🏆
├── logs/                     # 训练日志 (同步时间戳)
├── docs/
│   ├── optical_cd_dinov3_report.md  # 本文档
│   └── levir_cd_sota_gap_analysis.md
└── dinov3/                   # DINOv3 源码 (自包含)
```

---

## 🎯 下一站

- 天花板突破：时序 Transformer decoder 替代 diff→UPerNet
- 数据集扩展：FOTBCD-Binary (27K 张 512×512)
- 多模态：DINOv3 SAT 光学 + OlmoEarth SAR → `optical_sar_cd`
