"""
预测可视化工具：optical_cd 项目（LEVIR-CD 二分类变化检测）

5 列热力图：前时相 | 后时相 | 预测 | 真值 | 变化概率热力图
所有样本合并为一张 predictions.png。

用法:
    # 独立运行
    python tools/plot_results.py --model outputs/best_model.pth --output outputs/figures/

    # 从 train.py 调用
    from tools.plot_results import visualize_predictions
    visualize_predictions(model, data_root, output_dir, device, img_size=448)
"""

import os, sys, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import torch
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tqdm import tqdm
from torch.utils.data import DataLoader
import albumentations as A
from albumentations.pytorch import ToTensorV2


def load_test_samples(data_root, num_samples=8, img_size=448):
    """加载 LEVIR-CD 测试集样本。"""
    import cv2

    class TestDataset(torch.utils.data.Dataset):
        def __init__(self, root, size):
            self.root = root
            self.size = size
            self.img_list = sorted(os.listdir(os.path.join(root, 'test', 'A')))
            self.transform = A.Compose([
                A.Resize(size, size),
                A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                ToTensorV2(),
            ], additional_targets={'image_post': 'image'})

        def __getitem__(self, idx):
            name = self.img_list[idx]
            pre = cv2.imread(os.path.join(self.root, 'test', 'A', name))
            pre = cv2.cvtColor(pre, cv2.COLOR_BGR2RGB)
            post = cv2.imread(os.path.join(self.root, 'test', 'B', name))
            post = cv2.cvtColor(post, cv2.COLOR_BGR2RGB)
            label = cv2.imread(os.path.join(self.root, 'test', 'label', name), 0)
            label = (label == 255).astype(np.int64)
            aug = self.transform(image=pre, image_post=post, mask=label)
            return name, aug['image'], aug['image_post'], aug['mask']

        def __len__(self):
            return len(self.img_list)

    ds = TestDataset(data_root, img_size)
    loader = DataLoader(ds, batch_size=1, shuffle=False, num_workers=0)

    samples = []
    for names, pre, post, label in loader:
        if len(samples) >= num_samples:
            break
        samples.append((names[0], pre[0], post[0], label[0]))
    return samples


def visualize_predictions(model, data_root, output_dir, device='cuda',
                          num_samples=8, img_size=448):
    """
    供 train.py 调用的接口。所有样本合并为一张 predictions.png。

    Args:
        model: 已加载的 DINOv3CD 模型
        data_root: LEVIR-CD 数据集根目录
        output_dir: 图片输出目录
        device: cuda/cpu
        num_samples: 生成样本数
        img_size: 输入分辨率
    """
    os.makedirs(output_dir, exist_ok=True)
    model.eval()

    print(f"[Predictions] Loading {num_samples} test samples...")
    samples = load_test_samples(data_root, num_samples, img_size)

    # 推理
    print(f"[Predictions] Running inference...")
    preds_list = []
    probs_list = []
    mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)

    with torch.no_grad():
        for name, pre, post, _ in tqdm(samples, desc='Predict'):
            pre_b = pre.unsqueeze(0).to(device)
            post_b = post.unsqueeze(0).to(device)
            out = model(pre_b, post_b)  # [1, 2, H, W]

            prob = torch.softmax(out, dim=1)[0].cpu()  # [2, H, W]
            pred = out.argmax(dim=1)[0].cpu().numpy()
            change_prob = prob[1].numpy()  # 变化类的概率

            preds_list.append(pred)
            probs_list.append(change_prob)

    # 画图（5 列：前时相 | 后时相 | 预测 | 真值 | 变化概率热力图）
    print(f"[Predictions] Generating figures...")
    fig, axes = plt.subplots(num_samples, 5, figsize=(20, 4 * num_samples))

    if num_samples == 1:
        axes = axes.reshape(1, -1)

    for i, ((name, pre, post, label), pred, change_prob) in enumerate(
            zip(samples, preds_list, probs_list)):
        # Denormalize
        pre_img = pre * std + mean
        pre_img = pre_img.permute(1, 2, 0).numpy().clip(0, 1)
        post_img = post * std + mean
        post_img = post_img.permute(1, 2, 0).numpy().clip(0, 1)
        gt = label.numpy()

        # Row layout
        axes[i, 0].imshow(pre_img)
        axes[i, 0].set_title('Pre-event', fontsize=10)
        axes[i, 1].imshow(post_img)
        axes[i, 1].set_title('Post-event', fontsize=10)
        axes[i, 2].imshow(pred, cmap='gray', vmin=0, vmax=1)
        axes[i, 2].set_title('Prediction', fontsize=10)
        axes[i, 3].imshow(gt, cmap='gray', vmin=0, vmax=1)
        axes[i, 3].set_title('Ground Truth', fontsize=10)
        im = axes[i, 4].imshow(change_prob, cmap='hot', vmin=0, vmax=1)
        axes[i, 4].set_title(f'Change Prob (max={change_prob.max():.3f})', fontsize=10)

        for j in range(5):
            axes[i, j].axis('off')

    plt.tight_layout()
    save_path = os.path.join(output_dir, 'predictions.png')
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[Predictions] Saved: {save_path}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default=None,
                        help='Model weight path')
    parser.add_argument('--data-root', default='E:/datasets/SYSU-CD')
    parser.add_argument('--arch', default='dinov3_vitl', choices=['vit_base', 'vit_large', 'dinov3_vitl'])
    parser.add_argument('--dataset', default='sysu', choices=['levir', 'sysu'])
    parser.add_argument('--output', default=None)
    parser.add_argument('--num-samples', type=int, default=8)
    parser.add_argument('--img-size', type=int, default=448)
    parser.add_argument('--device', default='cuda')
    args = parser.parse_args()

    from models.dinov3_optical_cd import build_optical_cd_model

    project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    model_path = args.model or os.path.join(project_dir, 'outputs', 'best_model.pth')
    output_dir = args.output or os.path.join(project_dir, 'outputs', 'figures')

    print(f"Loading model from {model_path}...")
    model = build_optical_cd_model(num_classes=2, img_size=args.img_size, arch=args.arch)
    model.load_state_dict(torch.load(model_path, map_location='cpu', weights_only=True))
    model = model.to(args.device)

    visualize_predictions(model, args.data_root, output_dir, args.device,
                          args.num_samples, args.img_size)
