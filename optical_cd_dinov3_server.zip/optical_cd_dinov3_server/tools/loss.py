"""
变化检测损失函数 — CrossEntropyLoss。
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class CELoss(nn.Module):
    """
    交叉熵损失，支持类别权重。
    """

    def __init__(self, num_classes=2, ignore_index=255, weight=None):
        super().__init__()
        if weight is not None:
            weight = torch.tensor(weight)
        self.loss = nn.CrossEntropyLoss(
            weight=weight, ignore_index=ignore_index
        )

    def forward(self, pred, target):
        """
        Args:
            pred: [B, C, H, W] logits
            target: [B, H, W] labels
        Returns:
            loss: scalar
        """
        return self.loss(pred, target)


class DiceLoss(nn.Module):
    """
    Dice Loss for binary segmentation.
    Smooth = 1 to avoid division by zero.
    """

    def __init__(self, smooth=1.0):
        super().__init__()
        self.smooth = smooth

    def forward(self, pred, target):
        """
        Args:
            pred: [B, 2, H, W] logits
            target: [B, H, W] labels (0 or 1)
        """
        pred = F.softmax(pred, dim=1)[:, 1, :, :]  # 变化类概率 [B, H, W]
        target = target.float()

        intersection = (pred * target).sum()
        union = pred.sum() + target.sum()

        dice = (2. * intersection + self.smooth) / (union + self.smooth)
        return 1. - dice


class CombinedLoss(nn.Module):
    """
    Combined CE + Dice loss.
    """

    def __init__(self, num_classes=2, ce_weight=0.5, dice_weight=0.5, smooth=1.0):
        super().__init__()
        self.ce_loss = CELoss(num_classes=num_classes)
        self.dice_loss = DiceLoss(smooth=smooth)
        self.ce_weight = ce_weight
        self.dice_weight = dice_weight

    def forward(self, pred, target):
        ce = self.ce_loss(pred, target)
        dice = self.dice_loss(pred, target)
        return self.ce_weight * ce + self.dice_weight * dice
