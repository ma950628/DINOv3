"""
DINOv3-CD 数据集模块
"""
