"""
LEVIR-CD 数据集加载器。

LEVIR-CD 数据集结构:
    LEVIR-CD/
        train/
            A/       # 时相1 图像
            B/       # 时相2 图像
            label/   # 变化标签 (0=不变, 255=变化)
        test/
            A/
            B/
            label/

图像尺寸: 1024×1024
裁剪尺寸: 224×224 (适配 DINOv3 ViT-B patch_size=14)
"""

import os
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset
from typing import Optional, Tuple, Callable
import albumentations as A
from albumentations.pytorch import ToTensorV2


class LEVIRCDDataset(Dataset):
    """
    LEVIR-CD 变化检测数据集
    
    从原始 1024×1024 图像中随机裁剪 224×224 的 patch，
    应用数据增强后返回 (T1, T2, label) 三元组。
    """

    def __init__(
        self,
        root_dir: str,
        split: str = 'train',
        crop_size: int = 224,
        stride: int = 224,
        augment: bool = True,
        use_label: bool = True,
    ):
        """
        Args:
            root_dir: LEVIR-CD 数据集根目录
            split: 'train' 或 'test'
            crop_size: 裁剪尺寸 (默认 224)
            stride: 滑动窗口步长 (train 时建议 224, test 时建议 112 或 224)
            augment: 是否使用数据增强
            use_label: 是否使用标签 (训练/验证=True, 推理=False)
        """
        super().__init__()
        self.root_dir = root_dir
        self.split = split
        self.crop_size = crop_size
        self.stride = stride
        self.augment = augment
        self.use_label = use_label

        # 数据集路径
        self.A_dir = os.path.join(root_dir, split, 'A')
        self.B_dir = os.path.join(root_dir, split, 'B')
        self.label_dir = os.path.join(root_dir, split, 'label') if use_label else None

        # 获取图像文件名
        self.image_names = sorted(os.listdir(self.A_dir))
        if use_label:
            # 确保标签目录存在
            if not os.path.exists(self.label_dir):
                raise FileNotFoundError(f"标签目录不存在: {self.label_dir}")

        # 预处理坐标: 为每张图像生成裁剪位置
        self._precompute_crops()

        # 构建数据增强 pipeline
        self.transform = self._build_transform()

    def _precompute_crops(self):
        """预计算所有图像的裁剪坐标"""
        self.crops = []  # [(image_idx, x, y), ...]

        for idx in range(len(self.image_names)):
            # 读取一张图像获取尺寸
            img_path = os.path.join(self.A_dir, self.image_names[idx])
            h, w = cv2.imread(img_path).shape[:2]

            # 滑动窗口生成裁剪坐标
            for y in range(0, h - self.crop_size + 1, self.stride):
                for x in range(0, w - self.crop_size + 1, self.stride):
                    self.crops.append((idx, x, y))

            # 处理右侧和下侧的边界
            if w - self.crop_size > 0 and (w - self.crop_size) % self.stride != 0:
                x = w - self.crop_size
                for y in range(0, h - self.crop_size + 1, self.stride):
                    self.crops.append((idx, x, y))
            if h - self.crop_size > 0 and (h - self.crop_size) % self.stride != 0:
                y = h - self.crop_size
                for x in range(0, w - self.crop_size + 1, self.stride):
                    self.crops.append((idx, x, y))
            if w - self.crop_size > 0 and h - self.crop_size > 0:
                if (w - self.crop_size) % self.stride != 0 and (h - self.crop_size) % self.stride != 0:
                    self.crops.append((idx, w - self.crop_size, h - self.crop_size))

    def _build_transform(self):
        """构建数据增强 pipeline"""
        if self.augment and self.split == 'train':
            return A.Compose([
                # 几何增强
                A.RandomRotate90(p=0.5),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.5),
                # 色彩增强 (仅对图像，不影响标签)
                A.RandomBrightnessContrast(
                    brightness_limit=0.15, contrast_limit=0.15, p=0.5
                ),
                # 归一化到 [0, 1]
                A.Normalize(mean=(0.0, 0.0, 0.0), std=(1.0, 1.0, 1.0),
                           max_pixel_value=255.0),
                ToTensorV2(),
            ], additional_targets={'image2': 'image', 'mask1': 'mask'})
        else:
            return A.Compose([
                A.Normalize(mean=(0.0, 0.0, 0.0), std=(1.0, 1.0, 1.0),
                           max_pixel_value=255.0),
                ToTensorV2(),
            ], additional_targets={'image2': 'image', 'mask1': 'mask'})

    def __len__(self):
        return len(self.crops)

    def __getitem__(self, idx):
        """返回 (T1_image, T2_image, label) 或 (T1_image, T2_image)"""
        img_idx, x, y = self.crops[idx]
        img_name = self.image_names[img_idx]

        # 读取图像
        img_A = cv2.imread(os.path.join(self.A_dir, img_name))
        img_B = cv2.imread(os.path.join(self.B_dir, img_name))
        img_A = cv2.cvtColor(img_A, cv2.COLOR_BGR2RGB)
        img_B = cv2.cvtColor(img_B, cv2.COLOR_BGR2RGB)

        # 裁剪
        img_A = img_A[y:y + self.crop_size, x:x + self.crop_size]
        img_B = img_B[y:y + self.crop_size, x:x + self.crop_size]

        if self.use_label:
            # 读取标签
            label = cv2.imread(
                os.path.join(self.label_dir, img_name), cv2.IMREAD_GRAYSCALE
            )
            label = label[y:y + self.crop_size, x:x + self.crop_size]
            # 二值化: 变化=1, 不变=0
            label = (label > 0).astype(np.uint8)

            # 应用增强
            transformed = self.transform(
                image=img_A, image2=img_B, mask1=label
            )
            return (
                transformed['image'],          # T1 [3, H, W]
                transformed['image2'],         # T2 [3, H, W]
                transformed['mask1'].long(),   # label [H, W]
            )
        else:
            transformed = self.transform(image=img_A, image2=img_B)
            return (
                transformed['image'],
                transformed['image2'],
            )


def create_levir_dataloader(
    root_dir: str,
    split: str = 'train',
    batch_size: int = 8,
    crop_size: int = 224,
    stride: int = 224,
    augment: bool = True,
    num_workers: int = 4,
):
    """
    创建 LEVIR-CD DataLoader。

    Args:
        root_dir: 数据集根目录
        split: 'train' / 'test'
        batch_size: 批次大小
        crop_size: 裁剪尺寸
        stride: 滑动窗口步长
        augment: 是否数据增强
        num_workers: 数据加载线程数

    Returns:
        DataLoader
    """
    dataset = LEVIRCDDataset(
        root_dir=root_dir,
        split=split,
        crop_size=crop_size,
        stride=stride,
        augment=augment,
        use_label=True,
    )

    dataloader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=(split == 'train'),
        num_workers=num_workers,
        pin_memory=True,
        drop_last=(split == 'train'),
    )
    return dataloader
