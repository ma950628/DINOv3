"""
BRIGHT → SSLMetaArch_QH2 数据适配层

功能：
1. 从 BRIGHT 数据集加载光学(前) + SAR(后) 图像对
2. 将 SAR 图像包装成 OlmoEarth 期望的多源 H5 格式
3. 兼容 LEVIR-CD 作为备选数据源（快速原型验证）

OlmoEarth 期望输入格式：
    h5_data = {
        "s2": Tensor [B, H, W, T1, C1],   # Sentinel-2（多光谱）
        "s1": Tensor [B, H, W, T2, C2],   # Sentinel-1（SAR）
        "ls": Tensor [B, H, W, T3, C3],   # Landsat（多光谱）
    }
    其中 H=W=16（低分辨率空间格网），T_i=时间步数，C_i=通道数

BRIGHT 数据格式：
    pre-event/   → 光学 TIFF（前时相）
    post-event/  → SAR TIFF（后时相）
    target/      → 建筑损伤标签

关键适配策略：
    BRIGHT 只有单源 SAR → 复制到 s1/s2/ls 三个源
    每个源设置 T=1（单时相），C=1（单通道）
"""

import os
import torch
import numpy as np
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms.functional as TF
import torch.nn.functional as F


class BrightToH5Adapter:
    """
    将 BRIGHT 的 SAR 图像转换为 OlmoEarth 所需的多源 H5 格式。
    
    架构对齐：
      HR ViT 输入: 224×224 → patch_size=14 → 16×16 格网 (256 patches)
      OlmoEarth 输入: 64×64 → patch_size=4 → 16×16 格网 ✓ 对齐
    
    由于 BRIGHT 只有单源 SAR（非多源 H5），适配策略：
    - SAR 图缩放到 64×64（OlmoEarth 的输入分辨率）
    - 单通道 SAR → 复制到 s1/s2/ls 三个源
    - 每个源 T=1（单时相），C=1（单通道）
    
    未来升级到真实多源 H5 数据时，只需替换此类。
    """
    
    # OlmoEarth 输入分辨率（patch_size=4 → 输出 16×16 格网）
    OE_INPUT_SIZE = 64
    
    @staticmethod
    def sar_to_h5_dict(sar_tensor):
        """
        将单张 SAR 图像转换为 OlmoEarth 输入字典。
        
        Args:
            sar_tensor: [B, 1, H, W] 或 [1, H, W] SAR 图像
                        （值范围 [0,1]，任意分辨率）
        Returns:
            dict: {
                "s2": [B, 64, 64, 1, 1],
                "s1": [B, 64, 64, 1, 1],
                "ls": [B, 64, 64, 1, 1],
            }
        """
        # 确保是 4D [B, 1, H, W]
        if sar_tensor.dim() == 3:
            sar_tensor = sar_tensor.unsqueeze(0)
        if sar_tensor.dim() == 2:
            sar_tensor = sar_tensor.unsqueeze(0).unsqueeze(0)
        
        B = sar_tensor.shape[0]
        
        # 缩放到 OlmoEarth 的输入分辨率 64×64
        sar_resized = F.interpolate(
            sar_tensor, size=(BrightToH5Adapter.OE_INPUT_SIZE,) * 2,
            mode='bilinear', align_corners=False
        )  # [B, 1, 64, 64]
        
        # 扩展维度到 [B, H, W, T, C] = [B, 64, 64, 1, 1]
        h5_data = sar_resized.permute(0, 2, 3, 1).unsqueeze(3)  # [B, 64, 64, 1, 1]
        
        return {
            "s2": h5_data.clone(),  # 复制到三个源
            "s1": h5_data.clone(),
            "ls": h5_data.clone(),
        }
    
    @staticmethod
    def optical_to_hr_input(optical_tensor, img_size=224):
        """
        将光学图像预处理为 HR ViT 输入格式。
        
        Args:
            optical_tensor: [B, 3, H, W] 或 [3, H, W] RGB 图像
                            （值范围 0-255）
            img_size: ViT 输入尺寸（默认 224）
        Returns:
            [B, 3, img_size, img_size] 归一化到 [0,1]
        """
        if optical_tensor.dim() == 3:
            optical_tensor = optical_tensor.unsqueeze(0)
        
        # 缩放到 224×224
        optical_resized = F.interpolate(
            optical_tensor, size=(img_size, img_size), 
            mode='bilinear', align_corners=False
        )
        
        # 归一化到 [0, 1]
        if optical_resized.max() > 1.0:
            optical_resized = optical_resized / 255.0
        
        return optical_resized


class BrightCDDataset(Dataset):
    """
    BRIGHT 建筑损伤评估数据集。
    
    结构：
        ${root}/
        ├── pre-event/    → 光学 TIFF（前时相）
        ├── post-event/   → SAR TIFF（后时相）
        └── target/       → 建筑损伤标签
    
    注：完整 BRIGHT ~14.6TB。可先从 Zenodo 下载子集
    （如 bata-explosion 或 turkey-earthquake 等单个事件）。
    """
    
    def __init__(self, root, split_file=None, img_size=224, 
                 is_train=True, use_sar_adapter=True):
        """
        Args:
            root: BRIGHT 数据集根目录
            split_file: 划分文件路径（.txt），每行是 event/image_id
            img_size: HR ViT 输入尺寸
            is_train: 是否训练模式（数据增强）
            use_sar_adapter: 是否使用 BrightToH5Adapter
        """
        self.root = root
        self.img_size = img_size
        self.is_train = is_train
        self.use_sar_adapter = use_sar_adapter
        
        # 加载划分
        if split_file and os.path.exists(split_file):
            with open(split_file, 'r') as f:
                self.samples = [line.strip() for line in f if line.strip()]
        else:
            # 自动发现所有样本
            self.samples = self._discover_samples()
        
        print(f"BrightCDDataset: 发现 {len(self.samples)} 个样本")
    
    def _discover_samples(self):
        """自动发现 root 下所有配对样本"""
        pre_dir = os.path.join(self.root, 'pre-event')
        samples = []
        if os.path.isdir(pre_dir):
            for fname in os.listdir(pre_dir):
                if fname.endswith('_pre_disaster.tif'):
                    # 提取 event_imageID 前缀
                    prefix = fname.replace('_pre_disaster.tif', '')
                    samples.append(prefix)
        return sorted(samples)
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        prefix = self.samples[idx]
        
        # 文件路径
        pre_path = os.path.join(self.root, 'pre-event', 
                                f'{prefix}_pre_disaster.tif')
        post_path = os.path.join(self.root, 'post-event', 
                                 f'{prefix}_post_disaster.tif')
        target_path = os.path.join(self.root, 'target', 
                                   f'{prefix}_building_damage.tif')
        
        # 加载光学图（前时相）
        optical_img = self._load_tif(pre_path, is_optical=True)
        
        # 加载 SAR 图（后时相）
        sar_img = self._load_tif(post_path, is_optical=False)
        
        # 加载标签
        label = self._load_label(target_path)
        
        # 数据增强（仅训练）
        if self.is_train:
            optical_img, sar_img, label = self._augment(
                optical_img, sar_img, label
            )
        
        # 转为 tensor
        optical_tensor = TF.to_tensor(optical_img).float()  # [3, H, W]
        sar_tensor = TF.to_tensor(sar_img).float()          # [1, H, W]
        label_tensor = torch.from_numpy(np.array(label)).long()  # [H, W]
        
        # 缩放到固定尺寸
        optical_tensor = F.interpolate(
            optical_tensor.unsqueeze(0), 
            size=(self.img_size, self.img_size), 
            mode='bilinear', align_corners=False
        ).squeeze(0)  # [3, 224, 224]
        
        sar_tensor = F.interpolate(
            sar_tensor.unsqueeze(0),
            size=(self.img_size, self.img_size),
            mode='bilinear', align_corners=False
        ).squeeze(0)  # [1, 224, 224]
        
        label_tensor = F.interpolate(
            label_tensor.unsqueeze(0).unsqueeze(0).float(),
            size=(self.img_size, self.img_size),
            mode='nearest'
        ).squeeze().long()  # [224, 224]
        
        # 使用适配器将 SAR 转为 OlmoEarth 格式
        if self.use_sar_adapter:
            h5_dict = BrightToH5Adapter.sar_to_h5_dict(sar_tensor.unsqueeze(0))
            # 去掉 batch 维度
            h5_dict = {k: v.squeeze(0) for k, v in h5_dict.items()}
        else:
            h5_dict = None
        
        return {
            'optical': optical_tensor,     # [3, 224, 224] → HR ViT
            'h5_data': h5_dict,            # dict → OlmoEarth（可选）
            'label': label_tensor,         # [224, 224] → 损失计算
            'sar_img': sar_tensor,         # [1, 224, 224] → SAR CNN
            'prefix': prefix,              # 样本标识
        }
    
    def _load_tif(self, path, is_optical=True):
        """加载 TIFF 文件"""
        try:
            img = Image.open(path)
            if is_optical and img.mode != 'RGB':
                img = img.convert('RGB')
            elif not is_optical and img.mode != 'L':
                img = img.convert('L')  # SAR 单通道
            return img
        except Exception as e:
            print(f"加载失败 {path}: {e}")
            # 返回占位图
            if is_optical:
                return Image.new('RGB', (256, 256), (0, 0, 0))
            else:
                return Image.new('L', (256, 256), 0)
    
    def _load_label(self, path):
        """加载建筑损伤标签"""
        try:
            label = Image.open(path)
            # BRIGHT 标签: 0=无变化, 1=损伤, 255=忽略
            return label
        except:
            return Image.new('L', (256, 256), 0)
    
    def _augment(self, optical, sar, label):
        """训练时数据增强"""
        import random
        # 随机水平翻转
        if random.random() > 0.5:
            optical = TF.hflip(optical)
            sar = TF.hflip(sar)
            label = TF.hflip(label)
        # 随机垂直翻转
        if random.random() > 0.5:
            optical = TF.vflip(optical)
            sar = TF.vflip(sar)
            label = TF.vflip(label)
        return optical, sar, label


# ============================================================
# LEVIR-CD 兼容适配器（用于快速原型验证）
# ============================================================
# 注：旧的 LevirToCrossModalAdapter 已移除。
#     BRIGHT 数据集请使用 BrightCDDataset。
# ============================================================
