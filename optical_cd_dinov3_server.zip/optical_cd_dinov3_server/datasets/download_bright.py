"""
BRIGHT 数据集下载与解压脚本

下载来源：Zenodo https://zenodo.org/records/20072020
数据集版本：v2.4（2026-05-08）

使用方式：
    python download_bright.py                        # 下载全部
    python download_bright.py --only target          # 只下载标签
    python download_bright.py --no-unzip             # 只下载不解压
"""

import os
import sys
import subprocess
import zipfile
import logging
import argparse

# 代理设置（如果系统有代理）
PROXY = "http://127.0.0.1:7897"

# Zenodo 记录信息
ZENODO_RECORD = "20072020"
BASE_URL = f"https://zenodo.org/records/{ZENODO_RECORD}/files"

FILES = {
    "pre-event.zip": {
        "url": f"{BASE_URL}/pre-event.zip?download=1",
        "size_gb": 8.0,
        "target_dir": "pre-event",
    },
    "post-event.zip": {
        "url": f"{BASE_URL}/post-event.zip?download=1",
        "size_gb": 3.3,
        "target_dir": "post-event",
    },
    "target.zip": {
        "url": f"{BASE_URL}/target.zip?download=1",
        "size_gb": 0.047,
        "target_dir": "target",
    },
}


def download_file(url, dest, proxy=PROXY):
    """使用 curl 通过代理下载文件"""
    proxy_args = ["-x", proxy] if proxy else []
    cmd = ["curl", "-L", "-C", "-"] + proxy_args + [
        "-o", dest, "--connect-timeout", "30", url
    ]
    print(f"  ↓ {os.path.basename(dest)}")
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0 and proc.returncode != 18:  # 18 = partial file (resume ok)
        print(f"  ⚠ curl exit code: {proc.returncode}")
    # 打印最后一行进度
    for line in proc.stderr.split('\n'):
        if '%' in line:
            print(f"     {line.strip()}")


def unzip_file(zip_path, extract_to):
    """解压 zip 文件"""
    print(f"  📦 解压 {os.path.basename(zip_path)} → {extract_to}")
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(extract_to)
    print(f"  ✓ 解压完成")


def main():
    parser = argparse.ArgumentParser(description="BRIGHT 数据集下载")
    parser.add_argument("--only", type=str, default="",
                        help="只下载指定文件（如 target）")
    parser.add_argument("--no-unzip", action="store_true",
                        help="只下载不解压")
    parser.add_argument("--root", type=str, default=r"E:\datasets\BRIGHT",
                        help="数据集根目录")
    parser.add_argument("--proxy", type=str, default=PROXY,
                        help="代理地址")
    args = parser.parse_args()

    os.makedirs(args.root, exist_ok=True)
    tmp_dir = os.path.join(args.root, "download_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    files_to_dl = FILES
    if args.only:
        files_to_dl = {k: v for k, v in FILES.items() if args.only in k}

    for fname, info in files_to_dl.items():
        dest = os.path.join(tmp_dir, fname)
        target_dir = os.path.join(args.root, info["target_dir"])

        # 如果目标目录已存在且非空，跳过
        if os.path.isdir(target_dir) and len(os.listdir(target_dir)) > 0:
            print(f"⏭️ {info['target_dir']}/ 已存在，跳过")
            continue

        # 下载
        if not os.path.exists(dest) or os.path.getsize(dest) < 1024:
            download_file(info["url"], dest, proxy=args.proxy)
        else:
            print(f"⏭️ {fname} 已下载，跳过")

        # 解压
        if not args.no_unzip and os.path.exists(dest):
            unzip_file(dest, args.root)

    print(f"\n✨ 全部完成！数据集路径: {args.root}")


if __name__ == "__main__":
    main()
