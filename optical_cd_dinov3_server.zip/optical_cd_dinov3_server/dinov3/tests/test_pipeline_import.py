"""Test that the core model pipeline imports without the test harness."""
import sys
import os

# Add the dinov3 package to the path
# The `dinov3` package lives at: <repo_root>/dinov3/
# This test file is at:           <repo_root>/dinov3/tests/
# We need to add <repo_root> to sys.path so that `import dinov3` works.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Test 1: Can we import SSLMetaArch_QH2?
try:
    from dinov3.train.model import SSLMetaArch_QH2
    print("✓ SSLMetaArch_QH2 imported successfully")
except Exception as e:
    print(f"✗ SSLMetaArch_QH2 import failed: {e}")

# Test 2: Can we import RS_vision_transformer? (class = FusionViT)
try:
    from dinov3.models.RS_vision_transformer import FusionViT, build_model_from_cfg_QH
    print(f"✓ FusionViT + build_model_from_cfg_QH imported successfully")
except Exception as e:
    print(f"✗ FusionViT import failed: {e}")

# Test 3: Can we import the models __init__.py (build_model)?
try:
    from dinov3.models import build_model_from_cfg as build_model
    print("✓ build_model_from_cfg imported successfully")
except Exception as e:
    print(f"✗ build_model_from_cfg import failed: {e}")

# Test 4: Can we import the layers?
try:
    from dinov3.layers import Mlp, SelfAttentionBlock
    print("✓ layers imported successfully (Mlp, SelfAttentionBlock)")
except Exception as e:
    print(f"✗ layers import failed: {e}")

print("\n=== All import tests completed ===")
