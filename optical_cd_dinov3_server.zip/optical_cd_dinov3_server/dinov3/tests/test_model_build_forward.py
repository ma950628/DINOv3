r"""
最小化测试脚本: 验证 SSLMetaArch_QH2 模型构建 & 前向传播

条件: PyTorch, OmegaConf 已安装, dinov3 包可导入

用法 (从项目根目录 dinov3/train/ 下运行):
    python ..\tests\test_model_build_forward.py
"""

import os
import sys
import logging
import types

import torch
import torch.nn as nn
from omegaconf import OmegaConf

# ═══════════════════════════════════════════════════════════════
# Phase 1 — 路径设置
# ═══════════════════════════════════════════════════════════════
_THIS_FILE = os.path.abspath(__file__)
_PROJECT_ROOT = os.path.dirname(os.path.dirname(_THIS_FILE))  # dinov3/ 目录
_DINOV3_TRAIN = os.path.join(_PROJECT_ROOT, 'train')          # train/ 子目录

# dinov3 包的父目录 (让 import dinov3 能工作)
_dinov3_parent = os.path.dirname(_PROJECT_ROOT)
if _dinov3_parent not in sys.path:
    sys.path.insert(0, _dinov3_parent)
# train 目录 (model.py, olmoearth_placeholder.py 所在)
if _DINOV3_TRAIN not in sys.path:
    sys.path.insert(0, _DINOV3_TRAIN)

# ═══════════════════════════════════════════════════════════════
# Phase 2 — dinov3.* 子模块 mock (model.py 模块级导入所需)
# ═══════════════════════════════════════════════════════════════

_mk = lambda name: sys.modules.setdefault(name, types.ModuleType(name))

# logging
logging.basicConfig(level=logging.INFO, format='%(name)s:%(levelname)s:%(message)s')

# 2.1 distributed
_dist = _mk('dinov3.distributed')
_dist.get_process_subgroup = lambda: None
_dist.get_default_process_group = lambda: None
_dist.get_world_size = lambda: 1
_dist.get_subgroup_size = lambda: 1
_dist.get_subgroup_rank = lambda: 0
_dist.is_subgroup_main_process = lambda: True

# 2.2 checkpointer
_ckpt = _mk('dinov3.checkpointer')
_ckpt.init_fsdp_model_from_checkpoint = lambda *a, **kw: None
_ckpt.find_latest_checkpoint = lambda *a, **kw: None
_ckpt.load_checkpoint = lambda *a, **kw: 0
_ckpt.save_checkpoint = lambda *a, **kw: None
_ckpt.keep_last_n_checkpoints = lambda *a, **kw: None
_ckpt.keep_checkpoint_copy = lambda *a, **kw: None
_ckpt.register_dont_save_hooks = lambda *a, **kw: None

# 2.3 configs
_cfg_mod = _mk('dinov3.configs')
_cfg_mod.get_default_config = lambda: OmegaConf.create()
_cfg_mod.setup_config = lambda args, **kw: OmegaConf.create()
_cfg_mod.setup_job = lambda **kw: None
_cfg_mod.setup_multidistillation = lambda args: OmegaConf.create()

# 2.4 data
_data = _mk('dinov3.data')
class _FakeDataAug:
    def __init__(self, *args, **kwargs): pass
    def __call__(self, img): return img
_data.DataAugmentationDINO = _FakeDataAug
_data.DatasetWithEnumeratedTargets = type('_DE', (), {})
_data.collate_data_and_cast = lambda *a, **kw: {}
_data.SamplerType = type('_ST', (), {})
_data.make_data_loader = lambda *a, **kw: None
_data.make_dataset = lambda *a, **kw: None
_data.CombinedDataLoader = type('_CDL', (), {})
_data.MaskingGenerator = type('_MG', (), {})
_data.make_classification_eval_transform = lambda *a, **kw: lambda x: x
_data.make_classification_train_transform = lambda *a, **kw: lambda x: x

# 2.5 layers.dino_head — 提供 DINOHead 备选
class _FakeDINOHead(nn.Module):
    def __init__(self, in_dim=384, out_dim=65536, hidden_dim=2048,
                 bottleneck_dim=256, nlayers=3, norm_last_layer=False, **kwargs):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim), nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim), nn.GELU(),
            nn.Linear(hidden_dim, bottleneck_dim),
        )
        self.last_layer = nn.utils.weight_norm(
            nn.Linear(bottleneck_dim, out_dim, bias=False)
        )
        self.last_layer.weight_g.data.fill_(1)
        if norm_last_layer:
            self.last_layer.weight_g.requires_grad_(False)
    def forward(self, x):
        x = self.net(x)
        x = nn.functional.normalize(x, dim=-1, p=2)
        return self.last_layer(x)
    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

# 2.6 loss
_loss_mod = _mk('dinov3.loss')
class _FakeDINOLoss(nn.Module):
    def __init__(self, out_dim=65536, n_students=None, **kwargs):
        super().__init__()
        self.register_buffer('center', torch.zeros(1, out_dim))
    def forward(self, student_logits, teacher_probs, ignore_diagonal=False):
        student_logits = student_logits.float()
        teacher_probs = teacher_probs.float()
        student_probs = torch.log_softmax(student_logits / 0.1, dim=-1)
        return -torch.sum(teacher_probs * student_probs, dim=-1).mean()
    def sinkhorn_knopp_teacher(self, teacher_output, teacher_temp=0.04):
        return torch.softmax(teacher_output.float() / teacher_temp, dim=-1)
    def init_weights(self): pass
class _FakeGramLoss(nn.Module):
    def forward(self, *args, **kwargs): return torch.tensor(0.0)
class _FakeKoLeoLoss(nn.Module):
    def forward(self, x): return torch.tensor(0.0)
_loss_mod.DINOLoss = _FakeDINOLoss
_loss_mod.GramLoss = _FakeGramLoss
_loss_mod.KoLeoLoss = _FakeKoLeoLoss
_loss_mod.KoLeoLossDistributed = _FakeKoLeoLoss
class _FakeiBOTPatchLoss(nn.Module):
    def __init__(self, out_dim=65536, **kwargs):
        super().__init__()
        self.center = torch.zeros(1, 1, out_dim)
    def forward(self, *args, **kwargs): return torch.tensor(0.0)
    def forward_masked(self, *args, **kwargs): return torch.tensor(0.0)
    def sinkhorn_knopp_teacher(self, teacher_output, teacher_temp=0.04,
                                n_masked_patches_tensor=None, n_iterations=3):
        return torch.softmax(teacher_output.float() / teacher_temp, dim=-1)
    def init_weights(self): pass
_loss_mod.iBOTPatchLoss = _FakeiBOTPatchLoss
class _FakeObjectLoss(nn.Module):
    def __init__(self, embed_dim=768, num_objects=64, **kwargs):
        super().__init__()
        self.object_queries = nn.Parameter(torch.randn(num_objects, embed_dim))
        self.register_buffer('center', torch.zeros(1, num_objects, 1))
    def forward(self, student_logits, teacher_probs):
        return torch.tensor(0.0)
    def compute_assignment(self, patch_tokens, object_queries):
        return torch.randn(patch_tokens.shape[0], len(object_queries), patch_tokens.shape[1])
    def sinkhorn_knopp_teacher(self, teacher_output, teacher_temp=0.04):
        return torch.softmax(teacher_output.float() / teacher_temp, dim=1)
    def init_weights(self): pass
    def update_center(self, teacher_logits): pass
    def apply_center_update(self): pass
_loss_mod.ObjectLoss = _FakeObjectLoss

# 2.7 train submodules
_tr_cos = _mk('dinov3.train.cosine_lr_scheduler')
_tr_cos.linear_warmup_cosine_decay = lambda *a, **kw: torch.ones(
    kw.get('total_iterations', 1000)
)
_tr_pg = _mk('dinov3.train.param_groups')
_tr_pg.fuse_params_groups = lambda groups: groups
_tr_pg.get_params_groups_with_decay_fsdp = lambda model, **kw: [
    {'params': model.parameters()}
]

# 2.8 fsdp
_fsdp = _mk('dinov3.fsdp.ac_compile_parallelize')
_fsdp.ac_compile_parallelize = lambda *a, **kw: None

# 2.9 logging
_dlog = _mk('dinov3.logging')
if not hasattr(_dlog, 'MetricLogger'):
    _dlog.MetricLogger = None
if not hasattr(_dlog, 'setup_logging'):
    _dlog.setup_logging = lambda **kw: None


logger = logging.getLogger("test")


def create_minimal_cfg():
    """创建一个最小配置，用于构建 SSLMetaArch_QH2 模型"""
    cfg = OmegaConf.create()
    cfg.MODEL = {"META_ARCHITECTURE": "SSLMetaArch_QH2"}
    cfg.student = {
        "arch": "vit_small",
        "patch_size": 14,
        "embed_dim": 384,
        "depth": 12,
        "num_heads": 6,
        "qkv_bias": True,
        "layerscale": None,
        "norm_layer": "layernorm",
        "ffn_layer": "mlp",
        "ffn_bias": True,
        "proj_bias": True,
        "n_storage_tokens": 0,
        "mask_k_bias": False,
        "untie_cls_and_patch_norms": False,
        "untie_global_and_local_cls_norm": False,
        "pos_embed_rope_base": 100.0,
        "pos_embed_rope_dtype": "fp32",
        "pos_embed_rope_normalize_coords": "separate",
        "drop_path_rate": 0.0,
        "resume_from_teacher_chkpt": False,
        "hr_seq_len": 256,
        "oe_seq_len": 256,
    }
    cfg.dino = {
        "head_n_prototypes": 65536,
        "head_bottleneck_dim": 256,
        "head_hidden_dim": 2048,
        "head_nlayers": 3,
        "head_norm_last_layer": False,
        "loss_weight": 1.0,
        "global_ignore_diagonal": False,
        "reweight_dino_local_loss": False,
    }
    cfg.ibot = {
        "head_n_prototypes": 65536,
        "head_bottleneck_dim": 256,
        "head_hidden_dim": 2048,
        "head_nlayers": 3,
        "separate_head": False,
    }
    cfg.crops = {
        "global_crops_scale": [0.32, 1.0],
        "local_crops_scale": [0.05, 0.32],
        "local_crops_number": 8,
        "global_crops_size": 224,
        "local_crops_size": 96,
        "gram_teacher_crops_size": None,
        "gram_teacher_no_distortions": False,
        "localcrops_subset_of_globalcrops": False,
        "share_color_jitter": True,
        "horizontal_flips": True,
        "rgb_mean": [0.485, 0.456, 0.406],
        "rgb_std": [0.229, 0.224, 0.225],
        "teacher_to_student_resolution_scale": 1.0,
    }
    cfg.optim = {
        "lr": 0.001, "min_lr": 1e-6, "epochs": 100,
        "warmup_epochs": 10, "weight_decay": 0.04, "weight_decay_end": 0.4,
        "adamw_beta1": 0.9, "adamw_beta2": 0.999,
        "layerwise_decay": 0.75, "patch_embed_lr_mult": 0.2,
        "dino_head_wd_multiplier": 1.0, "schedule_trunc_extra": 0,
        "freeze_last_layer_epochs": 1, "clip_grad": 3.0,
        "multi_tensor_optim": False, "scaling_rule": "none",
    }
    cfg.teacher = {
        "momentum_teacher": 0.996, "final_momentum_teacher": 1.0,
        "teacher_temp": 0.04, "warmup_teacher_temp": 0.04,
        "warmup_teacher_temp_epochs": 0,
    }
    cfg.train = {
        "OFFICIAL_EPOCH_LENGTH": 1250, "batch_size_per_gpu": 4,
        "num_workers": 2, "dataset_path": "ImageNet:split=TRAIN",
        "output_dir": "./output", "seed": 0, "cache_dataset": True,
        "sharded_eval_checkpoint": False,
    }
    cfg.checkpointing = {"period": 5000, "max_to_keep": 5}
    cfg.evaluation = {"eval_period_iterations": 0}
    cfg.compute_precision = {"param_dtype": "fp32", "sharding_strategy": "NO_SHARD"}
    cfg.distillation = {"enabled": False}
    cfg.gram = {"use_loss": False}
    return cfg


def _load_olmoearth_placeholder():
    """安全加载 olmoearth_placeholder，避免触发额外的导入链"""
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "olmoearth_placeholder",
        os.path.join(_DINOV3_TRAIN, "olmoearth_placeholder.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.Olmoearth


# ═══════════════════════════════════════════════════════════════
# 共享的全局缓存: 避免重复构建模型 (meta device 构建很快，但保持一致性)
# ═══════════════════════════════════════════════════════════════
_model_cache = None
_cfg_cache = None


def _get_or_build_model_and_cfg():
    """构建 SSLMetaArch_QH2 模型 (带缓存)，返回 (model, cfg)。"""
    global _model_cache, _cfg_cache
    if _model_cache is not None:
        return _model_cache, _cfg_cache

    import dinov3.models.vision_transformer as _vt
    import dinov3.models as _dm

    def _mock_build_model_from_cfg(cfg, only_teacher=False):
        student = _vt.vit_small(
            img_size=518, patch_size=14,
            pos_embed_rope_base=100.0, pos_embed_rope_dtype="fp32",
            pos_embed_rope_normalize_coords="separate",
        )
        teacher = _vt.vit_small(
            img_size=518, patch_size=14,
            pos_embed_rope_base=100.0, pos_embed_rope_dtype="fp32",
            pos_embed_rope_normalize_coords="separate",
        )
        embed_dim = 384
        if only_teacher:
            return teacher, embed_dim
        return student, teacher, embed_dim

    _dm.build_model_from_cfg = _mock_build_model_from_cfg

    from model import SSLMetaArch_QH2

    cfg = create_minimal_cfg()
    logger.info("构建模型 (meta device)...")
    with torch.device("meta"):
        model = SSLMetaArch_QH2(cfg)

    _model_cache = model
    _cfg_cache = cfg
    return model, cfg


def _check_cuda_usable():
    """检查 CUDA 是否真正可用（不仅可用，而且当前 PyTorch 兼容 GPU 计算能力）。"""
    if not torch.cuda.is_available():
        return False
    try:
        t = torch.zeros(1, device='cuda')
        t = t + 1
        del t
        torch.cuda.synchronize()
        return True
    except Exception as e:
        logger.warning(f"CUDA 不可用 (兼容性问题): {e}")
        return False


def _get_device():
    """返回可用的计算设备: CUDA 如果可用，否则 CPU。"""
    if _check_cuda_usable():
        return torch.device('cuda')
    else:
        logger.info("使用 CPU 作为计算设备")
        return torch.device('cpu')


def _materialize_model(model, device):
    """将 meta device 上的模型参数实例化到指定设备，返回设备上的模型。"""
    def _materialize(t):
        if t.device.type == 'meta':
            return torch.empty_like(t, device=device)
        return t
    model._apply(_materialize)
    if device.type != 'meta':
        model = model.to(device)
    return model


# ═══════════════════════════════════════════════════════════════
# 测试用例
# ═══════════════════════════════════════════════════════════════

def test_olmoearth_standalone():
    """测试 1: Olmoearth 占位模块独立运行"""
    logger.info("=" * 60)
    logger.info("测试 1: Olmoearth 占位模块独立运行")
    logger.info("=" * 60)

    Olmoearth = _load_olmoearth_placeholder()
    olmo = Olmoearth(embed_dim=384, patch_size=4)
    B, H, W = 2, 16, 16
    h5_data = {
        "s2": torch.randn(B, H, W, 3, 4),
        "s1": torch.randn(B, H, W, 2, 2),
        "ls": torch.randn(B, H, W, 1, 6),
    }
    with torch.no_grad():
        out = olmo(h5_data)
    for k in ["s2", "s1", "ls"]:
        feat = out[k]["features"]
        cls_tok = out[k]["cls_token"]
        assert feat.shape[0] == B, f"{k} features batch mismatch"
        assert feat.shape[-1] == 384, f"{k} features dim mismatch"
        assert cls_tok.shape[0] == B, f"{k} cls_token batch mismatch"
        assert cls_tok.shape[-1] == 384, f"{k} cls_token dim mismatch"
        logger.info(f"  {k}: features={list(feat.shape)}, cls_token={list(cls_tok.shape)} ✓")
    logger.info("测试 1 通过 ✓\n")


def test_model_build():
    """测试 2: 模型构建"""
    logger.info("=" * 60)
    logger.info("测试 2: SSLMetaArch_QH2 模型构建")
    logger.info("=" * 60)

    model, cfg = _get_or_build_model_and_cfg()
    total_params = sum(p.numel() for p in model.parameters())
    logger.info(f"模型总参数: {total_params:,}")
    logger.info("测试 2 通过 ✓\n")


def test_forward_pass():
    """测试 3: 前向传播 (forward_backward) — 支持 CPU/GPU 自适应"""
    logger.info("=" * 60)
    logger.info("测试 3: 前向传播 forward_backward")
    logger.info("=" * 60)

    model, cfg = _get_or_build_model_and_cfg()
    device = _get_device()
    model = _materialize_model(model, device)

    # 初始化权重 (CPU 上只做轻量 kaiming 初始化)
    try:
        model.init_weights()
    except Exception as e:
        logger.warning(f"init_weights 失败: {e}, 使用 kaiming 初始化")
        for m in model.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.Conv2d, nn.Conv1d)):
                nn.init.kaiming_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    model.train()

    B = 2
    img_size = cfg.crops.global_crops_size

    hr_image_student = torch.randn(B, 3, img_size, img_size, device=device)
    hr_image_teacher = torch.randn(B, 3, img_size, img_size, device=device)
    h5_data = {
        "s2": torch.randn(B, 16, 16, 3, 4, device=device),
        "s1": torch.randn(B, 16, 16, 2, 2, device=device),
        "ls": torch.randn(B, 16, 16, 1, 6, device=device),
    }
    data = {
        "hr_image_student": hr_image_student,
        "hr_image_teacher": hr_image_teacher,
        "h5_data": h5_data,
    }

    logger.info(f"HR image: {list(hr_image_student.shape)}, device={device}")
    logger.info(f"执行 forward_backward ({device.type})...")
    loss, metrics = model.forward_backward(data, teacher_temp=0.04, iteration=0)
    logger.info(f"Loss: {loss.item():.6f}")
    logger.info(f"Metrics: {metrics}")
    logger.info("测试 3 通过 ✓ (forward_backward 成功)\n")


def test_get_outputs():
    """测试 4: 独立获取 teacher/student 输出 — 验证 v6 输出结构"""
    logger.info("=" * 60)
    logger.info("测试 4: get_teacher_output / get_student_output")
    logger.info("=" * 60)

    model, cfg = _get_or_build_model_and_cfg()
    device = _get_device()
    model = _materialize_model(model, device)
    model.eval()

    B = 1
    hr_image = torch.randn(B, 3, cfg.crops.global_crops_size,
                           cfg.crops.global_crops_size, device=device)
    h5_data = {
        "s2": torch.randn(B, 16, 16, 3, 4, device=device),
        "s1": torch.randn(B, 16, 16, 2, 2, device=device),
        "ls": torch.randn(B, 16, 16, 1, 6, device=device),
    }

    with torch.no_grad():
        t_out = model.get_teacher_output(hr_image, h5_data)
        s_out = model.get_student_output(hr_image, h5_data)

    # 验证 teacher 输出键 (v6 结构)
    assert 'hr' in t_out, "teacher 缺少 'hr'"
    assert 'hr_ibot_centered' in t_out, "teacher 缺少 'hr_ibot_centered'"
    assert 'hr_patch_spatial' in t_out, "teacher 缺少 'hr_patch_spatial'"
    assert 'fusion_cls_centered' in t_out, "teacher 缺少 'fusion_cls_centered'"
    assert 'fusion_patch_centered' in t_out, "teacher 缺少 'fusion_patch_centered'"

    # 验证 student 输出键 (v6 结构)
    assert 'hr' in s_out, "student 缺少 'hr'"
    assert 'hr_ibot_after_head' in s_out, "student 缺少 'hr_ibot_after_head'"
    assert 'fusion_cls_after_head' in s_out, "student 缺少 'fusion_cls_after_head'"
    assert 'fusion_patch_after_head' in s_out, "student 缺少 'fusion_patch_after_head'"

    logger.info(f"Teacher HR cls_centered shape: {list(t_out['hr']['cls_centered'].shape)}")
    logger.info(f"Teacher hr_ibot_centered shape: {list(t_out['hr_ibot_centered'].shape)}")
    logger.info(f"Teacher fusion_cls_centered shape: {list(t_out['fusion_cls_centered'].shape)}")
    logger.info(f"Teacher fusion_patch_centered shape: {list(t_out['fusion_patch_centered'].shape)}")
    logger.info(f"Student HR cls_after_head shape: {list(s_out['hr']['cls_after_head'].shape)}")
    logger.info(f"Student hr_ibot_after_head shape: {list(s_out['hr_ibot_after_head'].shape)}")
    logger.info(f"Student fusion_cls_after_head shape: {list(s_out['fusion_cls_after_head'].shape)}")
    logger.info(f"Student fusion_patch_after_head shape: {list(s_out['fusion_patch_after_head'].shape)}")

    assert t_out['hr']['cls_centered'].shape[0] == B
    assert s_out['hr']['cls_after_head'].shape[0] == B
    assert t_out['fusion_cls_centered'].shape[0] == B
    # fusion_cls_after_head is per-patch: [hr_seq_len, prototypes]
    assert s_out['fusion_cls_after_head'].shape[-1] == 65536

    logger.info("测试 4 通过 ✓\n")


# ═══════════════════════════════════════════════════════════════
# 主入口
# ═══════════════════════════════════════════════════════════════

def main():
    """主测试入口 —— 所有测试函数均无参数，main 只负责顺序调用和错误收集。"""
    logger.info("=" * 60)
    logger.info("SkySense++ Model Build & Forward Test")
    logger.info(f"PyTorch version: {torch.__version__}")
    logger.info(f"Python: {sys.version}")
    logger.info("=" * 60)

    # 定义测试列表: (name, func, skip_reason_or_None)
    tests = [
        ("测试 1: Olmoearth 占位模块", test_olmoearth_standalone, None),
        ("测试 2: 模型构建", test_model_build, None),
        ("测试 3: 前向传播", test_forward_pass, None),
        ("测试 4: get_*_output", test_get_outputs, None),
    ]

    passed = 0
    failed = 0
    skipped = 0

    for name, func, skip_reason in tests:
        if skip_reason:
            logger.info(f"跳过 {name}: {skip_reason}")
            skipped += 1
            continue
        try:
            logger.info(f"--- 运行 {name} ---")
            func()
            passed += 1
        except Exception as e:
            logger.error(f"{name} 失败: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    logger.info("=" * 60)
    total = passed + failed + skipped
    logger.info(f"结果: {passed}/{total} 通过, {failed} 失败, {skipped} 跳过")
    if failed == 0:
        logger.info("所有测试通过 ✓✓✓")
    else:
        logger.error(f"{failed} 个测试失败 ✗")
    logger.info("=" * 60)

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    exit(main())
