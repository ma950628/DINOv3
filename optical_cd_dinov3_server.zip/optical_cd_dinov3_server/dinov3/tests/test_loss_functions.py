r"""
DINOv3 损失函数端到端梯度测试
================================
必须从项目根目录运行，以避免 dinov3/logging/ 遮盖标准库 logging 模块：

    cd <项目根目录>  (包含 dinov3/ 的目录)
    python -m dinov3.tests.test_loss_functions

测试覆盖范围：
  1. DINOLoss(768)         — 直接 CE 768 维，Sinkhorn-Knopp + 中心向量 + EMA
  2. DINOLoss(65536)       — 65536 原型（经 DINOHead 投影）
  3. iBOTPatchLoss(768)    — 直接 CE 768 维 patch 损失
  4. iBOTPatchLoss(65536)  — 65536 原型（经 iBOTHead 投影）
  5. ObjectLoss(N=16,64)   — 离散瓶颈 object-level 蒸馏，归一化内积 + SK 中心化
  6. 端到端梯度：六种损失组合 → 反向传播验证所有可训练参数获得梯度
  7. 768 维 与 65536 维 维度选择验证
  8. 中心向量动量更新（含 object_loss center）
  9. Sinkhorn-Knopp 输出概率性质（DINO/iBOT/Object 各自的列归一化约束）

关键说明：教师输出必须先经过 L2 归一化，再送入 Sinkhorn-Knopp，
与真实训练流程保持一致（DINOHead 会做 L2 归一化）。
原始 randn 直接做 exp(x/0.04) 会因数值溢出变为 inf。
"""

import sys
import os
import math

import pytest
from collections import OrderedDict

import torch
import torch.nn.functional as F
from torch import nn

# ── 禁用 torch.compile（避免 iBOT SinkhornKnoppTeacher 在无 C++ 编译器的 Windows 上崩溃）────
import torch._dynamo
torch._dynamo.config.disable = True

# ── 确保项目根目录在 sys.path 中 ────────────────────────
_PROJ_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..")
)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

# 导入实际损失函数模块
from dinov3.loss import DINOLoss, iBOTPatchLoss, ObjectLoss


# ══════════════════════════════════════════════════════════
# 辅助函数
# ══════════════════════════════════════════════════════════

def _构建投影层(输入维度: int, 输出维度: int) -> nn.Linear:
    """模拟 DINOHead 投影（简化的 weight_norm + L2_norm）。"""
    proj = nn.Linear(输入维度, 输出维度)
    nn.init.trunc_normal_(proj.weight, std=0.02)
    nn.init.zeros_(proj.bias)
    return proj


def _构建学生投影层(输入维度: int, 输出维度: int) -> nn.Linear:
    """模拟学生端投影头，将 backbone 输出变换到目标维度。"""
    proj = nn.Linear(输入维度, 输出维度)
    nn.init.trunc_normal_(proj.weight, std=0.02)
    nn.init.zeros_(proj.bias)
    return proj


def _随机L2归一化张量(维度元组):
    """生成 L2 归一化的随机张量（模拟 backbone 输出）。"""
    return F.normalize(torch.randn(维度元组), dim=-1)


# ══════════════════════════════════════════════════════════
# 1. DINO & iBOT 基础功能测试
# ══════════════════════════════════════════════════════════

class TestDINOLoss基础功能:
    """DINOLoss 基础功能测试。"""

    @pytest.mark.parametrize("输出维度", [768, 65536])
    def test_构造(self, 输出维度):
        """验证 DINOLoss 正确构造，中心向量维度匹配。"""
        损失函数 = DINOLoss(输出维度)
        assert 损失函数.center.shape == (1, 输出维度), \
            f"中心向量形状应为 (1, {输出维度})，实际为 {损失函数.center.shape}"
        assert 损失函数.student_temp == 0.1, "学生温度参数应为 0.1"
        assert 损失函数.center_momentum == 0.9, "中心向量动量应为 0.9"

    @pytest.mark.parametrize("输出维度", [768, 65536])
    def test_前向传播_无梯度教师(self, 输出维度):
        """forward 方法应输出标量损失值。"""
        损失函数 = DINOLoss(输出维度)
        B, C = 4, 1  # 1 个教师裁剪，1 个学生裁剪
        # 使用 softmax 模拟 SK 概率
        教师概率 = torch.softmax(_随机L2归一化张量((C, B, 输出维度)) / 0.04, dim=-1)
        学生logits = torch.randn(C, B, 输出维度, requires_grad=True)

        损失值 = 损失函数(学生logits, 教师概率)
        assert 损失值.ndim == 0, f"损失值应为标量，实际维度为 {损失值.ndim}"
        assert 损失值.item() > 0, f"损失值应大于 0，实际为 {损失值.item()}"

    @pytest.mark.parametrize("输出维度", [768, 65536])
    def test_SinkhornKnopp概率和为1(self, 输出维度):
        """Sinkhorn-Knopp 输出的每一行概率必须求和为 1。

        关键：输入必须是 L2 归一化的（真实的 backbone 输出）。
        对于 65536 维，B << K，因此放宽容差。
        """
        损失函数 = DINOLoss(输出维度)
        B = 1024 if 输出维度 == 768 else 128
        # L2 归一化的教师输出（模仿 DINOHead）
        教师输出 = _随机L2归一化张量((B, 输出维度))
        概率矩阵 = 损失函数.sinkhorn_knopp_teacher(教师输出, teacher_temp=0.04)
        
        assert not 概率矩阵.isnan().any(), f"维度={输出维度} 时 SK 输出出现 NaN"
        行求和 = 概率矩阵.sum(dim=-1)
        容差 = 1e-5 if 输出维度 == 768 else 1e-3
        assert torch.allclose(行求和, torch.ones_like(行求和), atol=容差), \
            f"维度={输出维度} 时概率和不为1，最大偏差={(行求和 - 1).abs().max().item():.2e}"

    @pytest.mark.parametrize("输出维度", [768, 65536])
    def test_中心向量更新_降低损失(self, 输出维度):
        """EMA 中心向量应在稳定数据上收敛。"""
        损失函数 = DINOLoss(输出维度, student_temp=0.1, center_momentum=0.9)
        损失函数.init_weights()
        教师概率 = torch.softmax(_随机L2归一化张量((1, 4, 输出维度)) / 0.04, dim=-1)
        学生层 = nn.Linear(输出维度, 输出维度)
        torch.nn.init.eye_(学生层.weight)
        torch.nn.init.zeros_(学生层.bias)

        损失记录 = []
        优化器 = torch.optim.SGD(学生层.parameters(), lr=0.1)
        for _ in range(5):
            原始输出 = 学生层(torch.randn(1, 4, 输出维度))
            损失值 = 损失函数(原始输出, 教师概率)
            优化器.zero_grad()
            损失值.backward()
            优化器.step()
            损失函数.update_center(教师概率.squeeze(0))
            损失记录.append(损失值.item())
        assert all(math.isfinite(v) for v in 损失记录), f"损失值出现非有限值: {损失记录}"


class TestiBOTPatchLoss基础功能:
    """iBOTPatchLoss 基础功能测试。"""

    @pytest.mark.parametrize("输出维度", [768, 65536])
    def test_构造(self, 输出维度):
        """验证 iBOTPatchLoss 正确构造。"""
        损失函数 = iBOTPatchLoss(输出维度)
        assert 损失函数.center.shape == (1, 1, 输出维度), \
            f"中心向量形状应为 (1, 1, {输出维度})，实际为 {损失函数.center.shape}"

    @pytest.mark.parametrize("输出维度", [768, 65536])
    def test_前向传播_全部patch(self, 输出维度):
        """forward() 对所有 patch 计算损失。"""
        损失函数 = iBOTPatchLoss(输出维度)
        B, P = 4, 196
        # 关键：教师必须是 softmax 概率，不能是原始/L2 特征
        教师概率 = torch.softmax(_随机L2归一化张量((B, P, 输出维度)) / 0.04, dim=-1)
        学生输出 = torch.randn(B, P, 输出维度, requires_grad=True)
        掩码 = torch.ones(B, P, dtype=torch.bool)

        损失值 = 损失函数(学生输出, 教师概率, 掩码)
        assert 损失值.ndim == 0, f"损失值应为标量，实际维度为 {损失值.ndim}"
        assert 损失值.item() > 0, f"损失值应大于 0，实际为 {损失值.item()}"

    @pytest.mark.parametrize("输出维度", [768, 65536])
    def test_SinkhornKnopp概率和为1(self, 输出维度):
        """iBOT Sinkhorn-Knopp 输出的每一行概率必须求和为 1。

        已修复上游 bug：ibot_patch_loss.py 第 35 行的 dist.all_reduce(B)
        原先缺少 `if dist.is_initialized()` 守卫，在单机非分布式环境下会崩溃。
        修复后增加了守卫，单机可正常调用 SK。
        """
        损失函数 = iBOTPatchLoss(输出维度)
        if 输出维度 == 768:
            N = 1024
        else:
            N = 256  # 65536 维用小批量
        教师输出 = _随机L2归一化张量((N, 输出维度))
        n_tokens = torch.tensor(N)
        概率矩阵 = 损失函数.sinkhorn_knopp_teacher(
            教师输出, teacher_temp=0.04, n_masked_patches_tensor=n_tokens
        )
        
        if 概率矩阵.isnan().any():
            nan_count = 概率矩阵.isnan().sum().item()
            raise AssertionError(
                f"维度={输出维度} 时 SK 输出出现 {nan_count} 个 NaN 值"
            )
        
        行求和 = 概率矩阵.sum(dim=-1)
        容差 = 1e-5 if 输出维度 == 768 else 1e-3
        最大偏差 = (行求和 - 1).abs().max().item()
        assert torch.allclose(行求和, torch.ones_like(行求和), atol=容差), \
            f"维度={输出维度} 时概率和不为1，最大偏差={最大偏差:.2e}"

    @pytest.mark.parametrize("输出维度", [768, 65536])
    def test_中心向量更新(self, 输出维度):
        """中心向量更新后应变为非零。"""
        损失函数 = iBOTPatchLoss(输出维度)
        损失函数.init_weights()
        assert 损失函数.center.abs().max().item() < 1e-6, \
            "初始化后中心向量应接近零"
        令牌 = _随机L2归一化张量((8, 196, 输出维度))
        损失函数.update_center(令牌)
        损失函数.apply_center_update()
        assert 损失函数.center.abs().max().item() > 0, \
            "中心向量更新后不应全为零"


# ══════════════════════════════════════════════════════════
# 2. Object Loss 基础功能测试
# ══════════════════════════════════════════════════════════

class TestObjectLoss基础功能:
    """ObjectLoss 基础功能测试 — 离散瓶颈物体级蒸馏损失。

    Object Loss 通过可学习的 Object Queries 对 patch tokens 进行软分组，
    在 Teacher 端使用 Sinkhorn-Knopp 中心化产生软标签，与 DINO/iBOT 损失
    遵循相同的范式，是 v7 新增的核心损失组件。
    """

    @pytest.mark.parametrize("num_objects", [16, 64])
    def test_构造(self, num_objects):
        """验证 ObjectLoss 正确构造，object_queries 和 center 维度匹配。"""
        损失函数 = ObjectLoss(embed_dim=768, num_objects=num_objects)
        assert 损失函数.object_queries.shape == (num_objects, 768), \
            f"object_queries 形状应为 ({num_objects}, 768)，实际为 {损失函数.object_queries.shape}"
        assert 损失函数.center.shape == (1, num_objects, 1), \
            f"center 形状应为 (1, {num_objects}, 1)，实际为 {损失函数.center.shape}"
        assert 损失函数.student_temp == 0.1
        assert 损失函数.center_momentum == 0.9

    @pytest.mark.parametrize("num_objects", [16, 64])
    def test_计算分配矩阵(self, num_objects):
        """compute_assignment 输出形状应为 [B, num_objects, P]。"""
        损失函数 = ObjectLoss(embed_dim=768, num_objects=num_objects)
        B, P = 4, 196
        patch_tokens = _随机L2归一化张量((B, P, 768))
        assignment = 损失函数.compute_assignment(patch_tokens, 损失函数.object_queries)
        assert assignment.shape == (B, num_objects, P), \
            f"分配矩阵形状应为 ({B}, {num_objects}, {P})，实际为 {assignment.shape}"

    @pytest.mark.parametrize("num_objects", [16, 64])
    def test_前向传播_输出标量损失(self, num_objects):
        """forward 方法应输出大于 0 的标量损失值。"""
        损失函数 = ObjectLoss(embed_dim=768, num_objects=num_objects)
        B, P = 4, 196

        # 学生 logits: compute_assignment 输出
        student_patch = _随机L2归一化张量((B, P, 768))
        student_logits = 损失函数.compute_assignment(student_patch, 损失函数.object_queries)

        # 教师概率: Sinkhorn-Knopp 输出
        teacher_patch = _随机L2归一化张量((B, P, 768))
        teacher_logits = 损失函数.compute_assignment(teacher_patch, 损失函数.object_queries)
        teacher_probs = 损失函数.sinkhorn_knopp_teacher(teacher_logits, teacher_temp=0.04)

        损失值 = 损失函数(student_logits, teacher_probs)
        assert 损失值.ndim == 0, f"损失值应为标量，实际维度为 {损失值.ndim}"
        assert 损失值.item() > 0, f"损失值应大于 0，实际为 {损失值.item()}"
        assert math.isfinite(损失值.item()), f"损失值不是有限值: {损失值.item()}"

    @pytest.mark.parametrize("num_objects", [16, 64])
    def test_反向传播_梯度有效(self, num_objects):
        """ObjectLoss 反向传播应产生有效的非 NaN 梯度。"""
        损失函数 = ObjectLoss(embed_dim=768, num_objects=num_objects)
        B, P = 4, 64

        student_patch = _随机L2归一化张量((B, P, 768)).requires_grad_(True)
        student_logits = 损失函数.compute_assignment(student_patch, 损失函数.object_queries)

        teacher_patch = _随机L2归一化张量((B, P, 768))
        with torch.no_grad():
            teacher_logits = 损失函数.compute_assignment(teacher_patch, 损失函数.object_queries)
            teacher_probs = 损失函数.sinkhorn_knopp_teacher(teacher_logits, teacher_temp=0.04)

        损失值 = 损失函数(student_logits, teacher_probs)
        损失值.backward()

        assert student_patch.grad is not None, "学生 patch tokens 应有梯度"
        assert not student_patch.grad.isnan().any(), "学生 patch tokens 梯度含 NaN"
        assert 损失函数.object_queries.grad is not None, "object_queries 应有梯度"
        assert not 损失函数.object_queries.grad.isnan().any(), "object_queries 梯度含 NaN"

    @pytest.mark.parametrize("num_objects", [16, 64])
    def test_SinkhornKnopp概率性质(self, num_objects):
        """Sinkhorn-Knopp 输出每一列应近似求和为 1（沿 object 维度的分配概率）。"""
        损失函数 = ObjectLoss(embed_dim=768, num_objects=num_objects)
        B, P = 8, 64

        teacher_patch = _随机L2归一化张量((B, P, 768))
        teacher_logits = 损失函数.compute_assignment(teacher_patch, 损失函数.object_queries)
        teacher_probs = 损失函数.sinkhorn_knopp_teacher(teacher_logits, teacher_temp=0.04)

        assert not teacher_probs.isnan().any(), "SK 输出含 NaN"
        assert (teacher_probs >= 0).all(), "SK 输出含负数"
        # 每个 patch 对 object queries 的分配概率之和应约为 1
        列求和 = teacher_probs.sum(dim=1)  # [B, P] — sum over object dim
        assert torch.allclose(列求和, torch.ones_like(列求和), atol=1e-3), \
            f"每列 (patch) 概率和不为 1，最大偏差={(列求和 - 1).abs().max().item():.2e}"

    @pytest.mark.parametrize("num_objects", [16, 64])
    def test_中心向量更新(self, num_objects):
        """中心向量 update + apply 后应变为非零。"""
        损失函数 = ObjectLoss(embed_dim=768, num_objects=num_objects)
        损失函数.init_weights()
        assert 损失函数.center.abs().max().item() < 1e-6, \
            "初始化后 center 应接近零"

        B, P = 8, 64
        teacher_patch = _随机L2归一化张量((B, P, 768))
        teacher_logits = 损失函数.compute_assignment(teacher_patch, 损失函数.object_queries)

        损失函数.update_center(teacher_logits)
        损失函数.apply_center_update()
        assert 损失函数.center.abs().max().item() > 0, \
            "center 更新后不应全为零"


# ══════════════════════════════════════════════════════════
# 3. 维度选择验证
# ══════════════════════════════════════════════════════════

class Test维度选择:
    """验证 DINOLoss 和 iBOTPatchLoss 都支持 768 维和 65536 维。"""

    @pytest.mark.parametrize("维度", [768, 65536])
    def test_DINO维度支持(self, 维度):
        """DINOLoss 在两种维度下都应正常计算并产生有效梯度。"""
        损失函数 = DINOLoss(维度)
        B = 8
        教师概率 = torch.softmax(_随机L2归一化张量((1, B, 维度)) / 0.04, dim=-1)
        学生logits = torch.randn(1, B, 维度, requires_grad=True)
        
        损失值 = 损失函数(学生logits, 教师概率)
        损失值.backward()
        
        assert 损失值.item() > 0, f"维度={维度}: 损失值应大于 0"
        assert 学生logits.grad is not None, f"维度={维度}: 学生 logits 没有梯度"
        assert not 学生logits.grad.isnan().any(), f"维度={维度}: 梯度出现 NaN"

    @pytest.mark.parametrize("维度", [768, 65536])
    def test_iBOT维度支持(self, 维度):
        """iBOTPatchLoss 在两种维度下都应正常计算并产生有效梯度。"""
        损失函数 = iBOTPatchLoss(维度)
        B, P = 4, 196
        # 关键：forward() 的教师输入必须是 softmax 概率
        教师概率 = torch.softmax(_随机L2归一化张量((B, P, 维度)) / 0.04, dim=-1)
        学生输出 = torch.randn(B, P, 维度, requires_grad=True)
        掩码 = torch.ones(B, P, dtype=torch.bool)
        
        损失值 = 损失函数(学生输出, 教师概率, 掩码)
        损失值.backward()
        
        assert 损失值.item() > 0, f"维度={维度}: 损失值应大于 0"
        assert 学生输出.grad is not None, f"维度={维度}: 学生输出没有梯度"
        assert not 学生输出.grad.isnan().any(), f"维度={维度}: 梯度出现 NaN"

    def test_两种维度损失值在合理范围(self):
        """768 维和 65536 维的损失值应在相近数量级范围内。"""
        损失记录 = {}
        for 维度 in [768, 65536]:
            dl = DINOLoss(维度)
            tp = torch.softmax(_随机L2归一化张量((1, 8, 维度)) / 0.04, dim=-1)
            sl = torch.randn(1, 8, 维度)
            损失记录[维度] = dl(sl, tp).item()
        
        比值 = max(损失记录.values()) / min(损失记录.values())
        assert 0.1 < 比值 < 10, \
            f"损失比值 {比值:.1f} 超出预期范围 [0.1, 10]: {损失记录}"


# ══════════════════════════════════════════════════════════
# 4. 端到端梯度流（模拟 model.py 中 forward_backward）
# ══════════════════════════════════════════════════════════

class Test端到端梯度流:
    """
    验证六种损失组合的完整梯度流。
    模拟 model.py 中 forward_backward 的逻辑：
      HR DINO + HR iBOT + Fusion DINO + Fusion iBOT + HR Object + Fusion Object
    """

    @pytest.mark.parametrize("使用直接CE", [True, False])
    def test_六种损失端到端梯度(self, 使用直接CE):
        """
        构建完整损失图并验证所有可训练参数获得梯度。
        使用直接CE=True  -> 768 维直接 CE（学生投影头 + SK 教师）
        使用直接CE=False -> 65536 原型（经投影头）
        """
        K = 768 if 使用直接CE else 65536
        B, P = 4, 196
        T_eff = 32
        Kobj = 64

        # ── 损失模块 ──
        dino损失 = DINOLoss(K, student_temp=0.1)
        ibot损失 = iBOTPatchLoss(K, student_temp=0.1)
        融合dino损失 = DINOLoss(K, student_temp=0.1)
        融合ibot损失 = iBOTPatchLoss(K, student_temp=0.1)
        hr_object损失 = ObjectLoss(embed_dim=768, num_objects=Kobj)
        fusion_object损失 = ObjectLoss(embed_dim=768, num_objects=Kobj)

        # ── 学生投影头（可训练 — 始终存在）──
        学生投影_hr_dino = _构建学生投影层(768, K)
        学生投影_hr_ibot = _构建学生投影层(768, K)
        学生投影_融合_dino = _构建学生投影层(768, K)
        学生投影_融合_ibot = _构建学生投影层(768, K)

        # ── 教师投影头（仅在 65536 模式时使用）──
        教师投影_dino = None if 使用直接CE else _构建投影层(768, K)
        教师投影_ibot = None if 使用直接CE else _构建投影层(768, K)
        教师投影_融合_dino = None if 使用直接CE else _构建投影层(768, K)
        教师投影_融合_ibot = None if 使用直接CE else _构建投影层(768, K)

        # ── 收集学生侧（期望有梯度）和教师侧（期望无梯度）参数 ──
        学生参数列表: list[nn.Parameter] = []
        for 投影 in [学生投影_hr_dino, 学生投影_hr_ibot,
                     学生投影_融合_dino, 学生投影_融合_ibot]:
            学生参数列表.extend(投影.parameters())
        # ObjectLoss 的可学习参数也要包含
        学生参数列表.append(hr_object损失.object_queries)
        学生参数列表.append(fusion_object损失.object_queries)

        教师参数列表: list[nn.Parameter] = []
        for 投影 in [教师投影_dino, 教师投影_ibot, 教师投影_融合_dino, 教师投影_融合_ibot]:
            if 投影 is not None:
                教师参数列表.extend(投影.parameters())

        # ── 1. HR DINO 损失 ──
        hr_cls = _随机L2归一化张量((B, 768)).requires_grad_(True)
        hr_cls_学生投影 = 学生投影_hr_dino(hr_cls).unsqueeze(0)  # (1, B, K)
        教师原始 = _随机L2归一化张量((B, 768))
        if 教师投影_dino:
            教师原始 = 教师投影_dino(教师原始.unsqueeze(0)).squeeze(0).detach()
        教师概率_hr = dino损失.sinkhorn_knopp_teacher(
            教师原始, teacher_temp=0.04
        ).unsqueeze(0)
        hr_dino损失值 = dino损失(hr_cls_学生投影, 教师概率_hr)

        # ── 2. HR iBOT 损失 ──
        hr_patch_学生 = _随机L2归一化张量((B, P, 768)).requires_grad_(True)
        hr_patch_学生投影 = 学生投影_hr_ibot(hr_patch_学生)  # (B, P, K)
        hr_patch_教师 = _随机L2归一化张量((B, P, 768))
        if 教师投影_ibot:
            hr_patch_教师原始 = 教师投影_ibot(hr_patch_教师).detach()
        else:
            hr_patch_教师原始 = hr_patch_教师

        教师ibot_扁平 = torch.softmax(
            hr_patch_教师原始 / 0.04, dim=-1
        )
        hr_掩码 = torch.ones(B, P, dtype=torch.bool)
        hr_ibot损失值 = ibot损失(
            hr_patch_学生投影, 教师ibot_扁平, hr_掩码
        )

        # ── 3. 融合 DINO 损失 ──
        融合_cls = _随机L2归一化张量((B, 768)).requires_grad_(True)
        融合_cls_学生投影 = 学生投影_融合_dino(融合_cls).unsqueeze(0)
        融合_教师原始 = _随机L2归一化张量((B, 768))
        if 教师投影_融合_dino:
            融合_教师原始 = 教师投影_融合_dino(融合_教师原始.unsqueeze(0)).squeeze(0).detach()
        融合_教师概率 = 融合dino损失.sinkhorn_knopp_teacher(
            融合_教师原始, teacher_temp=0.04
        ).unsqueeze(0)
        融合_教师池化 = 融合_教师概率.reshape(1, B, K).mean(
            dim=0, keepdim=True
        )
        融合dino损失值 = 融合dino损失(
            融合_cls_学生投影, 融合_教师池化
        )

        # ── 4. 融合 iBOT 损失 ──
        融合_patch_学生 = _随机L2归一化张量((B, T_eff, 768)).requires_grad_(True)
        融合_patch_学生投影 = 学生投影_融合_ibot(融合_patch_学生)
        融合_patch_教师 = _随机L2归一化张量((B, T_eff, 768))
        if 教师投影_融合_ibot:
            融合_patch_教师原始 = 教师投影_融合_ibot(融合_patch_教师).detach()
        else:
            融合_patch_教师原始 = 融合_patch_教师

        融合_教师SK = torch.softmax(
            融合_patch_教师原始 / 0.04, dim=-1
        )
        融合ibot_掩码 = torch.ones(B, T_eff, dtype=torch.bool)
        融合ibot损失值 = 融合ibot损失(
            融合_patch_学生投影, 融合_教师SK, 融合ibot_掩码
        )

        # ── 5. HR Object 损失 ──
        hr_student_obj_logits = hr_object损失.compute_assignment(
            hr_patch_学生, hr_object损失.object_queries
        )
        hr_teacher_patch_obj = _随机L2归一化张量((B, P, 768))
        with torch.no_grad():
            hr_teacher_obj_logits = hr_object损失.compute_assignment(
                hr_teacher_patch_obj, hr_object损失.object_queries
            )
            hr_teacher_obj_probs = hr_object损失.sinkhorn_knopp_teacher(
                hr_teacher_obj_logits, teacher_temp=0.04
            )
        hr_object损失值 = hr_object损失(hr_student_obj_logits, hr_teacher_obj_probs)

        # ── 6. Fusion Object 损失 ──
        fusion_student_obj_logits = fusion_object损失.compute_assignment(
            融合_patch_学生, fusion_object损失.object_queries
        )
        fusion_teacher_patch_obj = _随机L2归一化张量((B, T_eff, 768))
        with torch.no_grad():
            fusion_teacher_obj_logits = fusion_object损失.compute_assignment(
                fusion_teacher_patch_obj, fusion_object损失.object_queries
            )
            fusion_teacher_obj_probs = fusion_object损失.sinkhorn_knopp_teacher(
                fusion_teacher_obj_logits, teacher_temp=0.04
            )
        fusion_object损失值 = fusion_object损失(
            fusion_student_obj_logits, fusion_teacher_obj_probs
        )

        # ── 总损失 ──
        总损失 = (
            1.0 * hr_dino损失值
            + 0.1 * hr_ibot损失值
            + 0.1 * 融合dino损失值
            + 0.1 * 融合ibot损失值
            + 0.05 * hr_object损失值
            + 0.05 * fusion_object损失值
        )
        总损失.backward()

        # ── 验证学生参数有梯度（经过损失反向传播）──
        for i, p in enumerate(学生参数列表):
            assert p.grad is not None, \
                f"学生参数[{i}] 无梯度 (shape={tuple(p.shape)})"
            assert not p.grad.isnan().any(), \
                f"学生参数[{i}] 梯度含 NaN (shape={tuple(p.shape)})"
            if p.data.abs().max() > 1e-8:
                assert p.grad.abs().max() > 1e-10, \
                    f"学生参数[{i}] 梯度几乎为零，但参数非零 (shape={tuple(p.shape)})"

        # ── 验证教师参数无梯度（预期 stop-grad）──
        for i, p in enumerate(教师参数列表):
            assert p.grad is None, \
                f"教师参数[{i}] 不应有梯度 (shape={tuple(p.shape)})，应为 stop-grad"
            assert not p.isnan().any(), \
                f"教师参数[{i}] 数据含 NaN (shape={tuple(p.shape)})"

        模式名 = "直接CE(768维)" if 使用直接CE else "65536原型投影"
        print(f"\n[{模式名}] "
              f"总损失={总损失.item():.4f}  "
              f"DINO={hr_dino损失值.item():.4f}  "
              f"iBOT={hr_ibot损失值.item():.4f}  "
              f"融合DINO={融合dino损失值.item():.4f}  "
              f"融合iBOT={融合ibot损失值.item():.4f}  "
              f"HR_Obj={hr_object损失值.item():.4f}  "
              f"Fus_Obj={fusion_object损失值.item():.4f}")

    def test_两种模式均无NaN梯度(self):
        """768 维和 65536 维模式下反向传播均不应产生 NaN。"""
        for 使用直接CE in [True, False]:
            K = 768 if 使用直接CE else 65536
            B = 4
            df = DINOLoss(K)
            tp = torch.softmax(_随机L2归一化张量((1, B, K)) / 0.04, dim=-1)
            sl = torch.randn(1, B, K, requires_grad=True)
            损失值 = df(sl, tp)
            损失值.backward()
            
            模式名 = "768维直接CE" if 使用直接CE else "65536维原型"
            assert not torch.isnan(sl.grad).any(), \
                f"{模式名}: 梯度出现 NaN"
            assert math.isfinite(损失值.item()), \
                f"{模式名}: 损失值不是有限值，为 {损失值.item()}"


# ══════════════════════════════════════════════════════════
# 5. 报告一致性验证
# ══════════════════════════════════════════════════════════

class Test报告一致性:
    """验证代码行为与 DINOv3 损失函数分析报告一致。"""

    def test_use_direct_ce_loss开关(self):
        """
        model.py 使用 use_direct_ce_loss 在两种维度之间切换：
        - True  → 768 维直接 CE（SK + 中心向量 + EMA + 学生温度）
        - False → 65536 原型（经 DINOHead）
        """
        B = 8
        for 标志值, K in [(True, 768), (False, 65536)]:
            dl = DINOLoss(K, student_temp=0.1)
            tp = dl.sinkhorn_knopp_teacher(
                _随机L2归一化张量((B, K)), teacher_temp=0.04
            ).unsqueeze(0)
            sl = torch.randn(1, B, K)
            损失值 = dl(sl, tp)
            
            标志说明 = "直接CE" if 标志值 else "原型模式"
            assert 损失值.ndim == 0 and math.isfinite(损失值.item()), \
                f"{标志说明}, K={K}, 损失值无效: {损失值.item()}"

    def test_总损失公式(self):
        """
        报告公式：总损失 = w1*dino + w2*ibot + w3*融合dino + w4*融合ibot
                           + w5*hr_obj + w6*fusion_obj
        """
        K = 768
        Kobj = 64
        dl_dino = DINOLoss(K)
        dl_ibot = iBOTPatchLoss(K)
        dl_obj = ObjectLoss(embed_dim=768, num_objects=Kobj)

        B, P = 4, 64
        # DINO
        tp_dino = dl_dino.sinkhorn_knopp_teacher(
            _随机L2归一化张量((B, K)), teacher_temp=0.04
        ).unsqueeze(0)
        sl_dino = torch.randn(1, B, K)
        dino_val = dl_dino(sl_dino, tp_dino)

        # iBOT
        tp_ibot = torch.softmax(
            _随机L2归一化张量((B, P, K)) / 0.04, dim=-1
        )
        sl_ibot = torch.randn(B, P, K)
        掩码 = torch.ones(B, P, dtype=torch.bool)
        ibot_val = dl_ibot(sl_ibot, tp_ibot, 掩码)

        # Object
        student_patch = _随机L2归一化张量((B, P, 768))
        student_obj_logits = dl_obj.compute_assignment(student_patch, dl_obj.object_queries)
        teacher_patch = _随机L2归一化张量((B, P, 768))
        with torch.no_grad():
            teacher_obj_logits = dl_obj.compute_assignment(teacher_patch, dl_obj.object_queries)
            teacher_obj_probs = dl_obj.sinkhorn_knopp_teacher(teacher_obj_logits, teacher_temp=0.04)
        obj_val = dl_obj(student_obj_logits, teacher_obj_probs)

        总损失 = 1.0 * dino_val + 0.1 * ibot_val + 0.1 * dino_val + 0.1 * ibot_val + 0.05 * obj_val + 0.05 * obj_val
        assert math.isfinite(总损失.item()), \
            f"总损失值无效: {总损失.item()}"

    def test_教师使用SinkhornKnopp(self):
        """
        报告强调教师使用 Sinkhorn-Knopp 算法进行软分配。
        直接测试 DINO SK。
        """
        # DINO SK
        dl = DINOLoss(768)
        dino概率 = dl.sinkhorn_knopp_teacher(
            _随机L2归一化张量((1024, 768)), teacher_temp=0.04
        )
        assert torch.allclose(dino概率.sum(-1), torch.ones(1024), atol=1e-5), \
            "DINO SK 输出每行之和不为 1"
        assert (dino概率 >= 0).all(), "DINO SK 输出含有负数"
        assert not dino概率.isnan().any(), "DINO SK 输出含有 NaN"


# ══════════════════════════════════════════════════════════
# 6. 边界情况与数值稳定性
# ══════════════════════════════════════════════════════════

class Test边界情况:
    """边界情况与数值稳定性测试。"""

    def test_大批量无NaN(self):
        """大批量不应产生 NaN。"""
        dl = DINOLoss(65536)
        B = 128
        tp = dl.sinkhorn_knopp_teacher(
            _随机L2归一化张量((B, 65536)), teacher_temp=0.04
        )
        sl = torch.randn(1, B, 65536)
        损失值 = dl(sl, tp.unsqueeze(0))
        assert math.isfinite(损失值.item()), \
            f"65536 维大批量(B={B})损失值无效: {损失值.item()}"

    def test_中心向量收敛(self):
        """反复 update_center 不应发散。"""
        dl = DINOLoss(65536)
        dl.init_weights()
        for _ in range(20):
            数据 = _随机L2归一化张量((16, 65536))
            dl.update_center(数据)
            dl.apply_center_update()
        assert dl.center.abs().max().item() < 100.0, \
            f"20 轮后中心向量最大值异常: {dl.center.abs().max().item()}"

    def test_空patch掩码_正确处理(self):
        """空掩码不应崩溃（clamp 保护应生效）。"""
        il = iBOTPatchLoss(768)
        B, P = 4, 10
        教师概率 = torch.softmax(_随机L2归一化张量((B, P, 768)) / 0.04, dim=-1)
        学生输出 = torch.randn(B, P, 768, requires_grad=True)
        空掩码 = torch.zeros(B, P, dtype=torch.bool)
        损失值 = il(学生输出, 教师概率, 空掩码)
        assert math.isfinite(损失值.item()), \
            f"空掩码情况下损失值无效: {损失值.item()}"


# ══════════════════════════════════════════════════════════
# 入口
# ══════════════════════════════════════════════════════════
if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=long"])
