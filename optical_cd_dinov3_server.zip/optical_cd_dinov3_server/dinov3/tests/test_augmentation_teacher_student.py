"""
测试脚本: DINOv3 教师-学生分支修改验证
=========================================

验证内容:
  1. 教师分支图像不作增强处理 (仅 resize + center crop + normalize)
  2. 学生分支图像应用全部强增强
  3. 所有 mask 操作已取消

必须从项目根目录运行:
    cd <项目根目录>  (包含 dinov3/ 的目录)
    python -m dinov3.tests.test_augmentation_teacher_student
"""

import sys
import os
import math

import pytest
import torch
import numpy as np
from PIL import Image

# ── 确保项目根目录在 sys.path 中 ────────────────────────
_PROJ_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..")
)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from dinov3.data.augmentations import DataAugmentationDINO
from dinov3.data.collate import collate_data_and_cast, get_batch_subset
from dinov3.data.transforms import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD


# ══════════════════════════════════════════════════════════
# 辅助函数
# ══════════════════════════════════════════════════════════

def _create_random_pil_image(size=(256, 256)):
    """创建一个随机的 PIL RGB 图像用于测试增强"""
    arr = np.random.randint(0, 256, (*size, 3), dtype=np.uint8)
    return Image.fromarray(arr)


def _pil_to_numpy(pil_img):
    """将 PIL 图像转换为 numpy 数组 (H, W, 3)"""
    return np.array(pil_img)


def _is_normalized_tensor(tensor, mean, std):
    """
    检查 tensor 是否是经过给定 mean/std 归一化的结果。
    tensor 形状: [C, H, W] 或 [3, H, W]
    返回值: bool — 图像的数值范围是否与归一化一致
    """
    if isinstance(tensor, torch.Tensor):
        arr = tensor.detach().cpu().numpy()
    else:
        arr = tensor
    # 归一化后: 期望 mean≈0, std≈1 在大多数像素上
    arr = np.asarray(arr, dtype=np.float32)
    return arr.min() < 0 and arr.max() > 1.0  # 归一化后数值应在 ≈[-2, 2] 范围


def _check_spatial_augmentation(img1, img2, threshold=0.95):
    """
    检查两张图像是否有空间变换 (随机裁剪、翻转等)。
    如果两张图过于相似 (SSIM-like > threshold), 则可能没有变换。
    此处使用简单的像素差异比例来判断。
    """
    arr1 = np.array(img1, dtype=np.float32)
    arr2 = np.array(img2, dtype=np.float32)
    if arr1.shape != arr2.shape:
        return True  # 尺寸不同 → 有变换
    diff_ratio = np.mean(np.abs(arr1 - arr2) > 5)
    return diff_ratio > 0.01


def _check_color_augmentation(img1, img2, threshold=0.80):
    """
    检查两张图像是否有颜色变换。
    使用像素相关系数, 如果高度相关则说明没有颜色抖动。
    返回值: bool — True 表示有颜色增强
    """
    arr1 = np.array(img1, dtype=np.float32).ravel()
    arr2 = np.array(img2, dtype=np.float32).ravel()
    if len(arr1) != len(arr2):
        return True
    corr = np.corrcoef(arr1, arr2)[0, 1]
    if np.isnan(corr):
        return False
    return abs(corr) < threshold


# ══════════════════════════════════════════════════════════
# 1. 增强函数基础测试
# ══════════════════════════════════════════════════════════

class TestDataAugmentationTeacherStudent:
    """验证教师-学生分支的增强差异"""

    def test_output_contains_both_keys(self):
        """DataAugmentationDINO 输出应同时包含 global_crops 和 global_crops_teacher"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        img = _create_random_pil_image((512, 512))
        output = aug(img)

        assert "global_crops" in output, "输出缺少 'global_crops' (学生分支)"
        assert "global_crops_teacher" in output, "输出缺少 'global_crops_teacher' (教师分支)"
        assert "local_crops" in output, "输出缺少 'local_crops'"

    def test_student_global_crops_have_spatial_augmentation(self):
        """学生分支的两张 global crops 应该有空间变换"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        img = _create_random_pil_image((512, 512))
        output = aug(img)

        student_crop1 = output["global_crops"][0]
        student_crop2 = output["global_crops"][1]

        # 两张学生 crop 应该不同 (因为 RandomResizedCrop)
        # 转换为 numpy 进行比较
        arr1 = student_crop1.permute(1, 2, 0).cpu().numpy()
        arr2 = student_crop2.permute(1, 2, 0).cpu().numpy()

        diff = np.mean(np.abs(arr1 - arr2))
        assert diff > 1e-6, (
            f"两张学生 global crops 完全相同 (diff={diff:.8f}), "
            f"RandomResizedCrop 未生效"
        )

    def test_teacher_global_crops_have_no_spatial_variation(self):
        """教师分支的两张 global crops 应该完全相同 (仅 resize + center crop)"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        img = _create_random_pil_image((512, 512))
        output = aug(img)

        teacher_crop1 = output["global_crops_teacher"][0]
        teacher_crop2 = output["global_crops_teacher"][1]

        arr1 = teacher_crop1.permute(1, 2, 0).cpu().numpy()
        arr2 = teacher_crop2.permute(1, 2, 0).cpu().numpy()

        diff = np.mean(np.abs(arr1 - arr2))
        assert diff < 1e-5, (
            f"两张教师 global crops 不相同 (diff={diff:.8f}), "
            f"教师分支应仅做确定性变换 (resize + center crop)"
        )

    def test_student_teacher_are_different(self):
        """学生分支和教师分支的图像应该不同"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        img = _create_random_pil_image((512, 512))
        output = aug(img)

        student_crop = output["global_crops"][0]
        teacher_crop = output["global_crops_teacher"][0]

        arr_s = student_crop.permute(1, 2, 0).cpu().numpy()
        arr_t = teacher_crop.permute(1, 2, 0).cpu().numpy()

        diff = np.mean(np.abs(arr_s - arr_t))
        assert diff > 1e-6, (
            f"学生和教师图片完全相同 (diff={diff:.8f}), "
            f"学生应该有随机增强而教师没有"
        )

    def test_student_crops_are_normalized(self):
        """学生分支输出应是归一化的 tensor"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        img = _create_random_pil_image((512, 512))
        output = aug(img)

        student_crop = output["global_crops"][0]
        assert isinstance(student_crop, torch.Tensor), "学生输出应为 torch.Tensor"
        assert student_crop.dtype == torch.float32, f"学生输出 dtype 应为 float32, 实际为 {student_crop.dtype}"
        assert student_crop.shape[0] == 3, f"学生输出应为 3 通道, 实际为 {student_crop.shape[0]} 通道"

    def test_teacher_crops_are_normalized(self):
        """教师分支输出应是归一化的 tensor"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        img = _create_random_pil_image((512, 512))
        output = aug(img)

        teacher_crop = output["global_crops_teacher"][0]
        assert isinstance(teacher_crop, torch.Tensor), "教师输出应为 torch.Tensor"
        assert teacher_crop.dtype == torch.float32, f"教师输出 dtype 应为 float32, 实际为 {teacher_crop.dtype}"
        assert teacher_crop.shape[0] == 3, f"教师输出应为 3 通道"

    def test_global_crops_size_matches(self):
        """学生和教师的 global crops 应该有相同的尺寸"""
        for size in [224, 336, 448]:
            aug = DataAugmentationDINO(
                global_crops_scale=(0.4, 1.0),
                local_crops_scale=(0.05, 0.4),
                local_crops_number=8,
                global_crops_size=size,
                local_crops_size=96,
            )
            img = _create_random_pil_image((max(size + 100, 400), max(size + 100, 400)))
            output = aug(img)

            s_h, s_w = output["global_crops"][0].shape[1], output["global_crops"][0].shape[2]
            t_h, t_w = output["global_crops_teacher"][0].shape[1], output["global_crops_teacher"][0].shape[2]

            assert s_h == size and s_w == size, f"size={size}: 学生 crop 尺寸为 ({s_h}, {s_w})"
            assert t_h == size and t_w == size, f"size={size}: 教师 crop 尺寸为 ({t_h}, {t_w})"

    def test_teacher_transform_is_deterministic(self):
        """教师变换是确定性的: 同一张图多次调用产生相同结果"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        img = _create_random_pil_image((512, 512))

        # 多次调用
        outputs = [aug(img) for _ in range(3)]
        for i in range(1, 3):
            t1 = outputs[0]["global_crops_teacher"][0]
            t2 = outputs[i]["global_crops_teacher"][0]
            diff = torch.mean(torch.abs(t1 - t2)).item()
            assert diff < 1e-5, (
                f"第 {i+1} 次调用的教师 crop 与第一次不同 (diff={diff:.8f}), "
                f"教师变换应为确定性的"
            )

    def test_student_transform_is_non_deterministic(self):
        """学生变换是随机的: 同一张图多次调用产生不同结果 (大概率)"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        img = _create_random_pil_image((512, 512))

        # 多次调用, 检查是否有任何差异
        outputs = [aug(img) for _ in range(5)]
        all_same = []
        for i in range(1, 5):
            s1 = outputs[0]["global_crops"][0]
            s2 = outputs[i]["global_crops"][0]
            diff = torch.mean(torch.abs(s1 - s2)).item()
            all_same.append(diff < 1e-5)

        # 5 次调用中至少有一次不同
        assert not all(all_same), (
            "连续 5 次调用学生变换产生了完全相同的结果, "
            "随机增强 (RandomResizedCrop/ColorJitter) 可能未生效"
        )

    def test_local_crops_still_present(self):
        """local crops 仍然存在于输出中 (学生分支)"""
        for n_local in [4, 8]:
            aug = DataAugmentationDINO(
                global_crops_scale=(0.4, 1.0),
                local_crops_scale=(0.05, 0.4),
                local_crops_number=n_local,
                global_crops_size=224,
                local_crops_size=96,
            )
            img = _create_random_pil_image((512, 512))
            output = aug(img)

            assert len(output["local_crops"]) == n_local, (
                f"期望 {n_local} 个 local crops, 实际为 {len(output['local_crops'])}"
            )
            for lc in output["local_crops"]:
                assert lc.shape[1] == 96, f"local crop 高度应为 96, 实际为 {lc.shape[1]}"
                assert lc.shape[2] == 96, f"local crop 宽度应为 96, 实际为 {lc.shape[2]}"


# ══════════════════════════════════════════════════════════
# 2. Mask 取消验证
# ══════════════════════════════════════════════════════════

class TestMaskCancellation:
    """验证所有 mask 操作已取消"""

    def _build_fake_augmentation(self):
        """构建一个增强函数, 返回与 DataAugmentationDINO 兼容的输出格式"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )
        return aug

    def _make_sample_list(self, aug, n_samples=4):
        """生成模拟样本列表 [{(aug_output, target)}, ...]"""
        samples = []
        for _ in range(n_samples):
            img = _create_random_pil_image((512, 512))
            output = aug(img)
            samples.append((output, 0))  # target = 0, 仅占位
        return samples

    def test_collated_masks_are_all_false(self):
        """collated_masks 应全部为 False"""
        aug = self._build_fake_augmentation()
        samples = self._make_sample_list(aug, n_samples=4)

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,  # 14x14 patches for 224px / 16px patch
        )

        masks = collated["collated_masks"]
        assert isinstance(masks, torch.Tensor), "collated_masks 应为 torch.Tensor"
        assert masks.dtype == torch.bool, f"collated_masks dtype 应为 bool, 实际为 {masks.dtype}"
        assert not masks.any(), (
            f"collated_masks 应全部为 False, 但有 {masks.sum().item()} 个 True"
        )

    def test_mask_indices_list_is_empty(self):
        """mask_indices_list 应为空张量"""
        aug = self._build_fake_augmentation()
        samples = self._make_sample_list(aug, n_samples=4)

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        mask_indices = collated["mask_indices_list"]
        assert isinstance(mask_indices, torch.Tensor)
        assert mask_indices.numel() == 0, (
            f"mask_indices_list 应为空, 但有 {mask_indices.numel()} 个元素"
        )

    def test_masks_weight_is_empty(self):
        """masks_weight 应为空张量"""
        aug = self._build_fake_augmentation()
        samples = self._make_sample_list(aug, n_samples=4)

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        masks_weight = collated["masks_weight"]
        assert isinstance(masks_weight, torch.Tensor)
        assert masks_weight.numel() == 0, (
            f"masks_weight 应为空, 但有 {masks_weight.numel()} 个元素"
        )

    def test_upperbound_is_zero(self):
        """upperbound 应为 0"""
        aug = self._build_fake_augmentation()
        samples = self._make_sample_list(aug, n_samples=4)

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        assert collated["upperbound"] == 0, (
            f"upperbound 应为 0, 实际为 {collated['upperbound']}"
        )

    def test_n_masked_patches_is_zero(self):
        """n_masked_patches 应为 0"""
        aug = self._build_fake_augmentation()
        samples = self._make_sample_list(aug, n_samples=4)

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        n_masked = collated["n_masked_patches"]
        assert isinstance(n_masked, torch.Tensor)
        assert n_masked.item() == 0, (
            f"n_masked_patches 应为 0, 实际为 {n_masked.item()}"
        )

    def test_teacher_crops_collated_correctly(self):
        """教师 crops 应被正确拼接为独立的 tensor"""
        aug = self._build_fake_augmentation()
        n_samples = 4
        samples = self._make_sample_list(aug, n_samples=n_samples)

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        # 教师 crops 存在且形状正确: [2 * B, 3, 224, 224]
        teacher_crops = collated["collated_global_crops_teacher"]
        assert isinstance(teacher_crops, torch.Tensor), "collated_global_crops_teacher 应为 Tensor"
        assert teacher_crops.shape[0] == 2 * n_samples, (
            f"教师 batch size 应为 {2*n_samples}, 实际为 {teacher_crops.shape[0]}"
        )
        assert teacher_crops.shape[1] == 3, f"教师 crops 通道数应为 3, 实际为 {teacher_crops.shape[1]}"

    def test_student_teacher_crops_are_different(self):
        """学生和教师 crops 在 collated 后应该不同"""
        aug = self._build_fake_augmentation()
        n_samples = 2
        samples = self._make_sample_list(aug, n_samples=n_samples)

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        student = collated["collated_global_crops"]
        teacher = collated["collated_global_crops_teacher"]

        # 学生和教师 tensor 应不同
        diff = torch.mean(torch.abs(student - teacher)).item()
        assert diff > 1e-6, (
            f"学生和教师 collated crops 完全相同 (diff={diff:.8f})"
        )


# ══════════════════════════════════════════════════════════
# 3. get_batch_subset 中的 mask 取消验证
# ══════════════════════════════════════════════════════════

class TestBatchSubsetMaskCancellation:
    """验证 get_batch_subset 中 mask 已取消"""

    def _build_fake_augmentation(self):
        return DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )

    def _make_sample_list(self, aug, n_samples=4):
        samples = []
        for _ in range(n_samples):
            img = _create_random_pil_image((512, 512))
            output = aug(img)
            samples.append((output, 0))
        return samples

    def test_batch_subset_masks_all_false(self):
        """get_batch_subset 输出的 collated_masks 应全部为 False"""
        aug = self._build_fake_augmentation()
        samples = self._make_sample_list(aug, n_samples=8)

        full_batch = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        subset = get_batch_subset(full_batch, divide_by=2)

        masks = subset["collated_masks"]
        assert not masks.any(), (
            f"get_batch_subset 的 masks 应全部为 False, "
            f"但有 {masks.sum().item()} 个 True"
        )

    def test_batch_subset_mask_indices_empty(self):
        """get_batch_subset 输出的 mask_indices_list 应为空"""
        aug = self._build_fake_augmentation()
        samples = self._make_sample_list(aug, n_samples=8)

        full_batch = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        subset = get_batch_subset(full_batch, divide_by=2)

        assert subset["mask_indices_list"].numel() == 0, (
            "get_batch_subset 的 mask_indices_list 应为空"
        )

    def test_batch_subset_n_masked_patches_zero(self):
        """get_batch_subset 输出的 n_masked_patches 应为 0"""
        aug = self._build_fake_augmentation()
        samples = self._make_sample_list(aug, n_samples=8)

        full_batch = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        subset = get_batch_subset(full_batch, divide_by=2)

        assert subset["n_masked_patches"].item() == 0, (
            f"get_batch_subset 的 n_masked_patches 应为 0, "
            f"实际为 {subset['n_masked_patches'].item()}"
        )


# ══════════════════════════════════════════════════════════
# 4. 端到端数据流验证
# ══════════════════════════════════════════════════════════

class TestEndToEndDataFlow:
    """端到端验证 augmentation → collate 数据流"""

    def test_full_pipeline_output_structure(self):
        """
        完整流程: augment → collate → 验证输出结构正确
        """
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )

        # 模拟多图像 batch
        samples = []
        for _ in range(4):
            img = _create_random_pil_image((512, 512))
            output = aug(img)
            samples.append((output, 0))

        # Collate
        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        # 验证所有必需的 key 都存在
        required_keys = [
            "collated_global_crops",
            "collated_global_crops_teacher",
            "collated_local_crops",
            "collated_masks",
            "mask_indices_list",
            "masks_weight",
            "upperbound",
            "n_masked_patches",
        ]
        for key in required_keys:
            assert key in collated, f"collated 输出缺少 key: '{key}'"

    def test_student_teacher_shape_consistency(self):
        """学生和教师 global crops 应该有相同的 batch size 和空间尺寸"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )

        samples = []
        for _ in range(4):
            img = _create_random_pil_image((512, 512))
            output = aug(img)
            samples.append((output, 0))

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        student = collated["collated_global_crops"]
        teacher = collated["collated_global_crops_teacher"]

        assert student.shape == teacher.shape, (
            f"学生 shape {list(student.shape)} ≠ 教师 shape {list(teacher.shape)}"
        )

    def test_batch_subset_preserves_teacher_crops(self):
        """get_batch_subset 后教师 crops 仍存在且正确"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )

        samples = []
        for _ in range(8):
            img = _create_random_pil_image((512, 512))
            output = aug(img)
            samples.append((output, 0))

        collated = collate_data_and_cast(
            samples,
            mask_ratio_tuple=(0.5, 1.0),
            mask_probability=1.0,
            dtype=torch.float32,
            n_tokens=196,
        )

        # 模拟子集
        subset = get_batch_subset(collated, divide_by=2)

        # 检查子集中学生和教师 crops 的一致性
        expected_batch = 4 * 2  # (8/2) samples * 2 crops
        assert subset["collated_global_crops"].shape[0] == expected_batch, (
            f"学生子集 batch size 应为 {expected_batch}"
        )

    def test_multiple_image_sizes(self):
        """不同输入图像尺寸都应正确处理"""
        for input_size in [(300, 400), (600, 600), (800, 600)]:
            aug = DataAugmentationDINO(
                global_crops_scale=(0.4, 1.0),
                local_crops_scale=(0.05, 0.4),
                local_crops_number=4,
                global_crops_size=224,
                local_crops_size=96,
            )
            img = _create_random_pil_image(input_size)
            output = aug(img)

            # 教师和学生都有正确的尺寸
            for crop in output["global_crops"]:
                assert crop.shape[1] == 224 and crop.shape[2] == 224
            for crop in output["global_crops_teacher"]:
                assert crop.shape[1] == 224 and crop.shape[2] == 224

    def test_no_nan_in_output(self):
        """所有输出不应包含 NaN"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )

        for _ in range(10):
            img = _create_random_pil_image((512, 512))
            output = aug(img)

            for crop in output["global_crops"]:
                assert not torch.isnan(crop).any(), "学生 global crop 包含 NaN"
            for crop in output["global_crops_teacher"]:
                assert not torch.isnan(crop).any(), "教师 global crop 包含 NaN"
            for crop in output["local_crops"]:
                assert not torch.isnan(crop).any(), "local crop 包含 NaN"

    def test_no_inf_in_output(self):
        """所有输出不应包含 Inf"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=8,
            global_crops_size=224,
            local_crops_size=96,
        )

        for _ in range(10):
            img = _create_random_pil_image((512, 512))
            output = aug(img)

            for crop in output["global_crops"]:
                assert not torch.isinf(crop).any(), "学生 global crop 包含 Inf"
            for crop in output["global_crops_teacher"]:
                assert not torch.isinf(crop).any(), "教师 global crop 包含 Inf"


# ══════════════════════════════════════════════════════════
# 5. 数值范围验证
# ══════════════════════════════════════════════════════════

class TestNormalizationConsistency:
    """验证教师和学生的归一化一致性"""

    def test_teacher_student_same_normalization_params(self):
        """教师和学生使用相同的 mean/std 进行归一化"""
        for custom_mean, custom_std in [
            (IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD),
            ((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
            ((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
        ]:
            aug = DataAugmentationDINO(
                global_crops_scale=(0.4, 1.0),
                local_crops_scale=(0.05, 0.4),
                local_crops_number=4,
                global_crops_size=224,
                local_crops_size=96,
                mean=custom_mean,
                std=custom_std,
            )
            img = _create_random_pil_image((512, 512))
            output = aug(img)

            s = output["global_crops"][0]
            t = output["global_crops_teacher"][0]

            # 两者都应该有负值 (归一化后)
            assert (s < 0).any(), "学生 crop 应包含归一化后的负值"
            assert (t < 0).any(), "教师 crop 应包含归一化后的负值"

    def test_teacher_crops_are_normalized_like_student(self):
        """教师 crops 应该经过与学生相同的 normalize 处理"""
        aug = DataAugmentationDINO(
            global_crops_scale=(0.4, 1.0),
            local_crops_scale=(0.05, 0.4),
            local_crops_number=4,
            global_crops_size=224,
            local_crops_size=96,
        )

        for _ in range(5):
            img = _create_random_pil_image((512, 512))
            output = aug(img)

            s = output["global_crops"][0]
            t = output["global_crops_teacher"][0]

            # 归一化后的像素值范围应大致相似
            s_range = s.max().item() - s.min().item()
            t_range = t.max().item() - t.min().item()

            # 两者的数值范围应该在相近的数量级
            ratio = max(s_range, t_range) / (min(s_range, t_range) + 1e-8)
            assert ratio < 10.0, (
                f"教师和学生归一化后数值范围差异过大 "
                f"(学生范围={s_range:.2f}, 教师范围={t_range:.2f}, 比值={ratio:.2f})"
            )


# ══════════════════════════════════════════════════════════
# 入口
# ══════════════════════════════════════════════════════════

if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-v", "--tb=short"]))
