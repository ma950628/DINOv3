# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This software may be used and distributed in accordance with
# the terms of the DINOv3 License Agreement.

import math

import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch import nn

from dinov3.distributed import get_process_subgroup, get_subgroup_size


class ObjectLoss(nn.Module):
    """
    Object Loss — Discrete Bottleneck Object-level Distillation Loss.

    This loss introduces a set of learnable object queries (discrete bottleneck)
    that group ViT patch tokens into object-level representations via a soft
    assignment mechanism. The loss enforces student-teacher consistency on the
    soft assignment matrix using Sinkhorn-Knopp centering on the teacher side,
    following the same pattern as DINO/iBOT losses.

    Architecture:
        Student: patch_tokens [B, P, D] → cross_attn(object_queries, patches)
                 → soft_assignment [B, num_objects, P]
        Teacher: patch_tokens [B, P, D] → cross_attn(object_queries, patches)
                 → Sinkhorn-Knopp → teacher_assignment [B, num_objects, P]

        Loss = CrossEntropy(student_assignment, teacher_assignment)

    The discrete bottleneck (object_queries) is shared between student and
    teacher (EMA-updated), and the teacher assignment is centered via
    Sinkhorn-Knopp to prevent collapse.

    Args:
        embed_dim:      Feature dimension of ViT patch tokens (D)
        num_objects:    Number of object queries in the discrete bottleneck
        student_temp:   Temperature for student log-softmax
        center_momentum: EMA momentum for center update
    """

    def __init__(
        self,
        embed_dim,
        num_objects=64,
        student_temp=0.1,
        center_momentum=0.9,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_objects = num_objects
        self.student_temp = student_temp
        self.center_momentum = center_momentum

        # --- Learnable object queries (discrete bottleneck) ---
        # These queries are used to produce soft assignment over patch tokens.
        # Shape: [num_objects, D]
        self.object_queries = nn.Parameter(
            torch.randn(num_objects, embed_dim) * (embed_dim ** -0.5)
        )

        # --- Center buffer for Sinkhorn-Knopp teacher centering ---
        # Shape: [1, num_objects, 1] — one center per object query
        self.register_buffer("center", torch.full((1, num_objects, 1), math.nan))
        self.updated = True
        self.reduce_handle = None
        self.len_teacher_output = None
        self.async_batch_center = None

        # --- Temperature for teacher ---
        # Will be set during forward call

    def init_weights(self) -> None:
        self.center.zero_()
        nn.init.normal_(self.object_queries, std=self.embed_dim ** -0.5)

    def compute_assignment(
        self,
        patch_tokens: torch.Tensor,
        object_queries: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute soft assignment of patch tokens to object queries.

        For each object query, compute cosine similarity (or dot product)
        with each patch token, producing a soft assignment matrix.

        Args:
            patch_tokens:  [B, P, D] or [N, P, D]  — patch features
            object_queries: [num_objects, D]         — learnable queries

        Returns:
            assignment: [B, num_objects, P]  — soft assignment logits
        """
        # Normalize for stable cosine similarity
        patch_norm = F.normalize(patch_tokens, dim=-1)      # [..., P, D]
        queries_norm = F.normalize(object_queries, dim=-1)   # [num_objects, D]

        # Dot product: [..., P, D] × [num_objects, D]ᵀ → [..., P, num_objects]
        # Use batch matmul
        if patch_norm.dim() == 3:
            # [B, P, D] × [D, num_objects] → [B, P, num_objects]
            logits = torch.matmul(patch_norm, queries_norm.T)
            # → [B, num_objects, P]
            logits = logits.permute(0, 2, 1)
        elif patch_norm.dim() == 4:
            # [N, T, D] × [D, num_objects] → [N, T, num_objects]
            logits = torch.matmul(patch_norm, queries_norm.T)
            # → [N, num_objects, T]
            logits = logits.permute(0, 2, 1)
        else:
            raise ValueError(f"Unexpected patch_tokens shape: {patch_tokens.shape}")

        return logits  # [..., num_objects, P]

    @torch.no_grad()
    def sinkhorn_knopp_teacher(
        self,
        teacher_logits: torch.Tensor,
        teacher_temp: float,
        n_iterations: int = 3,
    ) -> torch.Tensor:
        """
        Apply Sinkhorn-Knopp centering to teacher assignment logits.

        The assignment has shape [B, num_objects, P] where:
          - num_objects: object query dimension (like prototypes in DINO)
          - P: number of patches (like batch dimension in Sinkhorn-Knopp)

        We apply Sinkhorn-Knopp along the object query dimension to ensure
        soft assignments are evenly distributed across objects, preventing
        all patches from collapsing to a single object query.

        Args:
            teacher_logits: [B, num_objects, P] — raw teacher assignment logits
            teacher_temp:   temperature for sharpening
            n_iterations:   number of Sinkhorn-Knopp iterations

        Returns:
            teacher_probs: [B, num_objects, P] — centered assignment probabilities
        """
        B, K, P = teacher_logits.shape  # K = num_objects
        teacher_output = teacher_logits.float()

        # Sinkhorn-Knopp treats:
        #   - K (num_objects) as the prototype dimension
        #   - B * P as the batch dimension
        # We transpose to [K, B*P] for consistency with DINO/iBOT paradigm

        teacher_output = teacher_output.permute(1, 0, 2).reshape(K, B * P)  # [K, B*P]

        world_size = get_subgroup_size() if dist.is_initialized() else 1
        Q = torch.exp(teacher_output / teacher_temp)  # [K, B*P]
        total_B = Q.shape[1] * world_size  # total effective batch

        # make the matrix sum to 1
        sum_Q = torch.sum(Q)
        if dist.is_initialized():
            dist.all_reduce(sum_Q, group=get_process_subgroup())
        Q /= sum_Q

        for _ in range(n_iterations):
            # normalize each row: total weight per object must be 1/K
            sum_of_rows = torch.sum(Q, dim=1, keepdim=True)
            if dist.is_initialized():
                dist.all_reduce(sum_of_rows, group=get_process_subgroup())
            Q /= sum_of_rows
            Q /= K

            # normalize each column: total weight per sample must be 1/(B*P)
            Q /= torch.sum(Q, dim=0, keepdim=True)
            Q /= total_B

        Q *= total_B  # columns must sum to 1 so that Q is an assignment

        # Reshape back: [K, B*P] → [B, K, P]
        Q = Q.reshape(K, B, P).permute(1, 0, 2)  # [B, K, P]

        return Q

    @torch.no_grad()
    def softmax_center_teacher(
        self,
        teacher_output: torch.Tensor,
        teacher_temp: float,
        update_centers: bool = True,
    ) -> torch.Tensor:
        """
        Softmax centering (alternative to Sinkhorn-Knopp for testing).
        """
        if update_centers:
            self.apply_center_update()
        # teacher_output: [B, K, P]
        return F.softmax((teacher_output - self.center) / teacher_temp, dim=1)

    def forward(
        self,
        student_logits: torch.Tensor,
        teacher_probs: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute object-level distillation loss.

        Args:
            student_logits: [B, num_objects, P] — student assignment logits
            teacher_probs:  [B, num_objects, P] — teacher assignment probabilities

        Returns:
            loss: scalar tensor
        """
        B, K, P = student_logits.shape

        # Student: apply log-softmax over object dimension
        # For each patch position, we want a distribution over object queries
        student_log_probs = F.log_softmax(
            student_logits.float() / self.student_temp, dim=1
        )  # [B, K, P]

        # Cross-entropy: -sum(teacher * log(student))
        # Sum over object dimension and patch dimension
        loss = -torch.sum(teacher_probs * student_log_probs, dim=1)  # [B, P]
        loss = loss.mean()  # scalar

        return loss

    @torch.no_grad()
    def update_center(self, teacher_output: torch.Tensor) -> None:
        """
        Update center buffer using EMA.

        Args:
            teacher_output: [B, num_objects, P] — teacher assignment logits
        """
        self.reduce_center_update(teacher_output)

    @torch.no_grad()
    def reduce_center_update(self, teacher_output: torch.Tensor) -> None:
        """
        Accumulate center update across distributed processes.
        """
        self.updated = False
        B, K, P = teacher_output.shape
        self.len_teacher_output = B * P

        # Average over batch and patch dimensions: [K, 1]
        center_update = teacher_output.mean(dim=0).mean(dim=-1, keepdim=True).unsqueeze(0)  # [1, K, 1]
        self.async_batch_center = center_update

        if dist.is_initialized():
            self.reduce_handle = dist.all_reduce(
                self.async_batch_center,
                async_op=True,
                group=get_process_subgroup(),
            )

    @torch.no_grad()
    def apply_center_update(self) -> None:
        if not self.updated:
            world_size = get_subgroup_size() if dist.is_initialized() else 1

            if self.reduce_handle is not None:
                self.reduce_handle.wait()
            _t = self.async_batch_center / (self.len_teacher_output * world_size)

            self.center = self.center * self.center_momentum + _t * (1 - self.center_momentum)

            self.updated = True
