# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This software may be used and distributed in accordance with
# the terms of the DINOv3 License Agreement.

import gc
import logging
import sys
from functools import partial

import torch
from omegaconf import OmegaConf
from torch import Tensor, nn

import dinov3.distributed as distributed
from dinov3.checkpointer import init_fsdp_model_from_checkpoint
from dinov3.configs import get_default_config
from dinov3.data import DataAugmentationDINO
from dinov3.fsdp.ac_compile_parallelize import ac_compile_parallelize
from dinov3.layers.dino_head import DINOHead
from dinov3.loss import DINOLoss, GramLoss, KoLeoLoss, KoLeoLossDistributed, iBOTPatchLoss, ObjectLoss
from dinov3.models import build_model_from_cfg
from dinov3.models.RS_vision_transformer import build_model_from_cfg_QH
from dinov3.train.cosine_lr_scheduler import linear_warmup_cosine_decay
from dinov3.train.param_groups import fuse_params_groups, get_params_groups_with_decay_fsdp
from dinov3.utils import count_parameters

# Olmoearth 占位模块 — 生产环境需替换为真实 OlmoEarth 预训练推理
from dinov3.models.olmoearth_placeholder import Olmoearth

logger = logging.getLogger("dinov3")


class SSLMetaArch_QH2(nn.Module):
    """
    Modified version of SSLMetaArchCompilable including gram loss:
    - Gram loss is used only if gram.use_loss is set to true
    """

    def __init__(self, cfg):
        super().__init__()

        # assert cfg.multidistillation.enabled is False
        # assert cfg.crops.local_crops_number > 0
        # assert cfg.ibot.separate_head is True
        # assert cfg.train.centering == "sinkhorn_knopp"

        # For some reason FULL_SHARD doesn't work
        # assert cfg.compute_precision.sharding_strategy == "SHARD_GRAD_OP"

        self.cfg = cfg

        # --- Gram defaults (disabled in QH2) ---
        self.gram_use_loss = False
        self.has_gram_teacher = False
        self.gram_it_load_ema_teacher = -1
        self.gram_rep_update = False
        self.gram_it_first_update = 0
        self.gram_update_frequency = 1
        self.gram_teacher = None
        self.gram_teacher_initialized = False
        self.gram_params_lists = None
        self.gram_loss_weight = 0.0
        self.gram_loss_schedule = None

        student_model_dict = dict() # student_model中需要包含四个部分--part1 DINO VIT；part2 Olmoearth；part3 Uphead；part4 Fusion
        teacher_model_dict = dict()
        # gram_model_dict = dict()

        # 定义模型：teacher(DinoVisionTransformer) student(DinoVisionTransformer dropout),embed_dim=student.embed_dim
        ######## Part1: HR encoder ######## 原始的dinov3 vit
        hr_student_backbone, hr_teacher_backbone, hr_embed_dim = build_model_from_cfg(cfg)
        torch.cuda.empty_cache()
        gc.collect()
        # gram_backbone, _ = build_model_from_cfg(cfg, only_teacher=True)
        logger.info(f"Number of parameters: {count_parameters(hr_student_backbone)}")
        student_model_dict["hr_backbone"] = hr_student_backbone
        teacher_model_dict["hr_backbone"] = hr_teacher_backbone
        # gram_model_dict["backbone"] = gram_backbone
        logger.info(f"OPTIONS -- architecture : embed_dim: {hr_embed_dim}")

        self.hr_embed_dim = hr_embed_dim  # D
 
        self.dino_out_dim = cfg.dino.head_n_prototypes  # K

        # 此部分暂时待定
        logger.info("OPTIONS -- DINO")
        logger.info(f"OPTIONS -- DINO -- loss_weight: {cfg.dino.loss_weight}")
        logger.info(f"OPTIONS -- DINO -- global_ignore_diagonal: {cfg.dino.global_ignore_diagonal}")
        logger.info(f"OPTIONS -- DINO -- head_n_prototypes: {cfg.dino.head_n_prototypes}")
        logger.info(f"OPTIONS -- DINO -- head_bottleneck_dim: {cfg.dino.head_bottleneck_dim}")
        logger.info(f"OPTIONS -- DINO -- head_hidden_dim: {cfg.dino.head_hidden_dim}")
        logger.info(f"OPTIONS -- DINO -- head_norm_last_layer: {cfg.dino.head_norm_last_layer}")
        dino_head_class = partial(  # 可选项，后续计算loss时可能需要
            DINOHead,
            in_dim=hr_embed_dim,
            out_dim=cfg.dino.head_n_prototypes,
            hidden_dim=cfg.dino.head_hidden_dim,
            bottleneck_dim=cfg.dino.head_bottleneck_dim,
            nlayers=cfg.dino.head_nlayers,
        )
        student_model_dict["dino_head"] = dino_head_class()
        teacher_model_dict["dino_head"] = dino_head_class()
        self.dino_loss = DINOLoss(self.dino_out_dim)

        # ---- HR iBOT head (用于 HR ViT 补丁令牌的 iBOT loss, 替代原来的 pixel loss) ----
        # iBOT 头使用与 DINO 相同的 prototype 数量, 或使用 cfg.ibot.head_n_prototypes
        ibot_out_dim = getattr(cfg.ibot, 'head_n_prototypes', cfg.dino.head_n_prototypes)
        ibot_head_class = partial(
            DINOHead,
            in_dim=hr_embed_dim,
            out_dim=ibot_out_dim,
            hidden_dim=getattr(cfg.ibot, 'head_hidden_dim', cfg.dino.head_hidden_dim),
            bottleneck_dim=getattr(cfg.ibot, 'head_bottleneck_dim', cfg.dino.head_bottleneck_dim),
            nlayers=getattr(cfg.ibot, 'head_nlayers', cfg.dino.head_nlayers),
        )
        student_model_dict["hr_ibot_head"] = ibot_head_class()
        teacher_model_dict["hr_ibot_head"] = ibot_head_class()
        self.hr_ibot_loss = iBOTPatchLoss(ibot_out_dim)
        logger.info(f"OPTIONS -- iBOT (HR) -- head_n_prototypes: {ibot_out_dim}")

        # ---- QH2 loss weights (configurable via cfg in production) ----
        # HR iBOT loss 权重: 复用原 pixel_loss_weight (默认 0.1)
        self.hr_ibot_loss_weight = getattr(cfg, 'pixel_loss_weight', 0.1)
        # Fusion DINO loss 权重: 新增配置 (默认 0.1)
        self.fusion_dino_loss_weight = getattr(cfg, 'fusion_dino_loss_weight', 0.1)
        # Fusion iBOT loss 权重: 新增配置 (默认 0.1)
        self.fusion_ibot_loss_weight = getattr(cfg, 'fusion_ibot_loss_weight', 0.1)
        logger.info(f"OPTIONS -- HR iBOT loss weight: {self.hr_ibot_loss_weight}")
        logger.info(f"OPTIONS -- Fusion DINO loss weight: {self.fusion_dino_loss_weight}")
        logger.info(f"OPTIONS -- Fusion iBOT loss weight: {self.fusion_ibot_loss_weight}")

        # ---- Direct CE Loss 模式 (可选, 跳过 DINOHead 投影, 直接在 768 维计算，保留 Sinkhorn-Knopp + Center + EMA + Student temp) ----
        self.use_direct_ce_loss = getattr(cfg, 'use_direct_ce_loss', False)
        self.direct_ce_temperature = getattr(cfg, 'direct_ce_temperature', 0.1)
        if self.use_direct_ce_loss:
            logger.info("OPTIONS -- use_direct_ce_loss: True (绕过 DINOHead 投影, 在 %d 维直接计算 CE with SK+Center)", self.hr_embed_dim)
            logger.info("OPTIONS -- direct_ce_temperature: %s", self.direct_ce_temperature)
            self.dino_loss_768 = DINOLoss(self.hr_embed_dim, student_temp=self.direct_ce_temperature)
            self.hr_ibot_loss_768 = iBOTPatchLoss(self.hr_embed_dim, student_temp=self.direct_ce_temperature)
            self.fusion_dino_loss_768 = DINOLoss(self.hr_embed_dim, student_temp=self.direct_ce_temperature)
            self.fusion_ibot_loss_768 = iBOTPatchLoss(self.hr_embed_dim, student_temp=self.direct_ce_temperature)
            logger.info("OPTIONS -- Direct CE 768-dim losses created (DINO + iBOT, all with SK + Center + EMA + Student temp)")
        else:
            logger.info("OPTIONS -- use_direct_ce_loss: False (使用 DINOHead 投影 + Sinkhorn-Knopp)")

        # ---- Fusion DINO head & loss (用于 Fusion ViT 的 CLS 级别的 DINO 损失) ----
        fusion_dino_head_class = partial(
            DINOHead,
            in_dim=hr_embed_dim,
            out_dim=cfg.dino.head_n_prototypes,
            hidden_dim=cfg.dino.head_hidden_dim,
            bottleneck_dim=cfg.dino.head_bottleneck_dim,
            nlayers=cfg.dino.head_nlayers,
        )
        student_model_dict["fusion_dino_head"] = fusion_dino_head_class()
        teacher_model_dict["fusion_dino_head"] = fusion_dino_head_class()
        self.fusion_dino_loss = DINOLoss(self.dino_out_dim)
        logger.info("OPTIONS -- Fusion DINO head & loss created")

        # ---- Fusion iBOT head & loss (用于 Fusion ViT 的 patch 级别的 iBOT 损失) ----
        fusion_ibot_out_dim = getattr(cfg.ibot, 'head_n_prototypes', cfg.dino.head_n_prototypes)
        fusion_ibot_head_class = partial(
            DINOHead,
            in_dim=hr_embed_dim,
            out_dim=fusion_ibot_out_dim,
            hidden_dim=getattr(cfg.ibot, 'head_hidden_dim', cfg.dino.head_hidden_dim),
            bottleneck_dim=getattr(cfg.ibot, 'head_bottleneck_dim', cfg.dino.head_bottleneck_dim),
            nlayers=getattr(cfg.ibot, 'head_nlayers', cfg.dino.head_nlayers),
        )
        student_model_dict["fusion_ibot_head"] = fusion_ibot_head_class()
        teacher_model_dict["fusion_ibot_head"] = fusion_ibot_head_class()
        self.fusion_ibot_loss = iBOTPatchLoss(fusion_ibot_out_dim)
        logger.info(f"OPTIONS -- Fusion iBOT head & loss created (out_dim={fusion_ibot_out_dim})")

        # ---- Object Loss (SkySense++ inspired) ----
        # Object Loss 预测 patch tokens 的对象/语义类别分布
        # 采用与 iBOTPatchLoss 相同的 Sinkhorn-Knopp + Center EMA + Student Temperature + CE 模式
        # HR Object: HR ViT patch tokens → ObjectHead → SK centering → CE
        # Fusion Object: Fusion ViT patch tokens → ObjectHead → SK centering → CE
        object_out_dim = getattr(cfg, 'object_head_n_prototypes', ibot_out_dim)
        object_head_class = partial(
            DINOHead,
            in_dim=hr_embed_dim,
            out_dim=object_out_dim,
            hidden_dim=getattr(cfg, 'object_head_hidden_dim', cfg.dino.head_hidden_dim),
            bottleneck_dim=getattr(cfg, 'object_head_bottleneck_dim', cfg.dino.head_bottleneck_dim),
            nlayers=getattr(cfg, 'object_head_nlayers', cfg.dino.head_nlayers),
        )
        student_model_dict["hr_object_head"] = object_head_class()
        teacher_model_dict["hr_object_head"] = object_head_class()
        self.hr_object_loss = ObjectLoss(object_out_dim)
        student_model_dict["fusion_object_head"] = object_head_class()
        teacher_model_dict["fusion_object_head"] = object_head_class()
        self.fusion_object_loss = ObjectLoss(object_out_dim)
        self.hr_object_loss_weight = getattr(cfg, 'hr_object_loss_weight', 0.1)
        self.fusion_object_loss_weight = getattr(cfg, 'fusion_object_loss_weight', 0.1)
        logger.info(f"OPTIONS -- Object Loss -- head_n_prototypes: {object_out_dim}")
        logger.info(f"OPTIONS -- Object Loss -- HR weight: {self.hr_object_loss_weight}")
        logger.info(f"OPTIONS -- Object Loss -- Fusion weight: {self.fusion_object_loss_weight}")

        ######## Part2: Olmoearth encoder (3 路独立) ########
        # Sentinel-2 / Sentinel-1 / Landsat 各有独立的时间步数和通道数
        # 每个卫星数据共享一个 Olmoearth 实例，但独立调用
        olmoearth = Olmoearth(embed_dim=hr_embed_dim)
        olmoearth.requires_grad_(False)

        student_model_dict['olmoearth'] = olmoearth
        teacher_model_dict['olmoearth'] = olmoearth

        ######### Part3: 跨模态融合 (移除 UPHead / ViT1-CLS，逐时间自注意力) ########
        # 时序拼接: 每个空间位置序列 = [HR(1), OE(T_sum)] → ViT-2 内部加 CLS → [2+T_sum, D]
        # Fusion ViT 沿时间维度做自注意力 (不是空间维度)，输出 CLS token

        ######## Part4: Fusion encoder ########
        # QHVisionTransformer: 对每个空间位置的 [1+T_sum, D] 序列做逐时间自注意力编码
        fusion_student_backbone, fusion_teacher_backbone, fusion_embed_dim = build_model_from_cfg_QH(cfg)
        torch.cuda.empty_cache()
        gc.collect()
        # gram_backbone, _ = build_model_from_cfg(cfg, only_teacher=True)
        logger.info(f"Number of parameters: {count_parameters(fusion_student_backbone)}")
        student_model_dict["fusion_backbone"] = fusion_student_backbone
        teacher_model_dict["fusion_backbone"] = fusion_teacher_backbone

        # Build student and teacher models
        self.student = nn.ModuleDict(student_model_dict)
        self.teacher = nn.ModuleDict(teacher_model_dict)
        self.model_ema = self.teacher  # this may be overwritten for distillation
        logger.info(f"Student and Teacher are built: they are both {cfg.student.arch} network.")

        if cfg.distillation.enabled:
            self._setup_distillation()
        # No grad is needed for these two
        self.teacher.requires_grad_(False)
        self.model_ema.requires_grad_(False)
        self.ema_params_lists = None

        # getting config params fixed:
        # self.n_local_crops = self.cfg.crops.local_crops_number
        # self.is_distillation_enabled = self.cfg.distillation.enabled
        self.dino_global_ignore_diagonal = self.cfg.dino.global_ignore_diagonal
        self.dino_loss_weight = self.cfg.dino.loss_weight
        # self.dino_koleo_loss_weight = self.cfg.dino.koleo_loss_weight
        # self.ibot_loss_weight = self.cfg.ibot.loss_weight

        # Local loss reweighting
        if self.cfg.dino.reweight_dino_local_loss:
            iter_per_epoch = cfg.train.OFFICIAL_EPOCH_LENGTH
            total_iterations = iter_per_epoch * cfg.optim.epochs
            schedule_cfg = cfg.dino.local_loss_weight_schedule
            self.dino_local_loss_schedule = linear_warmup_cosine_decay(
                start=schedule_cfg.start,
                peak=schedule_cfg.peak,
                end=schedule_cfg.end,
                warmup_iterations=iter_per_epoch * schedule_cfg.warmup_epochs,
                total_iterations=total_iterations,
                cosine_iterations=(
                    iter_per_epoch * schedule_cfg.cosine_epochs if "cosine_epochs" in schedule_cfg else None
                ),
            )

        # Gram
        # self.gram_use_loss = self.cfg.gram.use_loss
        # self.gram_ema_teacher = False
        # self.has_gram_teacher = False
        # self.gram_teacher_initialized = False
        # if self.gram_use_loss:
        #     # Gram regularization
        #     self.gram_loss = GramLoss(
        #         apply_norm=self.cfg.gram.normalized,
        #         remove_only_teacher_neg=self.cfg.gram.remove_only_teacher_neg,
        #         remove_neg=self.cfg.gram.remove_neg,
        #     )
        #     # Construct gram teacher
        #     self.has_gram_teacher = True if not cfg.gram.ema_teacher else False
        #     if self.has_gram_teacher:
        #         self.gram_teacher = nn.ModuleDict(gram_model_dict)
        #         self.gram_teacher.requires_grad_(False)
        #         logger.info(f"Gram teacher parameter at init: {next(self.gram_teacher.named_parameters())}")
        #     else:
        #         self.gram_teacher = None

        #     self.gram_loss_weight = self.cfg.gram.loss_weight
        #     if self.cfg.gram.get("loss_weight_schedule"):
        #         iter_per_epoch = cfg.train.OFFICIAL_EPOCH_LENGTH
        #         total_iterations = iter_per_epoch * cfg.optim.epochs
        #         schedule_cfg = self.cfg.gram.loss_weight_schedule
        #         self.gram_loss_schedule = linear_warmup_cosine_decay(
        #             start=schedule_cfg.start,
        #             peak=schedule_cfg.peak,
        #             end=schedule_cfg.end,
        #             warmup_iterations=iter_per_epoch * schedule_cfg.warmup_epochs,
        #             total_iterations=total_iterations,
        #             cosine_iterations=(
        #                 iter_per_epoch * schedule_cfg.cosine_epochs if "cosine_epochs" in schedule_cfg else None
        #             ),
        #         )
        #         logger.info(f"Applying gram loss weight schedule instead of `cfg.gram.loss_weight`: {schedule_cfg}")
        #     else:
        #         self.gram_loss_schedule = None
        #     self.gram_ema_teacher = self.cfg.gram.ema_teacher  # If true use the EMA_teacher as gram_teacher
        #     self.gram_ckpt = self.cfg.gram.ckpt  # Checkpoint to the first gram teacher model
        #     self.gram_img_level = self.cfg.gram.img_level  # Apply the loss on the image, if false on the batch
        #     self.gram_tokens_used = self.cfg.gram.tokens_used  # Any value in ["all", "masked", "unmasked"]
        #     # Update the teacher frequently
        #     self.gram_rep_update = self.cfg.gram.rep_update  # bool, if yes the gram teacher will be updated at the freq
        #     self.gram_update_frequency = self.cfg.gram.update_frequency  # defined by this var update_frequency
        #     self.gram_it_first_update = self.cfg.gram.it_first_update  # after iteration it_first_update is passed.
        #     self.gram_it_load_ema_teacher = (
        #         self.cfg.gram.it_load_ema_teacher
        #     )  # after iteration it_load_ema the ema teacher is loaded into the gram teacher
        #     self.gram_compute_stats = self.cfg.gram.compute_stats  # whether to compute auxiliary stats
        #     self.gram_params_lists = None

        #     if self.gram_ema_teacher and self.gram_ckpt is not None:
        #         raise ValueError(
        #             "Cannot use both `gram.ema_teacher` and `gram.ckpt` at the same time. Please set one of them to False."
        #         )
        #     if self.gram_ckpt is None and self.gram_it_load_ema_teacher < 0:
        #         raise ValueError(
        #             "If no gram checkpoint is provided, `gram.it_load_ema_teacher` must be set to a non-negative value."
        #         )

        #     assert not (self.gram_ema_teacher and self.gram_rep_update)
        #     assert self.gram_tokens_used in ["all", "masked", "unmasked"]
        #     # Currently using masked/unmasked not handle at the image-level
        #     if self.gram_tokens_used in ["masked", "unmasked"]:
        #         assert self.gram_img_level is False

        #     logger.info("OPTIONS -- GRAM")
        #     logger.info(f"OPTIONS -- GRAM -- loss_weight: {cfg.gram.loss_weight}")
        #     logger.info(f"OPTIONS -- GRAM -- ema teacher: {cfg.gram.ema_teacher}")
        #     logger.info(f"OPTIONS -- GRAM -- ckpt: {cfg.gram.ckpt}")
        #     if self.cfg.gram.rep_update:
        #         logger.info(f"OPTIONS -- GRAM -- repeated update: {cfg.gram.rep_update}")
        #         logger.info(f"OPTIONS -- GRAM -- update freq: {cfg.gram.update_frequency}")
        #         logger.info(f"OPTIONS -- GRAM -- iteration first update: {cfg.gram.it_first_update}")

        #     logger.info(f"OPTIONS -- GRAM -- tokens_used: {cfg.gram.tokens_used}")
        #     logger.info(f"OPTIONS -- GRAM -- apply normalization: {cfg.gram.normalized}")
        #     logger.info(f"OPTIONS -- GRAM -- img_level: {cfg.gram.img_level}")
        #     logger.info(f"OPTIONS -- GRAM -- remove_neg: {cfg.gram.remove_neg}")
        #     logger.info(f"OPTIONS -- GRAM -- remove_only_teacher_neg: {cfg.gram.remove_only_teacher_neg}")

        #     if cfg.crops.gram_teacher_crops_size is None and self.has_gram_teacher:
        #         raise ValueError("cfg.crops.gram_teacher_crops_size must be set to use gram loss")
        #     if cfg.crops.gram_teacher_crops_size is not None and self.gram_ema_teacher:
        #         raise ValueError("cfg.crops.gram_teacher_crops_size shoud be None when gram.ema_teacher=True")

        #     self.student_crop_size = cfg.crops.global_crops_size
        #     self.gram_global_teacher_resize_method = cfg.gram.global_teacher_resize_method
        #     self.gram_global_teacher_resize_antialias = cfg.gram.global_teacher_resize_antialias
        #     logger.info(f"OPTIONS -- global crops student/teacher size: {self.student_crop_size}")
        #     logger.info(f"OPTIONS -- global crops GRAM teacher size: {cfg.crops.gram_teacher_crops_size}")
        #     logger.info(f"OPTIONS -- global crops GRAM teacher resize method: {cfg.gram.global_teacher_resize_method}")
        #     logger.info(
        #         f"OPTIONS -- global crops GRAM teacher resize antialias: {cfg.gram.global_teacher_resize_antialias}"
        #     )

    def _setup_distillation(self):
        logger.info(f"Performing distillation from {self.cfg.distillation.full_cfg_path}")

        default_cfg = get_default_config()
        distillation_cfg = OmegaConf.load(self.cfg.distillation.full_cfg_path)
        distillation_cfg = OmegaConf.merge(default_cfg, distillation_cfg)

        assert distillation_cfg.ibot.separate_head is True
        assert distillation_cfg.ibot.head_n_prototypes == self.cfg.ibot.head_n_prototypes, (
            f"{distillation_cfg.ibot.head_n_prototypes} != {self.cfg.ibot.head_n_prototypes}"
        )
        assert distillation_cfg.dino.head_n_prototypes == self.cfg.dino.head_n_prototypes, (
            f"{distillation_cfg.dino.head_n_prototypes} != {self.cfg.dino.head_n_prototypes}"
        )
        assert distillation_cfg.student.patch_size == self.cfg.student.patch_size

        teacher_model_dict = dict()

        backbone, embed_dim = build_model_from_cfg(distillation_cfg, only_teacher=True)
        teacher_model_dict["backbone"] = backbone

        teacher_model_dict["dino_head"] = DINOHead(
            in_dim=embed_dim,
            out_dim=distillation_cfg.dino.head_n_prototypes,
            hidden_dim=distillation_cfg.dino.head_hidden_dim,
            bottleneck_dim=distillation_cfg.dino.head_bottleneck_dim,
            nlayers=distillation_cfg.dino.head_nlayers,
        )
        teacher_model_dict["ibot_head"] = DINOHead(
            in_dim=embed_dim,
            out_dim=distillation_cfg.ibot.head_n_prototypes,
            hidden_dim=distillation_cfg.ibot.head_hidden_dim,
            bottleneck_dim=distillation_cfg.ibot.head_bottleneck_dim,
            nlayers=distillation_cfg.ibot.head_nlayers,
        )
        self.teacher = nn.ModuleDict(teacher_model_dict)

    def init_weights(self) -> None:
        # All weights are set to `nan` to ensure we initialize everything explicitly
        self.student.hr_backbone.init_weights()
        self.student.fusion_backbone.init_weights()
        self.student.dino_head.init_weights()
        self.student.hr_ibot_head.init_weights()
        self.student.fusion_dino_head.init_weights()
        self.student.fusion_ibot_head.init_weights()
        self.student.hr_object_head.init_weights()
        self.student.fusion_object_head.init_weights()
        self.dino_loss.init_weights()
        self.hr_ibot_loss.init_weights()
        self.fusion_dino_loss.init_weights()
        self.fusion_ibot_loss.init_weights()
        self.hr_object_loss.init_weights()
        self.fusion_object_loss.init_weights()
        if self.use_direct_ce_loss:
            self.dino_loss_768.init_weights()
            self.hr_ibot_loss_768.init_weights()
            self.fusion_dino_loss_768.init_weights()
            self.fusion_ibot_loss_768.init_weights()
        self.model_ema.load_state_dict(self.student.state_dict())
        # if self.has_gram_teacher:
        #     if self.gram_ckpt is not None:
        #         logger.info(f"Loading pretrained weights from {self.gram_ckpt}")
        #         init_fsdp_model_from_checkpoint(
        #             self.gram_teacher,
        #             self.gram_ckpt,
        #             skip_load_keys=[
        #                 "dino_head",
        #                 "ibot_head",
        #                 "dino_loss.center",
        #                 "ibot_patch_loss.center",
        #             ],
        #             keys_not_sharded=["backbone.rope_embed.periods", "qkv.bias_mask"],
        #             process_group=distributed.get_default_process_group(),
        #         )
        #         self.gram_teacher_initialized = True
        #     else:
        #         raise ValueError(f"Provide a correct path to {self.gram_ckpt}")
        #     self.gram_teacher.requires_grad_(False)
        #     self.gram_teacher.eval()
        if self.cfg.student.resume_from_teacher_chkpt:
            logger.info(f"Loading pretrained weights from {self.cfg.student.resume_from_teacher_chkpt}")
            init_fsdp_model_from_checkpoint(
                self.student,
                self.cfg.student.resume_from_teacher_chkpt,
                skip_load_keys=["dino_loss.center", "ibot_patch_loss.center"],
                keys_not_sharded=["backbone.rope_embed.periods", "qkv.bias_mask"],
                process_group=distributed.get_process_subgroup(),
            )
            self.model_ema.load_state_dict(self.student.state_dict())
        if self.cfg.distillation.enabled:
            if self.cfg.distillation.checkpoint_path != "ignore":
                logger.info(f"Loading teacher to distil from : {self.cfg.distillation.checkpoint_path}")
                init_fsdp_model_from_checkpoint(
                    self.teacher,
                    self.cfg.distillation.checkpoint_path,
                    skip_load_keys=["dino_loss.center", "ibot_patch_loss.center"],
                    keys_not_sharded=["backbone.rope_embed.periods", "qkv.bias_mask"],
                    process_group=distributed.get_default_process_group(),
                )
            else:
                logger.info("Init teacher to distil from, used for testing purpose only")
                self.teacher.backbone.init_weights()
                self.teacher.dino_head.init_weights()
                # self.teacher.ibot_head.init_weights()
            logger.info(f"Performing distillation from: {self.teacher}")

    def forward_backward(
        self, data, *, teacher_temp, iteration=0, **ignored_kwargs
    ) -> tuple[Tensor, dict[str, float | Tensor]]:
        """
        训练循环 — v7: 六部分损失结构 (新增 Object Loss)

        损失组成:
          1. HR DINO Loss  — HR ViT CLS 级别的 DINO 损失 (CLS 级)
          2. HR iBOT Loss  — HR ViT patch 级别的 iBOT 损失 (patch 级)
          3. HR Object Loss — HR ViT patch 级别的 Object 损失 (patch 级, SkySense++ 风格)
          4. Fusion DINO Loss — Fusion ViT CLS 级别的 DINO 损失 (CLS 级)
          5. Fusion iBOT Loss — Fusion ViT patch 级别的 iBOT 损失 (patch 级)
          6. Fusion Object Loss — Fusion ViT patch 级别的 Object 损失 (patch 级, SkySense++ 风格)

          Total Loss = dino_loss_weight          * hr_dino_loss
                     + hr_ibot_loss_weight        * hr_ibot_loss
                     + hr_object_loss_weight      * hr_object_loss
                     + fusion_dino_loss_weight    * fusion_dino_loss
                     + fusion_ibot_loss_weight    * fusion_ibot_loss
                     + fusion_object_loss_weight  * fusion_object_loss

        data 包含:
          hr_image_student:  [B, 3, H_hr, W_hr]
          hr_image_teacher:  [B, 3, H_hr, W_hr]
          h5_data:           {"s2": [B,H,W,T1,C1], "s1": [B,H,W,T2,C2], "ls": [B,H,W,T3,C3]}
        """
        del ignored_kwargs
        metrics_dict = {}

        hr_image_student = data.get("hr_image_student", data.get("collated_global_crops", None))
        hr_image_teacher = data.get("hr_image_teacher", data.get("collated_global_crops", None))

        if hr_image_student is None:
            # Standard DataLoader: convert from DINO format
            images = data["collated_global_crops"]
            hr_image_student = images[0] if isinstance(images, list) else images
            hr_image_teacher = images[0] if isinstance(images, list) else images

        hr_image_student = hr_image_student.cuda(non_blocking=True)
        hr_image_teacher = hr_image_teacher.cuda(non_blocking=True)

        if "h5_data" in data:
            h5_data = {
                k: v.cuda(non_blocking=True)
                for k, v in data["h5_data"].items()
            }
        else:
            # Placeholder: zeros when H5 data absent (for verification)
            B = hr_image_student.shape[0]
            D = self.hr_embed_dim
            h5_data = {
                "s2": torch.zeros(B, 4, 4, 1, D, device=hr_image_student.device),
                "s1": torch.zeros(B, 4, 4, 1, D, device=hr_image_student.device),
                "ls": torch.zeros(B, 4, 4, 1, D, device=hr_image_student.device),
            }

        # --- Teacher 输出 (no_grad) ---
        t_out = self.get_teacher_output(hr_image_teacher, h5_data)
        teacher_hr_output = t_out["hr"]
        teacher_hr_ibot_centered = t_out["hr_ibot_centered"]          # [B, P, K_ibot]
        teacher_hr_object_centered = t_out["hr_object_centered"]      # [B, P, K_obj]
        teacher_fusion_cls_centered = t_out["fusion_cls_centered"]    # [B, K_dino]
        teacher_fusion_patch_centered = t_out["fusion_patch_centered"] # [N_spatial, T_eff, K_ibot]
        teacher_fusion_object_centered = t_out["fusion_object_centered"] # [N_spatial, T_eff, K_obj]

        # --- Student 输出 ---
        s_out = self.get_student_output(hr_image_student, h5_data)
        student_hr_output = s_out["hr"]
        student_hr_ibot_after_head = s_out["hr_ibot_after_head"]          # [B, P, K_ibot]
        student_hr_object_after_head = s_out["hr_object_after_head"]      # [B, P, K_obj]
        student_fusion_cls_after_head = s_out["fusion_cls_after_head"]    # [N_spatial, K_dino]
        student_fusion_patch_after_head = s_out["fusion_patch_after_head"] # [N_spatial, T_eff, K_ibot]
        student_fusion_object_after_head = s_out["fusion_object_after_head"] # [N_spatial, T_eff, K_obj]

        loss_dict = {}

        # ---- 1. HR DINO Loss: CLS 级别的 DINO 损失 (HR ViT) ----
        if self.use_direct_ce_loss:
            # 直接 CE: 使用 dino_loss_768 (SK + Center + EMA + Student temp)
            hr_cls_student = student_hr_output["cls_after_head"].unsqueeze(0)   # [1, B, D]
            hr_cls_teacher = teacher_hr_output["cls_centered"].unsqueeze(0)      # [1, B, D]
            hr_dino_loss_val = self.dino_loss_768(hr_cls_student, hr_cls_teacher)
        else:
            # DINOLoss expects [crops, batch, K], single crop → unsqueeze dim 0
            hr_cls_student = student_hr_output["cls_after_head"].unsqueeze(0)   # [1, B, K]
            hr_cls_teacher = teacher_hr_output["cls_centered"].unsqueeze(0)      # [1, B, K]
            hr_dino_loss_val = self.dino_loss(hr_cls_student, hr_cls_teacher)
        loss_dict["hr_dino_loss"] = hr_dino_loss_val
        loss_accumulator = self.dino_loss_weight * hr_dino_loss_val

        # ---- 2. HR iBOT Loss: patch 级别的 iBOT 损失 (HR ViT) ----
        if self.hr_ibot_loss_weight > 0:
            B_hr, P_hr, _ = student_hr_ibot_after_head.shape
            all_patches_mask = torch.ones(B_hr, P_hr, dtype=torch.bool, device=hr_image_student.device)
            if self.use_direct_ce_loss:
                # 直接 CE: 使用 hr_ibot_loss_768 (SK + Center + EMA + Student temp)
                hr_ibot_loss_val = self.hr_ibot_loss_768(
                    student_hr_ibot_after_head,      # student_patch_tokens [B, P, D]
                    teacher_hr_ibot_centered,         # teacher_patch_tokens [B, P, D]
                    all_patches_mask,                 # student_masks_flat    [B, P]
                )
            else:
                # iBOTPatchLoss.forward(student_patch_tokens, teacher_patch_tokens, student_masks_flat)
                hr_ibot_loss_val = self.hr_ibot_loss(
                    student_hr_ibot_after_head,      # student_patch_tokens [B, P, K]
                    teacher_hr_ibot_centered,         # teacher_patch_tokens [B, P, K]
                    all_patches_mask,                 # student_masks_flat    [B, P]
                )
            loss_dict["hr_ibot_loss"] = hr_ibot_loss_val
            loss_accumulator = loss_accumulator + self.hr_ibot_loss_weight * hr_ibot_loss_val

        # ---- 3. Fusion DINO Loss: CLS 级别的 DINO 损失 (Fusion ViT) ----
        if self.fusion_dino_loss_weight > 0:
            B_f = hr_image_student.shape[0]
            N_spatial = student_fusion_cls_after_head.shape[0]
            P_f = N_spatial // B_f
            # Pool student logits over spatial dim: [N_spatial, K] → [B, K]
            fusion_cls_student_img = student_fusion_cls_after_head.reshape(B_f, P_f, -1).mean(dim=1)  # [B, K]
            if self.use_direct_ce_loss:
                # 直接 CE: 使用 fusion_dino_loss_768 (SK + Center + EMA + Student temp)
                # student [B, D], teacher [B, D] (already SK'd)
                fusion_dino_loss_val = self.fusion_dino_loss_768(
                    fusion_cls_student_img.unsqueeze(0),    # [1, B, D]
                    teacher_fusion_cls_centered.unsqueeze(0), # [1, B, D]
                )
            else:
                fusion_dino_loss_val = self.fusion_dino_loss(
                    fusion_cls_student_img.unsqueeze(0),    # [1, B, K]
                    teacher_fusion_cls_centered.unsqueeze(0), # [1, B, K]
                )
            loss_dict["fusion_dino_loss"] = fusion_dino_loss_val
            loss_accumulator = loss_accumulator + self.fusion_dino_loss_weight * fusion_dino_loss_val

        # ---- 4. Fusion iBOT Loss: patch 级别的 iBOT 损失 (Fusion ViT) ----
        if self.fusion_ibot_loss_weight > 0:
            N_sp, T_ef, _ = student_fusion_patch_after_head.shape
            all_fusion_mask = torch.ones(N_sp, T_ef, dtype=torch.bool, device=hr_image_student.device)
            if self.use_direct_ce_loss:
                # 直接 CE: 使用 fusion_ibot_loss_768 (SK + Center + EMA + Student temp)
                fusion_ibot_loss_val = self.fusion_ibot_loss_768(
                    student_fusion_patch_after_head,   # student_patch_tokens [N_spatial, T_eff, D]
                    teacher_fusion_patch_centered,      # teacher_patch_tokens [N_spatial, T_eff, D]
                    all_fusion_mask,                    # student_masks_flat    [N_spatial, T_eff]
                )
            else:
                fusion_ibot_loss_val = self.fusion_ibot_loss(
                    student_fusion_patch_after_head,   # student_patch_tokens [N_spatial, T_eff, K]
                    teacher_fusion_patch_centered,      # teacher_patch_tokens [N_spatial, T_eff, K]
                    all_fusion_mask,                    # student_masks_flat    [N_spatial, T_eff]
                )
            loss_dict["fusion_ibot_loss"] = fusion_ibot_loss_val
            loss_accumulator = loss_accumulator + self.fusion_ibot_loss_weight * fusion_ibot_loss_val

        # ---- 5. HR Object Loss: patch 级别的 Object 损失 (HR ViT) ----
        if self.hr_object_loss_weight > 0:
            B_hr, P_hr, _ = student_hr_object_after_head.shape
            all_patches_mask_obj = torch.ones(B_hr, P_hr, dtype=torch.bool, device=hr_image_student.device)
            hr_object_loss_val = self.hr_object_loss(
                student_hr_object_after_head,      # student_patch_tokens [B, P, K_obj]
                teacher_hr_object_centered,         # teacher_patch_tokens [B, P, K_obj]
                all_patches_mask_obj,               # student_masks_flat    [B, P]
            )
            loss_dict["hr_object_loss"] = hr_object_loss_val
            loss_accumulator = loss_accumulator + self.hr_object_loss_weight * hr_object_loss_val

        # ---- 6. Fusion Object Loss: patch 级别的 Object 损失 (Fusion ViT) ----
        if self.fusion_object_loss_weight > 0:
            N_sp_obj, T_ef_obj, _ = student_fusion_object_after_head.shape
            all_fusion_mask_obj = torch.ones(N_sp_obj, T_ef_obj, dtype=torch.bool, device=hr_image_student.device)
            fusion_object_loss_val = self.fusion_object_loss(
                student_fusion_object_after_head,   # student_patch_tokens [N_spatial, T_eff, K_obj]
                teacher_fusion_object_centered,      # teacher_patch_tokens [N_spatial, T_eff, K_obj]
                all_fusion_mask_obj,                 # student_masks_flat    [N_spatial, T_eff]
            )
            loss_dict["fusion_object_loss"] = fusion_object_loss_val
            loss_accumulator = loss_accumulator + self.fusion_object_loss_weight * fusion_object_loss_val

        # 反传 & 返回
        self.backprop_loss(loss_accumulator)
        return loss_accumulator, metrics_dict | loss_dict

    def _encode_satellite_timeseries(
        self, side: nn.ModuleDict, h5_data: dict
    ) -> tuple[dict, int, int]:
        """
        Call Olmoearth once to process H5 data dict (S2/S1/LS handled internally).

        Olmoearth(h5_data) → {s2: {features, cls_token}, s1: {...}, ls: {...}}

        Returns:
            oe_feats: dict with per-source raw features in native spatial grid
                      {s2: [B,H,W,T_i,D], s1: [...], ls: [...]}
            H_oe, W_oe: spatial size of Olmoearth output
        """
        oe_out = side.olmoearth(h5_data)  # frozen, single call

        oe_feats = {}
        H_oe, W_oe = None, None

        for src_name in ["s2", "s1", "ls"]:
            features = oe_out[src_name]["features"]  # [B, H_oe, W_oe, T_i, D]
            oe_feats[src_name] = features

            if H_oe is None:
                B, H, W, T_i, D = features.shape
                H_oe, W_oe = H, W

        return oe_feats, H_oe, W_oe

    @torch.no_grad()
    def get_teacher_output(self, hr_image_teacher, h5_data):
        """
        Teacher forward — v7: Object Loss 集成。

        Pipeline:
          1. HR ViT → cls [B,D], patch tokens [B,P,D]
          2. HR DINO: cls → dino_head → sinkhorn-knopp
          3. HR iBOT: patch → hr_ibot_head → sinkhorn-knopp
          4. HR Object: patch → hr_object_head → sinkhorn-knopp
          5. Olmoearth(H5) → per-source features → upsample → concat
          6. Fusion ViT → cls [N_spatial,D], patch [N_spatial,T_fusion,D]
          7. Fusion DINO: cls → fusion_dino_head → sinkhorn-knopp
          8. Fusion iBOT: patch → fusion_ibot_head → sinkhorn-knopp
          9. Fusion Object: patch → fusion_object_head → sinkhorn-knopp

        Returns:
            "hr":                    dict (HR CLS + DINO head + patch)
            "hr_ibot_centered":      [B, P, K_ibot]   (teacher iBOT patch logits centered)
            "hr_object_centered":    [B, P, K_obj]    (teacher Object patch logits centered)
            "hr_patch_spatial":      [B, D, H, H]     (native resolution)
            "fusion_cls_centered":   [B, K_fusion]    (fusion DINO CLS centered)
            "fusion_patch_centered": [N_spatial, T_eff, K_ibot]  (fusion iBOT patch centered)
            "fusion_object_centered":[N_spatial, T_eff, K_obj]   (fusion Object patch centered)
        """
        B = hr_image_teacher.shape[0]

        # --- Step 1: HR backbone ---
        backbone_out = self.teacher.hr_backbone(hr_image_teacher, is_training=True)
        cls_token = backbone_out["x_norm_clstoken"]         # [B, D]
        reg_tokens = backbone_out["x_storage_tokens"]       # [B, R, D]
        hr_patch = backbone_out["x_norm_patchtokens"]       # [B, P, D]

        # --- HR DINO ---
        if self.use_direct_ce_loss:
            # 直接 CE 模式: 跳过 DINOHead 投影 (768→65536), 使用 768维 Sinkhorn-Knopp + Center + EMA
            cls_after_head = cls_token               # [B, D]
            cls_centered = self.dino_loss_768.sinkhorn_knopp_teacher(
                cls_token, teacher_temp=0.04
            )  # [B, D]
        else:
            cls_after_head = self.teacher.dino_head(cls_token)
            cls_centered = self.dino_loss.sinkhorn_knopp_teacher(
                cls_after_head, teacher_temp=0.04
            )

        # --- HR iBOT ---
        if self.use_direct_ce_loss:
            # 直接 CE 模式: 跳过 iBOTHead 投影, 使用 768维 Sinkhorn-Knopp + Center + EMA
            hr_ibot_after_head = hr_patch              # [B, P, D]
            hr_ibot_flat = hr_patch.reshape(B * P, -1)   # [B*P, D]
            n_hr_patches_tensor = torch.tensor(B * P, device=hr_image_teacher.device)
            hr_ibot_centered_flat = self.hr_ibot_loss_768.sinkhorn_knopp_teacher(
                hr_ibot_flat, teacher_temp=0.04,
                n_masked_patches_tensor=n_hr_patches_tensor,
            )  # [B*P, D]
            hr_ibot_centered = hr_ibot_centered_flat.reshape(B, P, -1)  # [B, P, D]
        else:
            hr_ibot_after_head = self.teacher.hr_ibot_head(hr_patch)        # [B, P, K_ibot]
            # sinkhorn_knopp_teacher expects 2D [N, K]; flatten then reshape back
            hr_ibot_flat = hr_ibot_after_head.reshape(B * P, -1)             # [B*P, K_ibot]
            n_hr_patches_tensor = torch.tensor(B * P, device=hr_image_teacher.device)
            hr_ibot_centered_flat = self.hr_ibot_loss.sinkhorn_knopp_teacher(
                hr_ibot_flat, teacher_temp=0.04,
                n_masked_patches_tensor=n_hr_patches_tensor,
            )  # [B*P, K_ibot]
            hr_ibot_centered = hr_ibot_centered_flat.reshape(B, P, -1)       # [B, P, K_ibot]

        # --- HR Object Loss ---
        # Teacher: hr_patch → ObjectHead → Sinkhorn-Knopp centering
        hr_object_after_head = self.teacher.hr_object_head(hr_patch)        # [B, P, K_obj]
        hr_object_flat = hr_object_after_head.reshape(B * P, -1)             # [B*P, K_obj]
        n_hr_object_patches_tensor = torch.tensor(B * P, device=hr_image_teacher.device)
        hr_object_centered_flat = self.hr_object_loss.sinkhorn_knopp_teacher(
            hr_object_flat, teacher_temp=0.04,
            n_masked_patches_tensor=n_hr_object_patches_tensor,
        )  # [B*P, K_obj]
        hr_object_centered = hr_object_centered_flat.reshape(B, P, -1)       # [B, P, K_obj]

        hr_output = {
            "cls_pre_head":   cls_token,
            "reg_pre_head":   reg_tokens,
            "patch_pre_head": hr_patch,
            "cls_after_head": cls_after_head,
            "cls_centered":   cls_centered,
        }

        # --- Step 2: Olmoearth → upsample to HR patch grid ---
        oe_feats, H_oe, W_oe = self._encode_satellite_timeseries(
            self.teacher, h5_data
        )

        D = self.hr_embed_dim
        P = hr_patch.shape[1]
        H_hr_patch = int(P ** 0.5)
        N_spatial = B * P

        hr_spatial = hr_patch.reshape(B, H_hr_patch, H_hr_patch, D).permute(0, 3, 1, 2)
        hr_patch_spatial = hr_spatial  # [B, D, H_hr_patch, H_hr_patch]

        oe_tokens_list = []
        for src_name in ["s2", "s1", "ls"]:
            feats = oe_feats[src_name]
            B_s, H_o, W_o, T_i, D_s = feats.shape
            feats_2d = feats.permute(0, 3, 4, 1, 2).reshape(B_s, T_i * D_s, H_o, W_o)
            if H_o != H_hr_patch or W_o != H_hr_patch:
                feats_2d = torch.nn.functional.interpolate(
                    feats_2d, size=(H_hr_patch, H_hr_patch),
                    mode='bilinear', align_corners=False
                )
            feats_up = feats_2d.reshape(B_s, T_i, D_s, H_hr_patch, H_hr_patch)
            feats_up = feats_up.permute(0, 3, 4, 1, 2)
            tokens = feats_up.reshape(N_spatial, T_i, D_s)
            oe_tokens_list.append(tokens)

        oe_seq = torch.cat(oe_tokens_list, dim=1)

        # --- Step 3: Build per-spatial-location sequence ---
        hr_tokens_spatial = hr_patch.reshape(N_spatial, 1, D)
        fusion_seq = torch.cat([hr_tokens_spatial, oe_seq], dim=1)

        # --- Step 4: Fusion ViT ---
        fusion_out = self.teacher.fusion_backbone(fusion_seq, is_training=True)
        fusion_cls = fusion_out["x_norm_clstoken"]       # [N_spatial, D_fusion]
        fusion_patch = fusion_out["x_norm_patchtokens"]   # [N_spatial, T_eff, D_fusion]

        # --- Fusion DINO ---
        if self.use_direct_ce_loss:
            # 直接 CE: 跳过融合 DINOHead, 使用 768维 Sinkhorn-Knopp + Center + EMA
            fusion_cls_after_head = fusion_cls                # [N_spatial, D]
            fusion_cls_centered = self.fusion_dino_loss_768.sinkhorn_knopp_teacher(
                fusion_cls, teacher_temp=0.04
            )  # [N_spatial, D]
        else:
            fusion_cls_after_head = self.teacher.fusion_dino_head(fusion_cls)       # [N_spatial, K_dino]
            fusion_cls_centered = self.fusion_dino_loss.sinkhorn_knopp_teacher(
                fusion_cls_after_head, teacher_temp=0.04
            )  # [N_spatial, K_dino]

        # --- Fusion iBOT ---
        if self.use_direct_ce_loss:
            # 直接 CE: 跳过融合 iBOTHead, 使用 768维 Sinkhorn-Knopp + Center + EMA
            fusion_patch_after_head = fusion_patch            # [N_spatial, T_eff, D]
            T_eff = fusion_patch.shape[1]
            fusion_patch_flat = fusion_patch.reshape(N_spatial * T_eff, -1)  # [N_spatial*T_eff, D]
            n_fusion_patches_tensor = torch.tensor(N_spatial * T_eff, device=hr_image_teacher.device)
            fusion_patch_centered_flat = self.fusion_ibot_loss_768.sinkhorn_knopp_teacher(
                fusion_patch_flat, teacher_temp=0.04,
                n_masked_patches_tensor=n_fusion_patches_tensor,
            )  # [N_spatial*T_eff, D]
            fusion_patch_centered = fusion_patch_centered_flat.reshape(N_spatial, T_eff, -1)  # [N_spatial, T_eff, D]
        else:
            fusion_patch_after_head = self.teacher.fusion_ibot_head(fusion_patch)   # [N_spatial, T_eff, K_ibot]
            T_eff = fusion_patch.shape[1]
            # sinkhorn_knopp_teacher expects 2D [N, K]; flatten all spatial+time dims
            fusion_patch_flat = fusion_patch_after_head.reshape(N_spatial * T_eff, -1)  # [N_spatial*T_eff, K_ibot]
            n_fusion_patches_tensor = torch.tensor(N_spatial * T_eff, device=hr_image_teacher.device)
            fusion_patch_centered_flat = self.fusion_ibot_loss.sinkhorn_knopp_teacher(
                fusion_patch_flat, teacher_temp=0.04,
                n_masked_patches_tensor=n_fusion_patches_tensor,
            )  # [N_spatial*T_eff, K_ibot]
            fusion_patch_centered = fusion_patch_centered_flat.reshape(N_spatial, T_eff, -1)  # [N_spatial, T_eff, K_ibot]

        # --- Fusion Object Loss ---
        # Teacher: fusion_patch → ObjectHead → Sinkhorn-Knopp centering
        fusion_object_after_head = self.teacher.fusion_object_head(fusion_patch)   # [N_spatial, T_eff, K_obj]
        T_eff_obj = fusion_patch.shape[1]
        fusion_object_flat = fusion_object_after_head.reshape(N_spatial * T_eff_obj, -1)  # [N_spatial*T_eff, K_obj]
        n_fusion_object_patches_tensor = torch.tensor(N_spatial * T_eff_obj, device=hr_image_teacher.device)
        fusion_object_centered_flat = self.fusion_object_loss.sinkhorn_knopp_teacher(
            fusion_object_flat, teacher_temp=0.04,
            n_masked_patches_tensor=n_fusion_object_patches_tensor,
        )  # [N_spatial*T_eff, K_obj]
        fusion_object_centered = fusion_object_centered_flat.reshape(N_spatial, T_eff_obj, -1)  # [N_spatial, T_eff, K_obj]

        # Spatial pool for fusion CLS: [N_spatial, K_dino] → [B, K_dino]
        fusion_cls_img = fusion_cls_centered.reshape(B, P, -1).mean(dim=1)

        return {
            "hr":                     hr_output,
            "hr_ibot_centered":       hr_ibot_centered,          # [B, P, K_ibot]
            "hr_object_centered":     hr_object_centered,        # [B, P, K_obj]
            "hr_patch_spatial":       hr_patch_spatial,           # [B, D, H, H]
            "fusion_cls_centered":    fusion_cls_img,            # [B, K_dino]
            "fusion_patch_centered":  fusion_patch_centered,     # [N_spatial, T_eff, K_ibot]
            "fusion_object_centered": fusion_object_centered,    # [N_spatial, T_eff, K_obj]
        }

    def get_gram_teacher_output(self, images, *, masks, teacher_global, student_global, student_global_crops_size):
        # Get student patch features
        student_patches = student_global["patch_pre_head"].flatten(0, 1)  # [n_crops * B, P, D]

        # Get gram targets
        if self.gram_ema_teacher:
            teacher_patches = teacher_global["patch_pre_head"].flatten(0, 1)  # [n_crops * B, P, D]
        else:
            if not self.gram_teacher_initialized:
                raise ValueError("Gram teacher has not been initialized. Load a checkpoint or from the EMA teacher.")
            n_crops, B, rgb, H, W = images.shape
            images = images.flatten(0, 1)  # [n_crops * B, rgb, H, W]

            with torch.no_grad():
                backbone_out = self.gram_teacher.backbone(images, is_training=True)
            teacher_patches = backbone_out["x_norm_patchtokens"]  # [n_crops * B, P_T, D]

            # Downsample Gram teacher features if needed
            if teacher_patches.shape[1] != student_patches.shape[1]:
                N = H // self.cfg.student.patch_size
                assert teacher_patches.shape[1] == N**2
                N_student = student_global_crops_size // self.cfg.student.patch_size
                assert student_patches.shape[1] == N_student**2
                patches_hw = teacher_patches.transpose(-2, -1).unflatten(-1, (N, N))  # [n_crops * B, D, N, N]
                patches_hw = torch.nn.functional.interpolate(
                    patches_hw,
                    size=(N_student, N_student),
                    mode=self.gram_global_teacher_resize_method,
                    align_corners=False,
                    antialias=self.gram_global_teacher_resize_antialias,
                )
                teacher_patches = patches_hw.flatten(-2, -1).transpose(
                    -2, -1
                )  # [n_crops * B, N_student * N_student, D]
                assert teacher_patches.shape == student_patches.shape

        # Select the patches to be considered in the loss
        orig_student_patches = student_patches
        orig_teacher_patches = teacher_patches
        if self.gram_tokens_used == "masked":
            student_patches = student_patches[masks]
            teacher_patches = teacher_patches[masks]
        elif self.gram_tokens_used == "unmasked":
            student_patches = student_patches[~masks]
            teacher_patches = teacher_patches[~masks]

        return {
            "student_patches": student_patches,  # [n_crops * B, P, D] or [n_selected_patches, D]
            "teacher_patches": teacher_patches,  # [n_crops * B, P, D] or [n_selected_patches, D]
            # Unmasked patches, for computing statistics
            "orig_student_patches": orig_student_patches,  # [n_crops * B, P, D]
            "orig_teacher_patches": orig_teacher_patches,  # [n_crops * B, P, D]
        }

    def get_student_output(self, hr_image_student, h5_data):
        """
        Student forward — v7: Object Loss 集成。

        Pipeline:
          1. HR ViT → cls [B,D], patch tokens [B,P,D]
          2. HR DINO: cls → dino_head
          3. HR iBOT: patch → hr_ibot_head
          4. HR Object: patch → hr_object_head
          5. Olmoearth(H5) → per-source features → upsample → concat
          6. Fusion ViT → cls [N_spatial,D_fusion], patch [N_spatial,T_eff,D_fusion]
          7. Fusion DINO: cls → fusion_dino_head
          8. Fusion iBOT: patch → fusion_ibot_head
          9. Fusion Object: patch → fusion_object_head

        Returns:
            "hr":                     dict (HR CLS + DINO head + patch)
            "hr_ibot_after_head":     [B, P, K_ibot]   (student iBOT patch logits)
            "hr_object_after_head":   [B, P, K_obj]    (student Object patch logits)
            "fusion_cls_after_head":  [N_spatial, K_dino]  (fusion DINO cls logits)
            "fusion_patch_after_head":[N_spatial, T_eff, K_ibot] (fusion iBOT patch logits)
            "fusion_object_after_head":[N_spatial, T_eff, K_obj] (fusion Object patch logits)
        """
        B = hr_image_student.shape[0]

        # --- Step 1: HR backbone ---
        backbone_out = self.student.hr_backbone(hr_image_student, is_training=True)
        g_cls = backbone_out["x_norm_clstoken"]         # [B, D]
        g_reg = backbone_out["x_storage_tokens"]        # [B, R, D]
        g_patch = backbone_out["x_norm_patchtokens"]    # [B, P, D]

        # --- HR DINO ---
        if self.use_direct_ce_loss:
            g_cls_after_head = g_cls  # 直接 CE: 跳过 DINOHead, 保持 [B, D]
        else:
            g_cls_after_head = self.student.dino_head(g_cls)

        # --- HR iBOT ---
        if self.use_direct_ce_loss:
            hr_ibot_after_head = g_patch  # 直接 CE: 跳过 iBOTHead, 保持 [B, P, D]
        else:
            hr_ibot_after_head = self.student.hr_ibot_head(g_patch)  # [B, P, K_ibot]

        # --- HR Object ---
        hr_object_after_head = self.student.hr_object_head(g_patch)  # [B, P, K_obj]

        hr_output = {
            "cls_pre_head": g_cls,
            "reg_pre_head": g_reg,
            "patch_pre_head": g_patch,
            "cls_after_head": g_cls_after_head,
        }

        # --- Step 2: Olmoearth → upsample to HR patch grid ---
        oe_feats, H_oe, W_oe = self._encode_satellite_timeseries(
            self.student, h5_data
        )

        D = self.hr_embed_dim
        P = g_patch.shape[1]
        H_hr_patch = int(P ** 0.5)
        N_spatial = B * P

        oe_tokens_list = []
        for src_name in ["s2", "s1", "ls"]:
            feats = oe_feats[src_name]
            B_s, H_o, W_o, T_i, D_s = feats.shape
            feats_2d = feats.permute(0, 3, 4, 1, 2).reshape(B_s, T_i * D_s, H_o, W_o)
            if H_o != H_hr_patch or W_o != H_hr_patch:
                feats_2d = torch.nn.functional.interpolate(
                    feats_2d, size=(H_hr_patch, H_hr_patch),
                    mode='bilinear', align_corners=False
                )
            feats_up = feats_2d.reshape(B_s, T_i, D_s, H_hr_patch, H_hr_patch)
            feats_up = feats_up.permute(0, 3, 4, 1, 2)
            tokens = feats_up.reshape(N_spatial, T_i, D_s)
            oe_tokens_list.append(tokens)

        oe_seq = torch.cat(oe_tokens_list, dim=1)

        # --- Step 3: Build per-spatial-location sequence ---
        hr_tokens_spatial = g_patch.reshape(N_spatial, 1, D)
        fusion_seq = torch.cat([hr_tokens_spatial, oe_seq], dim=1)

        # --- Step 4: Fusion ViT ---
        fusion_out = self.student.fusion_backbone(fusion_seq, is_training=True)
        fusion_cls = fusion_out["x_norm_clstoken"]       # [N_spatial, D_fusion]
        fusion_patch = fusion_out["x_norm_patchtokens"]   # [N_spatial, T_eff, D_fusion]

        # --- Fusion DINO ---
        if self.use_direct_ce_loss:
            fusion_cls_after_head = fusion_cls
        else:
            fusion_cls_after_head = self.student.fusion_dino_head(fusion_cls)       # [N_spatial, K_dino]

        # --- Fusion iBOT ---
        if self.use_direct_ce_loss:
            fusion_patch_after_head = fusion_patch
        else:
            fusion_patch_after_head = self.student.fusion_ibot_head(fusion_patch)   # [N_spatial, T_eff, K_ibot]

        # --- Fusion Object ---
        fusion_object_after_head = self.student.fusion_object_head(fusion_patch)   # [N_spatial, T_eff, K_obj]

        return {
            "hr":                        hr_output,
            "hr_ibot_after_head":        hr_ibot_after_head,         # [B, P, K_ibot]
            "hr_object_after_head":      hr_object_after_head,       # [B, P, K_obj]
            "fusion_cls_after_head":     fusion_cls_after_head,      # [N_spatial, K_dino]
            "fusion_patch_after_head":   fusion_patch_after_head,    # [N_spatial, T_eff, K_ibot]
            "fusion_object_after_head":  fusion_object_after_head,   # [N_spatial, T_eff, K_obj]
        }

    def compute_losses(
        self,
        *,
        teacher_global,
        student_global,
        student_local,
        gram_global,
        masks,
        mask_indices_list,
        masks_weight,
        iteration,
    ):
        """
        QH2 mode compute_losses — stub that calls forward_backward instead.
        Only DINO loss is computed here; pixel & fusion losses are in forward_backward.

        This method is kept for backward compatibility with trainers that call
        compute_losses(). In the QH2 architecture, the main logic lives in
        forward_backward() which handles both forward pass and loss computation.
        """
        n_global_crops = student_global["cls_after_head"].shape[0]
        n_local_crops = student_local["cls_after_head"].shape[0]
        loss_dict = {}
        loss_accumulator = 0.0

        # Loss scales like in DINOv2
        dino_global_terms = (
            n_global_crops * (n_global_crops - 1) if self.dino_global_ignore_diagonal else n_global_crops**2
        )
        dino_local_terms = n_global_crops * n_local_crops
        dino_global_scale = dino_global_terms / (dino_global_terms + dino_local_terms)
        dino_local_scale = dino_local_terms / (dino_global_terms + dino_local_terms)

        # DINO local loss
        dino_local_crops_loss = self.dino_loss(
            student_logits=student_local["cls_after_head"],
            teacher_probs=teacher_global["cls_centered"],
        )
        loss_dict["dino_local_crops_loss"] = dino_local_crops_loss

        if self.cfg.dino.reweight_dino_local_loss:
            local_weight = self.dino_local_loss_schedule[iteration]
        else:
            local_weight = 1.0

        loss_dict["dino_local_loss_weight"] = local_weight
        loss_accumulator += self.dino_loss_weight * dino_local_scale * local_weight * dino_local_crops_loss

        # DINO global loss
        dino_global_crops_loss = self.dino_loss(
            student_logits=student_global["cls_after_head"],
            teacher_probs=teacher_global["cls_centered"],
            ignore_diagonal=self.dino_global_ignore_diagonal,
        )
        loss_dict["dino_global_crops_loss"] = dino_global_crops_loss
        loss_accumulator += self.dino_loss_weight * dino_global_scale * dino_global_crops_loss

        # —— QH2 note: KoLeo / iBOT / Gram losses are disabled ——
        # Their weights default to 0.0 and are included only for
        # compatibility with upstream trainers. The QH2 pipeline uses
        # forward_backward() which adds pixel_loss and fusion_image_loss.

        return loss_accumulator, loss_dict

    @torch.no_grad()
    def gram_load_ema_teacher(self):
        if self.has_gram_teacher:
            skip_load_prefixes = ["dino_head.", "ibot_head."]
            self.gram_teacher.load_state_dict(
                {
                    k: v
                    for k, v in self.model_ema.state_dict().items()
                    if not any(k.startswith(prefix) for prefix in skip_load_prefixes)
                }
            )
            self.gram_teacher.requires_grad_(False)
            self.gram_teacher.eval()
            self.gram_teacher_initialized = True

    def train(self):
        super().train()
        self.teacher.eval()
        if self.has_gram_teacher:
            self.gram_teacher.eval()

    def forward(self, inputs):
        raise NotImplementedError

    def backprop_loss(self, loss):
        loss.backward()

    def update_ema(self, m):
        if self.ema_params_lists is None:
            student_param_list = []
            teacher_param_list = []
            for k in self.student.keys():
                for ms, mt in zip(self.student[k].parameters(), self.model_ema[k].parameters()):
                    student_param_list += [ms]
                    teacher_param_list += [mt]
            self.ema_params_lists = (student_param_list, teacher_param_list)
        else:
            student_param_list, teacher_param_list = self.ema_params_lists
        with torch.no_grad():
            torch._foreach_mul_(teacher_param_list, m)
            torch._foreach_add_(teacher_param_list, student_param_list, alpha=1 - m)

    def update_gram(self, m=0):
        if not self.has_gram_teacher:
            return
        logger.info("Updating gram teacher with teacher weights.")
        if self.gram_params_lists is None:
            teacher_param_list = []
            gramteacher_param_list = []
            for k in self.gram_teacher.keys():
                for mgt, mt in zip(self.gram_teacher[k].parameters(), self.teacher[k].parameters()):
                    gramteacher_param_list += [mgt]
                    teacher_param_list += [mt]
            self.gram_params_lists = (gramteacher_param_list, teacher_param_list)
        else:
            gramteacher_param_list, teacher_param_list = self.gram_params_lists

        with torch.no_grad():
            torch._foreach_mul_(gramteacher_param_list, m)
            torch._foreach_add_(gramteacher_param_list, teacher_param_list, alpha=1 - m)

    def build_data_augmentation_dino(self, cfg):
        return DataAugmentationDINO(
            cfg.crops.global_crops_scale,
            cfg.crops.local_crops_scale,
            cfg.crops.local_crops_number,
            global_crops_size=cfg.crops.global_crops_size,
            local_crops_size=cfg.crops.local_crops_size,
            gram_teacher_crops_size=cfg.crops.gram_teacher_crops_size,
            gram_teacher_no_distortions=cfg.crops.gram_teacher_no_distortions,
            local_crops_subset_of_global_crops=cfg.crops.localcrops_subset_of_globalcrops,
            share_color_jitter=cfg.crops.share_color_jitter,
            horizontal_flips=cfg.crops.horizontal_flips,
            mean=cfg.crops.rgb_mean,
            std=cfg.crops.rgb_std,
        )

    def get_maybe_fused_params_for_submodel(self, m: nn.Module):
        params_groups = get_params_groups_with_decay_fsdp(
            model=m,
            lr_decay_rate=self.cfg.optim.layerwise_decay,
            patch_embed_lr_mult=self.cfg.optim.patch_embed_lr_mult,
            dino_head_wd_multiplier=self.cfg.optim.dino_head_wd_multiplier,
        )
        if self.cfg.optim.multi_tensor_optim:
            fused_params_groups = fuse_params_groups(params_groups)
            logger.info("fusing param groups")

            for g in fused_params_groups:
                g["foreach"] = True
                g["fused"] = True
            return fused_params_groups
        else:
            return params_groups

    def get_params_groups(self):
        all_params_groups = []
        for name, m in self.student.items():
            logger.info(f"Getting paramer groups for {name}")
            all_params_groups += self.get_maybe_fused_params_for_submodel(m)
        return all_params_groups

    def prepare_for_distributed_training(self) -> None:
        process_subgroup = distributed.get_process_subgroup()
        default_process_group = distributed.get_default_process_group()
        inference_only_models = [self.model_ema]
        inference_only_models_process_groups = [process_subgroup]
        if self.has_gram_teacher:
            inference_only_models.append(self.gram_teacher)
            inference_only_models_process_groups.append(default_process_group)
        if self.cfg.distillation.enabled:
            inference_only_models.append(self.teacher)
            inference_only_models_process_groups.append(default_process_group)
        ac_compile_parallelize(
            trained_model=self.student,
            inference_only_models=inference_only_models,
            cfg=self.cfg,
            trained_model_process_group=process_subgroup,
            inference_only_models_process_groups=inference_only_models_process_groups,
        )

    def broadcast_to_subgroups(self, tensor, over_dim, global_batch_size=None):
        """
        This is an operation that takes a tensor from the default process group, gathers it, stacks it, then scatters it within a smaller process subgroup
        """
        world_size = distributed.get_world_size()
        subgroup_size = distributed.get_subgroup_size()
        gathered = [torch.zeros_like(tensor) for _ in range(world_size)]

        torch.distributed.all_gather(gathered, tensor)
        catted = torch.cat(gathered, dim=over_dim)
        if global_batch_size is not None:
            catted = catted.narrow(dim=over_dim, start=0, length=global_batch_size)

        return catted.chunk(subgroup_size, dim=over_dim)[distributed.get_subgroup_rank()].clone()
