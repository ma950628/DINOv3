# DINOv3 双路 ViT 遥感预训练架构汇报文档

> **状态**: ✅ 已完成开发与测试  
> **日期**: 2026-05-09  
> **版本**: v1.0  

---

## 目录

1. [项目概述](#1-项目概述)
2. [架构设计理念](#2-架构设计理念)
3. [模型整体架构](#3-模型整体架构)
4. [核心模块详解](#4-核心模块详解)
5. [数据流与计算图](#5-数据流与计算图)
6. [损失函数设计](#6-损失函数设计)
7. [训练策略](#7-训练策略)
8. [测试验证结果](#8-测试验证结果)
9. [文件结构清单](#9-文件结构清单)
10. [待办事项与演进路线](#10-待办事项与演进路线)
11. [附录：与 SkySense++ 的区别](#11-附录与-skysense-的区别)

---

## 1. 项目概述

### 1.1 背景

本项目基于 Meta 的 **DINOv3** 自监督学习框架，构建了一个面向**多模态遥感 (Remote Sensing, RS)** 数据的预训练模型。核心目标是将**高分辨率 (HR) 光学图像**与**多源卫星时序数据 (Sentinel-2 / Sentinel-1 / Landsat)** 在统一的 ViT 框架下进行联合预训练，学习跨模态、跨分辨率的视觉表征。

### 1.2 架构特点

- **双路 ViT 结构**：一路处理高分辨率光学图像 (HR ViT)，另一路融合多模态卫星时序特征 (Fusion ViT)
- **三路卫星数据输入**：Sentinel-2 (多光谱, T1 步, C1 通道)、Sentinel-1 (SAR, T2 步, C2 通道)、Landsat (T3 步, C3 通道)
- **基于 DINOv3**：使用原生的 `DinoVisionTransformer` 作为 backbone，继承 DINOv3 的自监督学习能力和分布式训练基础设施
- **完全独立于 SkySense++**：本模型是独立设计实现，仅借鉴了 SkySense++ 的多模态融合概念，不依赖其代码

### 1.3 关键数字

| 指标 | 值 |
|------|-----|
| 模型总参数量 | **130,664,448** (~131M) |
| HR ViT 参数量 | ~21.5M (单个) |
| Fusion ViT 参数量 | ~21.5M (单个) |
| HR Image 输入尺寸 | 224 × 224 |
| 卫星数据空间尺寸 | 16 × 16 |
| HR ViT embed_dim | 384 |
| Fusion ViT embed_dim | 384 |
| HR ViT patch 数 (P) | 256 (16×16) |
| Fusion ViT 序列长度 (total) | 512 (256 HR + 256 OE) |

---

## 2. 架构设计理念

### 2.1 为什么需要双路 ViT？

遥感场景中，存在两种互补的信息源：

1. **高分辨率 (HR) 图像**：空间细节丰富（亚米级），但时序维度单一（单景）
2. **中低分辨率卫星时序**：空间粗糙（10-30米级），但时序维度丰富（多年历史数据，多波段）

传统方法将两者各自编码后简单拼接，缺少深层的跨模态交互。双路 ViT 设计让两个模态在**空间级别**进行深度融合。

### 2.2 核心设计决策

| 设计决策 | 选择 | 原因 |
|----------|------|------|
| HR backbone | DINOv3 DinoVisionTransformer | 原生 DINOv3 架构，无需额外适配 |
| 卫星数据编码器 | Olmoearth (外部预训练模型) | 冻结使用，作为迁移特征提供方 |
| 融合方式 | 空间序列拼接 + Fusion ViT (QHVisionTransformer) | 每个空间位置融合所有模态信息 |
| Student-Teacher | 对偶 EMA 架构 | 继承 DINOv3 自蒸馏范式 |
| Olmoearth 当前状态 | 占位模块 | OlmoEarth 模型尚未就绪，先用占位确保 pipeline 可运行 |

### 2.3 与 SkySense++ 的关系

> **重要说明**: 本模型完全基于 DINOv3 框架开发，与 SkySense++ 无代码依赖关系。仅在设计层面借鉴了其"HR + 多模态卫星时序联合预训练"的概念。详见[附录](#11-附录与-skysense-的区别)。

---

## 3. 模型整体架构

### 3.1 顶层结构图

```
┌─────────────────────────────────────────────────────────────────────┐
│                      SSLMetaArch_QH2                                │
│                                                                     │
│  ┌────────────────────── Student ──────────────────────────────┐    │
│  │                                                              │    │
│  │  ┌─────────────────┐   ┌──────────────────────────────────┐  │    │
│  │  │  hr_backbone    │   │         fusion_backbone          │  │    │
│  │  │  (DinoVision    │   │      (FusionViT / QH ViT)        │  │    │
│  │  │   Transformer)  │   │                                  │  │    │
│  │  │                 │   │  ┌──────────┐  ┌──────────┐     │  │    │
│  │  │  Input: HR Img  │   │  │ HR patch │  │ OE tokens│     │  │    │
│  │  │  [B,3,224,224]  │   │  │ (1 pos)  │  │(T_sum个) │     │  │    │
│  │  │                 │   │  └──────────┘  └──────────┘     │  │    │
│  │  │  Output:        │   │       │              │           │  │    │
│  │  │  - cls [B,D]    │───│───────┤    concat    │           │  │    │
│  │  │  - patch [B,P,D]│───│───────┘              │           │  │    │
│  │  └─────────────────┘   │         ┌────────────┘           │  │    │
│  │                        │         ▼                        │  │    │
│  │  ┌─────────────────┐   │  ┌──────────────────────────┐   │  │    │
│  │  │    dino_head    │   │  │  Fusion ViT Encoder      │   │  │    │
│  │  │  (DINOHead)     │   │  │  (SelfAttention × N)     │   │  │    │
│  │  │  cls→[B,K]      │   │  │  Input: [N_sp, T_o, D]   │   │  │    │
│  │  └─────────────────┘   │  │  Output: fusion CLS/Pixel │   │  │    │
│  │                        │  └──────────────────────────┘   │  │    │
│  │  ┌─────────────────┐   │                                 │  │    │
│  │  │   olmoearth     │───│────→ oe_tokens [N_sp, T_i, D]   │  │    │
│  │  │   (frozen)      │   │                                 │  │    │
│  │  └─────────────────┘   └──────────────────────────────────┘  │    │
│  └──────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  ┌────────────────────── Teacher ──────────────────────────────┐    │
│  │  (与 Student 结构相同, 无梯度, EMA 更新)                      │    │
│  └──────────────────────────────────────────────────────────────┘    │
│                                                                     │
│                      Losses:                                        │
│                  ┌─────┼─────┐                                       │
│                  ▼     ▼     ▼                                       │
│            DINO Loss  Pixel  Fusion                                 │
│            (CLS级)    Loss  Image Loss                               │
│                     (空间级) (图像级CLS)                              │
└─────────────────────────────────────────────────────────────────────┘
```

### 3.2 模块组成

| 模块名 | 类型 | 可训练 | 说明 |
|--------|------|--------|------|
| `student.hr_backbone` | DinoVisionTransformer | ✅ | HR 图像编码，输出 CLS + Patch tokens |
| `student.fusion_backbone` | FusionViT (QH ViT) | ✅ | 多模态融合编码，输出融合 CLS + Pixel |
| `student.dino_head` | DINOHead | ✅ | HR CLS → prototype 映射 |
| `student.olmoearth` | Olmoearth (占位) | ❌ (frozen) | 卫星时序特征提取 |
| `teacher.*` | 同上 | ❌ (EMA跟踪) | Teacher 分支，EMA 动量更新 |

---

## 4. 核心模块详解

### 4.1 HR Backbone — DinoVisionTransformer

**文件**: `dinov3/models/vision_transformer.py` (原生 DINOv3)  
**配置**: `vit_small`，embed_dim=384，depth=12，num_heads=6

**输入**:
- HR 图像: `[B, 3, 224, 224]`

**输出**:
```python
{
    "x_norm_clstoken":   Tensor[B, D],      # CLS token (图像级特征)
    "x_storage_tokens":  Tensor[B, R, D],   # 存储 tokens (R=0 时不使用)
    "x_norm_patchtokens": Tensor[B, P, D],  # Patch tokens (P=256)
}
```

**在模型中的作用**:
- 提取 HR 图像的视觉表征
- CLS token 用于 DINO loss（图像级对比）
- Patch tokens 用于与卫星数据进行空间级融合

### 4.2 Olmoearth — 卫星时序编码器（占位版本）

**文件**: `dinov3/train/olmoearth_placeholder.py`  
**状态**: 🔴 **占位模块**，待替换为真实 OlmoEarth 预训练推理

**输入** (H5 数据字典):
```python
h5_data = {
    "s2": Tensor[B, H, W, T1, C1],  # Sentinel-2 多光谱
    "s1": Tensor[B, H, W, T2, C2],  # Sentinel-1 SAR
    "ls": Tensor[B, H, W, T3, C3],  # Landsat
}
```

**输出**:
```python
{
    "s2": {"features": Tensor[B, H_out, W_out, T1, D], "cls_token": Tensor[B, T1, D]},
    "s1": {"features": Tensor[B, H_out, W_out, T2, D], "cls_token": Tensor[B, T2, D]},
    "ls": {"features": Tensor[B, H_out, W_out, T3, D], "cls_token": Tensor[B, T3, D]},
}
```

**占位实现逻辑**:
- 对每个时间步独立做 Conv2d patch 投影（动态适配通道数）
- 输出 H_out = H / patch_size, W_out = W / patch_size
- CLS token 用零向量占位

**为什么冻结 (requires_grad=False)**:
- OlmoEarth 是独立的预训练遥感基础模型，在本 pipeline 中作为特征提供方
- 冻结避免对 OlmoEarth 参数的梯度计算，节省显存和计算
- Student 和 Teacher 共享同一个 Olmoearth 实例

### 4.3 空间序列融合

这是本架构最核心的创新部分。传统方法通常将多模态特征全局池化后拼接，但本设计在**每个空间位置**上进行融合。

**融合流程**:

```
Step 1: Olmoearth 编码
  h5_data ──→ Olmoearth ──→ {s2: [B,H,W,T1,D], s1: [B,H,W,T2,D], ls: [B,H,W,T3,D]}

Step 2: 时序展平
  将各源的 [B,H,W,T_i,D] 展平为 [B*H*W, T_i, D]
  拼接: oe_seq = cat([s2_tokens, s1_tokens, ls_tokens], dim=1)
  oe_seq: [N_spatial, T_sum, D]  (T_sum = T1 + T2 + T3)

Step 3: HR Patch 空间对齐
  HR patch [B, P, D] → reshape → [B, D, H_hr, W_hr]
  若 HR patch 分辨率 ≠ Olmoearth 分辨率, 则 interpolate 到 (H_oe, W_oe)
  → [B, D, H_oe, W_oe] → [N_spatial, 1, D]

Step 4: CLS 广播
  HR CLS [B, D] → 广播到每个空间位置 → [N_spatial, 1, D]

Step 5: 空间序列拼接
  fusion_seq = cat([oe_seq, hr_token, cls_token], dim=1)
  fusion_seq: [N_spatial, T_sum + 2, D]

Step 6: Fusion ViT 编码
  fusion_seq ──→ FusionViT (SelfAttention blocks) ──→ {
      fusion_cls:  [N_spatial, D_fusion],    # 每个空间位置的融合CLS
      fusion_patch: [N_spatial, T_sum+2, D_fusion]  # 每个空间位置的融合patch
  }

Step 7: 图像级聚合
  fusion_cls [N_spatial, D] → reshape → [B, H_oe, W_oe, D] → AvgPool → [B, D]
```

**设计优势**:
- 每个空间位置独立融合，保留了**空间局部性**
- 序列长度 = T_sum + 2，与 ViT 的 self-attention 机制天然兼容
- HR token 和 CLS token 作为"锚点"参与每个位置的注意力计算

### 4.4 Fusion ViT — QHVisionTransformer (QH ViT)

**文件**: `dinov3/models/RS_vision_transformer.py`  
**类名**: `FusionViT`

**继承**: `DinoVisionTransformer` (原生 DINOv3)

**关键参数**:
| 参数 | 默认值 | 说明 |
|------|--------|------|
| embed_dim | 384 | 与 HR ViT 对齐 |
| depth | 12 | 与 HR ViT 对齐 |
| num_heads | 6 | Multi-head attention 头数 |
| hr_seq_len | 256 | HR 模态占 1 个 token / 空间位置 |
| oe_seq_len | 256 | OE 模态占 T_sum 个 token / 空间位置 |
| total_seq_len | 512 | hr + oe |

**forward_features 三种输入路径**:
1. **3D Tensor `[N, S, D]`**: 预序列化的 token，直接进入 Transformer blocks（当前使用）
2. **List of 2 Tensors**: `[hr_tokens, oe_tokens]`，内部拼接后进入 blocks
3. **4D Tensor `[B, C, H, W]`**: 标准 ViT 图像路径，兼容原始 DINOv3 接口

**当前使用路径**: 路径 1 (3D tensor)，因为输入已经是拼接好的空间序列

### 4.5 DINO Head

**类型**: `DINOHead` (原生 DINOv3)  
**参数**: in_dim=384, out_dim=65536 (prototypes), hidden_dim=2048, bottleneck_dim=256

**作用**: 将 HR ViT 的 CLS token 映射到 prototype 空间，用于 DINO loss 的自蒸馏对比学习。

---

## 5. 数据流与计算图

### 5.1 完整前向传播 (forward_backward)

```
forward_backward(data, teacher_temp, iteration)
│
├── 输入数据
│   ├── hr_image_student: [B, 3, 224, 224]
│   ├── hr_image_teacher: [B, 3, 224, 224]
│   └── h5_data: {"s2": [B,16,16,T1,C1], "s1": [B,16,16,T2,C2], "ls": [B,16,16,T3,C3]}
│
├── Teacher 前向 (no_grad)
│   ├── HR ViT → cls, patch tokens
│   ├── DINO head → cls_after_head → sinkhorn_knopp → cls_centered
│   ├── Olmoearth(frozen) → {s2, s1, ls} features
│   ├── 空间序列拼接 → fusion_seq
│   ├── Fusion ViT → fusion_cls [B,D], fusion_pixel [B,D,H,W]
│   └── 返回 {hr_output, fusion_pixel, fusion_cls}
│
├── Student 前向 (with grad)
│   ├── HR ViT → cls, patch tokens
│   ├── DINO head → cls_after_head
│   ├── Olmoearth(frozen) → {s2, s1, ls} features
│   ├── 空间序列拼接 → fusion_seq
│   ├── Fusion ViT → fusion_cls [B,D], fusion_pixel [B,D,H,W]
│   └── 返回 {hr_output, fusion_pixel, fusion_cls}
│
├── 损失计算
│   ├── image_loss = DINO_Loss(student.cls_after_head, teacher.cls_centered)
│   │                 (HR CLS 级别的对比学习)
│   ├── pixel_loss = CE(student.fusion_pixel, teacher.fusion_pixel, temp=τ_p)
│   │                 (空间位置级的融合特征对齐, Cross-Entropy)
│   ├── fusion_image_loss = CE(student.fusion_cls, teacher.fusion_cls, temp=τ_f)
│   │                 (图像级融合 CLS 对齐, Cross-Entropy)
│   └── total_loss = dino_loss_weight * image_loss
│                   + pixel_loss_weight * pixel_loss
│                   + fusion_image_loss_weight * fusion_image_loss
│
└── 反向传播 → optimizer.step()
```

### 5.2 Teacher EMA 更新

```python
def update_ema(self, m):
    # teacher = m * teacher + (1-m) * student
    torch._foreach_mul_(teacher_params, m)
    torch._foreach_add_(teacher_params, student_params, alpha=1 - m)
```

### 5.3 辅助方法

| 方法 | 作用 |
|------|------|
| `_encode_satellite_timeseries()` | 统一调用 Olmoearth，处理 H5 → 展平序列 |
| `get_teacher_output()` | Teacher 完整前向推理 (no_grad) |
| `get_student_output()` | Student 完整前向推理 (with grad) |
| `init_weights()` | 权重初始化 (student → EMA teacher) |

---

## 6. 损失函数设计

### 6.1 总损失

```python
total_loss = α * L_image + β * L_pixel + γ * L_fusion
```

其中默认权重: α=1.0, β=0.1, γ=0.1

### 6.2 Image Loss (DINO Loss)

**类型**: `DINOLoss` (原生 DINOv3)  
**形式**: Student CLS 与 Teacher CLS 在 prototype 空间的交叉熵对比

```python
L_image = CrossEntropy(student.cls_after_head, teacher.cls_centered)
```

- Teacher CLS 经过 Sinkhorn-Knopp 中心化处理
- 训练图像级 (CLS) 的语义表征
- 权重: `cfg.dino.loss_weight` (默认 1.0)

### 6.3 Pixel Loss (空间级融合损失)

**形式**: Student 与 Teacher 的融合像素特征之间的 CE (Cross-Entropy / KL-divergence)

```python
L_pixel = CE(student.fusion_pixel, teacher.fusion_pixel, temperature=τ_p)
```

- `fusion_pixel`: 每个空间位置的融合 CLS 特征，形状 `[B, D_fusion, H_oe, W_oe]`
- Teacher 特征经温度 τ 缩放后取 softmax 作为目标分布，与 Student 的 log-softmax 做交叉熵
- 促使 Student 学习保持空间一致性
- 权重: `self.pixel_loss_weight` (默认 0.1)
- 温度: `pixel_loss_temp` (默认 0.1)

### 6.4 Fusion Image Loss (融合图像损失)

**形式**: Student 与 Teacher 的融合图像级 CLS 之间的 CE (Cross-Entropy / KL-divergence)

```python
L_fusion = CE(student.fusion_cls, teacher.fusion_cls, temperature=τ_f)
```

- `fusion_cls`: 通过空间平均池化将 `[B, H_oe, W_oe, D]` 聚合为 `[B, D]`
- Teacher 特征经温度 τ 缩放后取 softmax 作为目标分布，与 Student 的 log-softmax 做交叉熵
- 训练融合 ViT 的图像级表征
- 权重: `self.fusion_image_loss_weight` (默认 0.1)
- 温度: `fusion_loss_temp` (默认 0.1)

### 6.5 已禁用/注释的损失

| 损失 | 状态 | 说明 |
|------|------|------|
| iBOT Loss | ❌ 注释掉 | 原始 DINOv3 的 patch 级 MIM 损失 |
| KoLeo Loss | ❌ 注释掉 | CLS 分布正则化损失 |
| Gram Loss | ❌ 注释掉 | patch 特征 Gram 矩阵正则化 |
| Local Crop Loss | ❌ 注释掉 | 仅使用 global crops |

---

## 7. 训练策略

### 7.1 当前配置 (测试阶段)

| 参数 | 值 |
|------|-----|
| 批次大小 (B) | 2 (测试用) |
| HR 图像尺寸 | 224 × 224 |
| 卫星数据尺寸 | 16 × 16 (空间), 可变时间步 |
| Olmoearth 状态 | 冻结 (frozen) |
| FP16/AMP | 未启用 |
| FSDP/DDP | 未启用 (单卡测试) |
| 优化器 | 待配置 (模型已构建) |

### 7.2 训练阶段划分

```
Phase 1: 基础验证 ✅ 已完成
  └── 模型构建 + 前向/反向传播 + Teacher 输出验证

Phase 2: 真实数据集成 (待进行)
  ├── 替换 Olmoearth 占位模块为真实 OlmoEarth 推理
  ├── 连接真实 H5 数据加载
  └── 确认多模态数据流完整性

Phase 3: 分布式训练 (待进行)
  ├── FSDP 包装 (SHARD_GRAD_OP)
  ├── 准备分布式数据加载器
  └── 多卡训练验证

Phase 4: 规模化预训练 (待进行)
  ├── 大规模遥感数据集
  └── 超参数调优
```

### 7.3 分布式训练注意事项

模型中的 `prepare_for_distributed_training()` 方法已预留分布式训练接口：

```python
def prepare_for_distributed_training(self):
    # inference_only_models: teacher, gram_teacher (不参与梯度计算)
    # trained_model: student (参与梯度计算和 FSDP 分片)
    ac_compile_parallelize(
        trained_model=self.student,
        inference_only_models=[self.model_ema, ...],
        cfg=self.cfg,
        trained_model_process_group=process_subgroup,
        inference_only_models_process_groups=[...],
    )
```

---

## 8. 测试验证结果

### 8.1 测试环境

| 项目 | 值 |
|------|-----|
| PyTorch | 2.12.0.dev20260408+cu128 |
| Python | 3.14.4 |
| CUDA | 12.8 (开发版) |

### 8.2 测试用例 (test_model_build_forward.py)

#### 测试 1: Olmoearth 占位模块独立运行

- **目的**: 验证占位模块的 I/O 正确性
- **输入**: S2 [2,16,16,3,4], S1 [2,16,16,2,2], LS [2,16,16,1,6]
- **结果**: ✅ 通过
  - S2: features=[2,4,4,3,384], cls_token=[2,3,384]
  - S1: features=[2,4,4,2,384], cls_token=[2,2,384]
  - LS: features=[2,4,4,1,384], cls_token=[2,1,384]

#### 测试 2: SSLMetaArch_QH2 模型构建

- **目的**: 验证完整模型构建 (meta device)
- **结果**: ✅ 通过
  - HR ViT 参数: 21,521,280
  - Fusion ViT 参数: 21,521,280
  - 模型总参数: **130,664,448**
  - Student 和 Teacher 均使用 vit_small 架构

#### 测试 3: forward_backward 前向传播

- **目的**: 验证端到端训练循环
- **输入**: HR [2,3,224,224], H5 完整数据
- **结果**: ✅ 通过
  - Loss: **11.075994**
  - image_loss: 11.0270 (主导)
  - pixel_loss: 0.3992
  - fusion_image_loss: 0.0905
  - `.cuda()` 调用已 patch 为 no-op

#### 测试 4: Teacher / Student 输出验证

- **目的**: 验证 get_teacher_output / get_student_output
- **结果**: ✅ 通过
  - Teacher HR cls_centered: [1, 65536] (prototype 空间)
  - Teacher fusion_cls: [1, 384] (图像级融合特征)
  - Teacher fusion_pixel: True (非空)
  - Student 对应输出均正确

### 8.3 验证结论

> **所有 4 项测试全部通过 ✅✅✅✅**  
> 双路 ViT 架构可以正确构建、前向传播和反向传播。Olmoearth 占位模块与 Fusion ViT 的集成工作正常。

---

## 9. 文件结构清单

### 9.1 本模型核心文件 (DINOv3 项目内)

```
dinov3-main/dinov3-main/dinov3-main/dinov3/
├── models/
│   ├── vision_transformer.py          # 原生 DINOv3 ViT (HR backbone)
│   └── RS_vision_transformer.py       # ★ FusionViT + UPHead + build_model_from_cfg_QH
├── train/
│   ├── model.py                       # ★ SSLMetaArch_QH2 (主模型)
│   ├── olmoearth_placeholder.py       # ★ Olmoearth 占位模块
│   └── train.py                       # 训练入口 (复用 DINOv3)
├── layers/
│   ├── dino_head.py                   # DINOHead (原生)
│   ├── block.py                       # SelfAttentionBlock (原生)
│   ├── mlp.py                         # Mlp / SwiGLUFFN (原生)
│   └── ...
└── loss.py                            # DINOLoss (原生)
```

### 9.2 测试文件

```
skysense++/tests/
└── test_model_build_forward.py        # ★ 模型构建与前向传播测试
```

### 9.3 参考文件 (skysense++ 项目)

```
skysense++/
├── lib/models/segmentors/skysense_pp_pipeline.py  # 原始 SkySense++ 参考
├── lib/models/heads/up_head.py                    # UPHead 原始实现
├── configs/pretrain_skysensepp.yml                # SkySense++ 配置参考
└── docs/
    ├── skysense_pp_pipeline_analysis.md            # SkySense++ 分析
    ├── architecture_migration_guide.md             # 迁移指南
    ├── pipeline_module_specification_template.md   # 模块规格模板
    └── olmoearth_dinov3_pipeline_design.md         # 早期设计文档
```

---

## 10. 待办事项与演进路线

### 10.1 高优先级

| 序号 | 任务 | 说明 |
|------|------|------|
| 1 | 🔴 **替换 Olmoearth 占位模块** | 接入真实 OlmoEarth 预训练推理 |
| 2 | 🔴 **H5 数据加载器** | 实现适配 DINOv3 DataLoader 的 H5 数据流水线 |
| 3 | 🟡 **分布式训练验证** | FSDP 包装、多卡训练、梯度检查 |
| 4 | 🟡 **超参数调优** | loss_weights、学习率、batch size 等 |

### 10.2 中优先级

| 序号 | 任务 | 说明 |
|------|------|------|
| 5 | 🟢 **Fusion ViT 深度优化** | 探索不同 depth/head 配置对融合质量的影响 |
| 6 | 🟢 **增加 iBOT Loss** | 恢复 patch 级 MIM 损失，增强局部表征学习 |
| 7 | 🟢 **多尺度融合** | 支持多个空间分辨率的融合（而非仅 H_oe×W_oe） |
| 8 | 🟢 **位置编码优化** | 为空间序列设计专用位置编码（如 2D sinusoidal） |

### 10.3 低优先级

| 序号 | 任务 | 说明 |
|------|------|------|
| 9 | 🔵 **多 GPU FSDP 调优** | 通信优化、显存优化 |
| 10 | 🔵 **蒸馏支持** | 教师模型蒸馏（cfg.distillation.enabled） |
| 11 | 🔵 **Gram Loss 恢复** | patch 特征正则化（可选） |
| 12 | 🔵 **模型压缩** | 量化、剪枝、知识蒸馏 |

---

## 11. 附录：与 SkySense++ 的区别

| 维度 | SkySense++ (原始) | DINOv3 双路 ViT (本模型) |
|------|-------------------|--------------------------|
| **基础框架** | MMSegmentation | DINOv3 (PyTorch 原生) |
| **HR Backbone** | SwinTransformer V2 (MSL) | DinoVisionTransformer (ViT) |
| **卫星 Backbone** | VisionTransformerMSL (per-source) | Olmoearth (统一预训练模型) |
| **融合方式** | TransformerEncoder Neck (序列级) | FusionViT (空间级, 每位置独立) |
| **预训练范式** | MIM (Masked Image Modeling) + VAE | DINO (自蒸馏) + Fusion MSE |
| **损失函数** | RecLoss + ModalityVAELoss | DINO Loss + Pixel CE + Fusion CE |
| **Distributed** | MMSegmentation 内置 | DINOv3 FSDP + AC Compile |
| **代码依赖** | ⚠️ 与 skysense++ 强耦合 | ✅ 完全独立，不依赖 skysense++ |
| **可扩展性** | 受限于 MMSeg 框架 | 完全基于 DINOv3，可复用社区生态 |
| **数据集** | 13 个多模态遥感数据集 | 待适配（架构通用） |
| **参数量** | ~3B (预训练) | ~131M (当前 vit_small 配置) |

---

## 文档变更记录

| 日期 | 版本 | 变更内容 |
|------|------|----------|
| 2026-05-09 | v1.0 | 初始版本，覆盖架构设计、模块详解、测试结果 |

---

*本文档由 Cline (AI 软件工程师) 基于 DINOv3 双路 ViT 遥感预训练模型的代码审查和测试结果自动生成。*
