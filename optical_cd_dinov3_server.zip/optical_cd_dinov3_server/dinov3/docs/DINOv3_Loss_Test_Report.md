# DINOv3 损失函数测试详细报告

## 目录

1. [概述](#1-概述)
2. [DINOv3 损失函数体系](#2-dinov3-损失函数体系)
3. [损失函数的内部机制详解](#3-损失函数的内部机制详解)
4. [测试设计与架构](#4-测试设计与架构)
5. [测试结果详析](#5-测试结果详析)
6. [关键发现与隐患分析](#6-关键发现与隐患分析)
7. [上游 Bug 修复记录](#7-上游-bug-修复记录)

---

## 1. 概述

本报告记录了针对 **DINOv3 自监督预训练框架**中损失函数的**端到端梯度验证测试**。测试的目标是：

- 验证 `DINOLoss`、`iBOTPatchLoss` 和 `ObjectLoss` 三种核心损失函数的数学正确性
- 确认 768 维（直接交叉熵）和 65536 维（原型投影）两种模式均可正常工作
- 验证完整的梯度流：从总损失经过**六个损失分支**反向传播到所有可训练参数
- 检测数值稳定性问题（NaN、Inf、梯度消失/爆炸）

测试脚本位于 `dinov3/tests/test_loss_functions.py`，共 **42 个测试用例**，覆盖 **6 大类别**。

---

## 2. DINOv3 损失函数体系

DINOv3 在单次前向传播中同时计算 **六个损失项**，组成总损失：

```
总损失 = w₁·HR_DINO + w₂·HR_iBOT + w₃·Fusion_DINO + w₄·Fusion_iBOT + w₅·HR_Object + w₆·Fusion_Object
```

其中：

| 损失项 | 损失函数类 | 作用域 | 教师数据来源 |
|--------|-----------|--------|------------|
| HR DINO | `DINOLoss` | 高分辨率图像级 (CLS token) | HR backbone 教师 |
| HR iBOT | `iBOTPatchLoss` | 高分辨率 patch 级 | HR backbone 教师 |
| Fusion DINO | `DINOLoss` | 融合视图图像级 | HR backbone 教师（池化） |
| Fusion iBOT | `iBOTPatchLoss` | 融合视图 patch 级 | HR backbone 教师（映射后） |
| HR Object | `ObjectLoss` | 高分辨率 object 级 | HR backbone 教师 |
| Fusion Object | `ObjectLoss` | 融合视图 object 级 | HR backbone 教师 |

### 2.1 损失函数模块清单

```
dinov3/loss/
├── __init__.py              → 导出 DINOLoss, iBOTPatchLoss, ObjectLoss, GramLoss, KoLeoLoss
├── dino_clstoken_loss.py    → DINOLoss: 图像级 CLS token 交叉熵 + Sinkhorn-Knopp 教师
├── ibot_patch_loss.py       → iBOTPatchLoss: patch 级掩码交叉熵 + Sinkhorn-Knopp 教师
├── object_loss.py           → ObjectLoss: object 级离散瓶颈蒸馏 + Sinkhorn-Knopp 教师
├── gram_loss.py             → GramLoss: Gram 矩阵匹配损失（可选辅助正则化）
└── koleo_loss.py            → KoLeoLoss: KoLeo 正则化损失（可选辅助正则化）
```

本测试聚焦于**三个核心损失函数**：`DINOLoss`、`iBOTPatchLoss` 和 `ObjectLoss`。`GramLoss` 和 `KoLeoLoss` 为可选辅助正则化项。

---

## 3. 损失函数的内部机制详解

### 3.1 DINO 损失（DINOLoss）

**文件**: `dinov3/loss/dino_clstoken_loss.py`

#### 3.1.1 核心公式

DINO 损失计算**图像级表示**的交叉熵，其中教师概率由 Sinkhorn-Knopp 算法生成。

**学生输出**（可训练，接收梯度）：

$$p_s = \text{softmax}(s / \tau_s)$$

其中 $s$ 是学生网络的 logits，$\tau_s = 0.1$ 是学生温度参数。

**教师输出**（stop-grad，不接收梯度）：

$$p_t = \text{SinkhornKnopp}(\text{L2Norm}(t) / \tau_t)$$

其中 $t$ 是教师网络输出（经 L2 归一化），$\tau_t = 0.04$ 是教师温度。

**前向传播**（`DINOLoss.forward`）：

```python
def forward(self, student_output, teacher_output):
    # student_output: (C, B, D) — C 个裁剪，B 个样本，D 维特征
    # teacher_output: (C, B, D) — C 个裁剪（通常 1 个全局裁剪）
    
    # 计算学生 log-softmax
    student_log_probs = F.log_softmax(student_output / self.student_temp, dim=-1)
    
    # 交叉熵: -sum(teacher * log(student))
    loss = -torch.sum(teacher_output * student_log_probs, dim=-1)
    
    # 对所有裁剪求和
    return loss.sum() / (C * B)
```

#### 3.1.2 Sinkhorn-Knopp 归一化

Sinkhorn-Knopp 算法将教师输出的 softmax 概率矩阵迭代归一化，使**每行之和为 1**（每个样本对应一个概率分布），同时满足**每列的边际约束**（每个原型的期望分配次数为 $B/K$）。

算法流程（默认 3 次迭代）：

```
输入: teacher_output (B, K)       # B 个样本，K 维（768 或 65536）
温度: τ = 0.04

Q_ij = exp(teacher_output_ij / τ)  # 元素级指数

# 初始归一化
Q = Q / sum(Q)                      # 总和归一化

for _ in range(3):
    # 行归一化: 每个原型的权重之和为 1/K
    Q = Q / sum(Q, dim=1)           # 按行归一化
    Q = Q / K                        # 缩放

    # 列归一化: 每个样本的概率之和为 1/B
    Q = Q / sum(Q, dim=0)           # 按列归一化
    Q = Q / B                        # 缩放

Q = Q * B                            # 恢复列和为 1
输出: Q.T (K, B) — 每个样本的概率分布
```

**关键性质**：输出矩阵的**每一列（对应一个样本）求和为 1**，即每个样本对应一个有效的概率分布。这是交叉熵损失函数正确计算的必要条件。

#### 3.1.3 中心向量与动量更新

为避免模型坍塌（所有样本坍缩到同一表示），DINO 维护一个**中心向量** $c \in \mathbb{R}^K$，对学生输出的 log-softmax 进行修正：

$$p_s = \text{softmax}((s - c) / \tau_s)$$

中心向量通过**指数移动平均（EMA）**更新：

$$c \leftarrow m \cdot c + (1 - m) \cdot \bar{t}$$

其中 $m = 0.9$ 是动量系数，$\bar{t}$ 是当前批次教师输出的均值。

### 3.2 iBOT Patch 损失（iBOTPatchLoss）

**文件**: `dinov3/loss/ibot_patch_loss.py`

#### 3.2.1 核心公式

iBOT 损失计算**patch 级表示**的交叉熵，仅对被掩码的 patch 计算。

**前向传播**（`iBOTPatchLoss.forward`）：

```python
def forward(self, student_patch_tokens, teacher_patch_tokens, student_masks_flat):
    # 对每个被掩码的 patch 计算交叉熵
    loss = -sum(teacher_patch * log_softmax(student_patch / τ), dim=-1)
    
    # 按掩码加权求和
    loss = sum(loss * mask, dim=-1) / sum(mask, dim=-1).clamp(min=1.0)
    
    return -loss.mean()
```

### 3.3 Object 损失（ObjectLoss）

**文件**: `dinov3/loss/object_loss.py`

#### 3.3.1 核心思想

Object Loss 通过**可学习的 Object Queries** 对 patch tokens 进行**软分组（soft grouping）**，在 object 粒度上进行知识蒸馏。它遵循与 DINO/iBOT 相同的交叉熵 + Sinkhorn-Knopp 教师范式，是 v7 新增的核心损失组件。

#### 3.3.2 核心公式

**第一步：计算分配矩阵（compute_assignment）**

```python
def compute_assignment(self, patch_tokens, object_queries):
    # patch_tokens: (B, P, D) — B 个样本，P 个 patch，D 维特征
    # object_queries: (N, D) — N 个可学习的 object query
    
    # 归一化内积作为 soft assignment logits
    patch_normed = F.normalize(patch_tokens, dim=-1)
    queries_normed = F.normalize(object_queries, dim=-1)
    
    # logits shape: (B, N, P) — 每个 patch 对每个 object 的分配分数
    logits = torch.einsum('bpd,nd->bnp', patch_normed, queries_normed)
    return logits / τ_student  # 学生温度参数
```

**第二步：教师 Sinkhorn-Knopp 中心化**

教师端分配矩阵经过 Sinkhorn-Knopp 归一化产生软标签：

```python
teacher_logits = compute_assignment(teacher_patch, object_queries)  # (B, N, P)
teacher_probs = sinkhorn_knopp(teacher_logits, teacher_temp=0.04)   # 行/列归一化
```

**第三步：交叉熵损失**

```python
student_log_probs = F.log_softmax(student_logits, dim=1)  # 沿 object 维度
loss = -sum(teacher_probs * student_log_probs, dim=1)      # 交叉熵
loss = loss.mean()
```

**中心向量**：形状为 `(1, N, 1)`，通过 EMA（momentum=0.9）更新，用于修正学生 logits。

### 3.4 768 维直接 CE vs 65536 原型投影

DINOv3 支持两种维度的交叉熵计算，通过 `use_direct_ce_loss` 配置项切换：

| 模式 | 维度 | 投影方式 | 配置 |
|------|------|---------|------|
| **直接 CE** | 768 | backbone 输出直接作为 logits | `use_direct_ce_loss=True` |
| **原型投影** | 65536 | 经 `DINOHead`/`iBOTHead` 投影到 65536 维原型空间 | `use_direct_ce_loss=False` |

两种模式在 `model.py` 的 `compute_losses` 方法中统一处理。ObjectLoss 始终在 object embedding 空间计算，不使用原型投影。

---

## 4. 测试设计与架构

### 4.1 测试环境

| 项目 | 值 |
|------|-----|
| Python | 3.14.4 |
| PyTorch | 与 Python 3.14 兼容版本 |
| 测试框架 | pytest |
| 运行方式 | 单机单卡（非分布式） |
| 运行命令 | `python -m dinov3.tests.test_loss_functions -v` |

### 4.2 测试分类

测试脚本 `test_loss_functions.py` 包含 **6 个测试类**，共 **42 个测试用例**：

```
测试类                         测试数    覆盖内容
─────────────────────────────────────────────────
TestDINOLoss基础功能            8        构造/前向/SK 概率/EMA (×2维度)
TestiBOTPatchLoss基础功能       8        构造/前向/SK 概率/EMA (×2维度)
TestObjectLoss基础功能          12       构造/分配/前向/梯度/SK/EMA (×2 object数)
Test维度选择                    5        两种维度的梯度有效性验证
Test端到端梯度流                3        六种损失的完整梯度流
Test报告一致性                  3        与官方报告的交叉验证
Test边界情况                    3        大批量/收敛/空掩码
```

### 4.3 辅助函数设计

测试前精心设计了三个关键辅助函数，确保测试输入与真实训练分布一致：

```python
# 1. 投影层构建（模拟 DINOHead）
def _构建投影层(输入维度, 输出维度):
    proj = nn.Linear(输入维度, 输出维度)
    nn.init.trunc_normal_(proj.weight, std=0.02)
    nn.init.zeros_(proj.bias)
    return proj

# 2. 学生投影层（可训练，期望获得梯度）
def _构建学生投影层(输入维度, 输出维度):
    proj = nn.Linear(输入维度, 输出维度)
    nn.init.trunc_normal_(proj.weight, std=0.02)
    nn.init.zeros_(proj.bias)
    return proj

# 3. L2 归一化随机张量（模拟 backbone 输出）
def _随机L2归一化张量(维度元组):
    return F.normalize(torch.randn(维度元组), dim=-1)
```

**为什么必须用 L2 归一化张量？**

`DINOHead` 对 backbone 输出做 L2 归一化后再送入 Sinkhorn-Knopp。如果用原始 `randn`，数值范围过大，$\exp(x/0.04)$ 会产生 Inf 溢出，导致 SK 输出 NaN。L2 归一化将向量约束到单位球面，确保数值稳定。

### 4.4 torch.compile 禁用说明

iBOT 的 `SinkhornKnoppTeacher` 在初始化时调用 `self.sinkhorn_knopp_teacher.compile()`。在没有 C++ 编译器（如 MSVC `cl.exe`）的 Windows 环境中，`torch.compile` 会因缺少 C++ 编译器而失败。

在测试脚本中通过以下方式禁用：

```python
import torch._dynamo
torch._dynamo.config.disable = True
```

这不影响功能的正确性验证——Sinkhorn-Knopp 算法本身不需要编译即可运行。

---

## 5. 测试结果详析

### 5.1 TestDINOLoss基础功能（8 个测试，全部通过 ✅）

#### test_构造[768] / test_构造[65536]

**测试内容**: 验证 `DINOLoss(patch_out_dim)` 正确构造。

**验证点**:
- `center` 缓冲区形状为 `(1, patch_out_dim)`
- `student_temp = 0.1`（默认学生温度）
- `center_momentum = 0.9`（默认中心动量）

**结果解读**: 两种维度下构造均正确，说明 `DINOLoss` 类与维度参数解耦，可灵活适配不同输出空间。

---

#### test_前向传播_无梯度教师[768/65536]

**测试内容**: 使用 softmax 模拟 SK 教师概率，验证 forward 输出标量损失值。

**验证点**:
- 输出是 0 维张量（标量）
- 损失值 > 0（交叉熵理论下界为 0，但从未达到）

**结果解读**: 前向传播计算逻辑正确，使用随机教师概率仍能得到正损失值（因为学生 logits 尚未与教师对齐）。

---

#### test_SinkhornKnopp概率和为1[768] / [65536]

**测试内容**: 验证 SK 输出的每一行概率之和为 1。

**验证点**:
- 无 NaN 值
- 每行概率之和与 1.0 的偏差在容差范围内
  - 768 维：容差 `1e-5`
  - 65536 维：容差 `1e-3`（放宽，因为 B << K 时 SK 收敛稍弱）

**结果解读**: 
- **768 维**: SK 收敛精确，概率和为 1 的误差 < 1e-5 ✅
- **65536 维**: B=128 远小于 K=65536，SK 收敛稍弱但仍可接受（误差 < 1e-3）。**实际训练中** B 通常是全局批量（如 1024×16 GPU），SK 精度会显著提高 ✅

---

#### test_中心向量更新_降低损失[768/65536]

**测试内容**: EMA 中心向量更新后，损失值应在稳定数据上趋于平稳（不发散）。

**验证点**:
- 5 轮更新后损失值均为有限值
- 中心向量 non-zero（说明 EMA 生效）

**结果解读**: 中心向量动量更新机制运行正常，有助于防止模型坍塌 ✅

---

### 5.2 TestiBOTPatchLoss基础功能（8 个测试，全部通过 ✅）

#### test_构造[768/65536]

**验证点**: `center` 形状为 `(1, 1, patch_out_dim)`（多一个维度用于 patch 广播）。

**结果解读**: iBOT 的 center 比 DINO 多一个维度，这与 patch 级特征 (B, P, D) 的形状广播需求一致 ✅

---

#### test_前向传播_全部patch[768/65536]

**测试内容**: 对所有 patch 使用全为 True 的掩码，计算损失。

**关键**: 教师输入必须是 **softmax 概率**（使用 L2 归一化后的特征计算），不能是原始特征或 L2 特征。

**结果解读**: 教师概率正确传递时，损失计算正常。如果误用原始特征作为教师，损失值会异常（过大或 NaN）。✅

---

#### test_SinkhornKnopp概率和为1[768/65536]

**测试内容**: iBOT 的 SinkhornKnoppTeacher 输出概率归一化。

**特别注意**: 此测试涉及**已修复的上游 bug**——原先 `dist.all_reduce(B)` 缺少 `dist.is_initialized()` 守卫。修复后单机可正常调用。

**验证点**:
- 无 NaN 输出
- 每行概率和接近 1.0

**结果解读**: 修复后的代码在单机环境下 SK 工作正常 ✅

---

#### test_中心向量更新[768/65536]

**验证点**: `init_weights()` 将 center 归零 → `update_center() + apply_center_update()` 后 center 非零。

**结果解读**: 异步中心更新机制（`reduce_handle` + `async_op`）在单机环境下退化为同步行为，更新正确 ✅

---

### 5.3 TestObjectLoss基础功能（12 个测试，全部通过 ✅）

Object Loss 是 v7 新增的核心损失组件，通过可学习的 Object Queries 对 patch tokens 进行软分组，在 object 粒度上执行知识蒸馏。

#### test_构造[16] / test_构造[64]

**测试内容**: 验证 `ObjectLoss(embed_dim=768, num_objects=N)` 正确构造。

**验证点**:
- `object_queries` 形状为 `(num_objects, 768)`
- `center` 形状为 `(1, num_objects, 1)`
- `student_temp = 0.1`，`center_momentum = 0.9`

**结果解读**: 构造正确，object_queries 和 center 维度均与 num_objects 减耦合 ✅

---

#### test_计算分配矩阵[16/64]

**测试内容**: `compute_assignment` 输出形状应为 `[B, num_objects, P]`。

**验证点**: 归一化内积计算正确，输出张量维度是 `(B, N, P)`，其中 N 是 object 数量。

**结果解读**: Soft grouping 分配矩阵计算无误，每个 patch 对每个 object 的亲和度 logits 正确产生 ✅

---

#### test_前向传播_输出标量损失[16/64]

**测试内容**: forward 方法应输出大于 0 的标量损失值。

**验证点**:
- 输出是标量（0 维张量）
- 损失值 > 0
- 损失值为有限值（非 NaN/Inf）

**结果解读**: Object Loss 的交叉熵计算与 DINO/iBOT 遵循同一范式，数学上一致 ✅

---

#### test_反向传播_梯度有效[16/64]

**测试内容**: ObjectLoss 反向传播应产生有效的非 NaN 梯度。

**验证点**:
- `student_patch.grad` 非空且不含 NaN
- `object_queries.grad` 非空且不含 NaN

**结果解读**: 梯度成功回传到学生 patch 特征和可学习的 object_queries 参数 ✅

---

#### test_SinkhornKnopp概率性质[16/64]

**测试内容**: Sinkhorn-Knopp 输出每一列（沿 object 维度的分配概率）应近似求和为 1。

**验证点**:
- 输出不含 NaN
- 输出值均 ≥ 0
- 每个 patch 对 object queries 的分配概率之和约为 1

**结果解读**: SK 在 Object Loss 空间中同样产生有效的概率分布 ✅

---

#### test_中心向量更新[16/64]

**测试内容**: 中心向量 update + apply 后应变为非零。

**验证点**: `init_weights()` 后 center ≈ 0，更新后 center 非零。

**结果解读**: Object Loss 的 EMA 中心向量更新与 DINO/iBOT 一致，工作正常 ✅

---

### 5.4 Test维度选择（5 个测试，全部通过 ✅）

#### test_DINO维度支持[768/65536]

**验证点**:
- 损失值 > 0
- `学生logits.grad` 非空（说明梯度成功回传）
- 梯度不含 NaN

**结果解读**: `DINOLoss` 在 768 维和 65536 维下均正常生成有效梯度 ✅

#### test_iBOT维度支持[768/65536]

**验证点**: 同上，验证 iBOT 的梯度有效性。

**结果解读**: `iBOTPatchLoss` 在两种维度下梯度均有效 ✅

#### test_两种维度损失值在合理范围

**测试内容**: 768 维和 65536 维的损失比值应在 [0.1, 10] 范围内。

**验证点**: 两种维度的损失值数量级一致（不应出现一个正常、另一个指数级爆炸/消失）。

**结果解读**: 比值在合理范围，说明理论计算逻辑一致——65536 维下 log_softmax 的分母更大，学生概率更分散，损失值可能稍高，但差别在可控范围内 ✅

---

### 5.5 Test端到端梯度流（3 个测试，全部通过 ✅）

#### test_六种损失端到端梯度[True] / [False]

**测试内容**: 构建与 `model.py` 中 `compute_losses` 等价的完整损失计算图：

```
HR DINO + HR iBOT + Fusion DINO + Fusion iBOT + HR Object + Fusion Object → 总损失 → backward
```

**模拟架构**:

| 模式 | 维度 | 学生分支 | 教师分支 |
|------|------|---------|---------|
| True（直接 CE） | 768 | `Linear(768, 768)` 投影 | backbone 输出 + SK（无投影头） |
| False（原型） | 65536 | `Linear(768, 65536)` 投影 | `Linear(768, 65536)` 投影 + SK |

Object Loss 始终在 768 维 embedding 空间计算，使用可学习的 object_queries（64 个 object）。

**验证点**:
1. 所有学生侧参数 **必须获得梯度**（通过 `p.grad is not None`）— 包括 4 个学生投影头 + 2 个 object_queries
2. 梯度不含 NaN
3. 如果参数非零，梯度不能为零（梯度消失检测）
4. 教师侧参数 **必须没有梯度**（stop-grad 预期）

**结果解读**:
- **True 模式（768 维）**: 4 个学生投影头 + 2 个 object_queries 参数全部获得有效梯度 ✅
- **False 模式（65536 维）**: 同上 ✅
- **教师参数无梯度**: 确认 `.detach()` / `@torch.no_grad()` / SK 中的 stop-grad 逻辑正确 ✅
- **六种损失组合无梯度冲突**：DINO、iBOT、Object Loss 三个不同粒度的损失可以同时反向传播 ✅

---

#### test_两种模式均无NaN梯度

**验证点**: 反向传播后梯度不含 NaN，损失值为有限值。

**结果解读**: 768 维和 65536 维反向传播均数值稳定 ✅

---

### 5.6 Test报告一致性（3 个测试，全部通过 ✅）

#### test_use_direct_ce_loss开关

**测试内容**: 验证 `use_direct_ce_loss` 的两种配置（True → 768, False → 65536）都能正常计算损失。

**结果解读**: 与官方报告的配置切换逻辑一致 ✅

#### test_总损失公式

**测试内容**: 验证加权求和公式可行（六分量相加得到标量）：

```
总损失 = 1.0*dino + 0.1*ibot + 0.1*fusion_dino + 0.1*fusion_ibot + 0.05*hr_object + 0.05*fusion_object
```

**结果解读**: 总损失为有限值，六分量加权求和无问题 ✅

#### test_教师使用SinkhornKnopp

**验证点**:
- SK 输出每行之和为 1
- 输出值 >= 0（概率有效性）
- 无 NaN

**结果解读**: 教师概率由 SK 生成完毕后方可进入交叉熵 ✅

---

### 5.7 Test边界情况（3 个测试，全部通过 ✅）

#### test_大批量无NaN

**测试内容**: 65536 维下 B=128 批量计算 SK 和损失，不应产生 NaN。

**说明**: B << K (128 << 65536) 是极端情况——Sinkhorn-Knopp 在 B 很小而 K 极大时，行归一化可能导致数值不精确，但不应产生 NaN。

**结果解读**: 通过 ✅，说明 SK 实现具有良好的数值稳定性。

#### test_中心向量收敛

**测试内容**: 20 轮 update_center + apply_center_update，中心向量不应发散。

**验证点**: 20 轮后中心向量绝对值的最大值 < 100。

**结果解读**: EMA 机制提供良好的稳定性，即使输入是随机 L2 归一化张量，中心向量也不会爆炸 ✅

#### test_空patch掩码_正确处理

**测试内容**: 所有 patch 掩码为 False（无有效 patch），不应崩溃。

**说明**: `clamp(min=1.0)` 保护分母不为零。如果无此保护，除以零会导致 inf/NaN。

**结果解读**: 保护机制生效，空掩码返回有限损失值 ✅

---

## 6. 关键发现与隐患分析

### 6.1 ✅ 已确认正确项

| 项目 | 验证方法 | 结论 |
|------|---------|------|
| DINO 768 维直接 CE | 前向 + 反向梯度检查 | ✅ 正常 |
| DINO 65536 维原型投影 | 前向 + 反向梯度检查 | ✅ 正常 |
| iBOT 768 维直接 CE | 前向 + 反向梯度检查 | ✅ 正常 |
| iBOT 65536 维原型投影 | 前向 + 反向梯度检查 | ✅ 正常 |
| Object Loss (N=16/64) | 前向 + 反向梯度检查 | ✅ 正常 |
| 六种损失端到端梯度流 | 完整损失图 + backward | ✅ 正常 |
| SK 输出概率和为 1 | 行求和检查 | ✅ 通过 |
| EMA 中心向量更新 | 5-20 轮收敛检查 | ✅ 稳定 |
| 空掩码保护 | 零掩码边界测试 | ✅ 保护生效 |
| 教师 stop-grad | 教师参数无梯度检查 | ✅ 正确 |

### 6.2 ⚠️ 潜在隐患

#### 隐患 1: 65536 维 SK 在极小批量下的精度衰减

**现象**: B=128, K=65536 时 SK 概率之和与 1 的偏差最大约 `1e-3`。

**影响**:
- 实际训练中 B 是全局批量（如每 GPU 64 × 16 GPU = 1024），B 更大时 SK 精度会显著提高
- 偏差在 `1e-3` 水平对梯度方向影响有限，Sinkhorn-Knopp 本身就是近似算法
- **极端情况**：如果未来使用非常小的 micro-batch（如 B=4），偏差可能增大到影响收敛

**建议**: 在配置中保证单 GPU 批量 ≥ 32，或监控 SK 概率和的偏差。

---

#### 隐患 2: 教师 softmax 输入误用风险

**现象**: `iBOTPatchLoss.forward()` 期望的教师输入是 **softmax 概率**（值在 [0,1] 之间，行求和为 1），而 `DINOLoss.forward()` 也期望概率（由 SK 生成）。

**风险**: 如果误将 L2 归一化特征（而非 softmax 概率）传递给 forward，损失的梯度方向会是错误的——模型会优化到不同的方向。

**当前保护**: 无运行时检查。代码依赖调用方（`model.py`）的正确实现。

**建议**: 考虑在 `forward` 中添加开箱断言（仅在 debug 模式），检查教师输入是否为有效概率分布：
```python
assert (teacher_output >= 0).all(), "教师输出必须是非负概率"
assert (teacher_output.sum(dim=-1) - 1.0).abs().max() < 1e-3, "教师行之和必须为1"
```

---

#### 隐患 3: Sinkhorn-Knopp 迭代次数固定为 3

**现象**: `SinkhornKnoppTeacher` 硬编码 `n_iterations=3`。

**影响**:
- 对于 768 维，3 次迭代通常足够
- 对于 65536 维且 B << K 时，3 次迭代可能不足以完全收敛

**建议**: 考虑将迭代次数作为超参数暴露，或在 65536 模式下自动增加迭代次数。

---

#### 隐患 4: 分布式环境下的 SK 行为

**现象**: `SinkhornKnoppTeacher` 中包含 `dist.all_reduce()` 调用。已修复的 bug 暴露了一个关键问题：**SK 在单机和分布式下的行为不同**（分布式下对 sum_Q 和 sum_of_rows 做全局归约）。

**风险**: 在分布式训练中，SK 的行和列归一化涉及跨 GPU 通信。如果 `all_reduce` 和本地计算之间存在竞态条件或异步问题，可能导致不同 GPU 上的 SK 结果不一致。

**当前保护**: 所有 `dist.all_reduce` 都是同步的（非 async）。但 `reduce_center_update` 中的 `dist.all_reduce` 是异步的（`async_op=True`），通过 `reduce_handle.wait()` 在 `apply_center_update` 中同步。

**建议**: 在分布式训练中监控中心向量的跨 GPU 一致性。

---

#### 隐患 5: torch.compile 与 Python 版本兼容性

**现象**: `SinkhornKnoppTeacher` 使用 `module.compile()`，在特定环境下可能失败（如无 C++ 编译器、Python 3.14）。

**影响**: 非关键——compile 仅用于加速，不改变数学结果。

**建议**: 添加 try-except 包装：
```python
try:
    self.sinkhorn_knopp_teacher.compile()
except Exception as e:
    logger.warning(f"SinkhornKnopp compile failed: {e}. Running without compile.")
```

---

## 7. 上游 Bug 修复记录

### Bug: `ibot_patch_loss.py` 缺少 `dist.is_initialized()` 守卫

**位置**: `dinov3/loss/ibot_patch_loss.py` 第 35 行

**原始代码**:
```python
B = n_masked_patches_tensor
dist.all_reduce(B, group=get_process_subgroup())  # ← 单机崩溃
K = Q.shape[0]
```

**问题**: 在单机非分布式环境下，`dist.all_reduce()` 在进程组未初始化时引发异常。

**修复后代码**:
```python
B = n_masked_patches_tensor
if dist.is_initialized():
    dist.all_reduce(B, group=get_process_subgroup())
K = Q.shape[0]
```

**影响范围**: 仅影响单机测试/调试场景。分布式训练中 `dist` 已初始化，原代码可正常运行但不符合防御性编程最佳实践。

**测试验证**: 修复后 `TestiBOTPatchLoss基础功能::test_SinkhornKnopp概率和为1` 的两种维度测试均通过。

---

## 附录 A: 测试运行命令

```bash
# 从项目根目录运行
cd e:\dinov3-main\dinov3-main
python -m dinov3.tests.test_loss_functions -v
```

## 附录 B: 测试结果快速参考

```
TestDINOLoss基础功能::test_构造[768]                       ✅
TestDINOLoss基础功能::test_构造[65536]                     ✅
TestDINOLoss基础功能::test_前向传播_无梯度教师[768]        ✅
TestDINOLoss基础功能::test_前向传播_无梯度教师[65536]      ✅
TestDINOLoss基础功能::test_SinkhornKnopp概率和为1[768]     ✅
TestDINOLoss基础功能::test_SinkhornKnopp概率和为1[65536]   ✅
TestDINOLoss基础功能::test_中心向量更新_降低损失[768]      ✅
TestDINOLoss基础功能::test_中心向量更新_降低损失[65536]    ✅
TestiBOTPatchLoss基础功能::test_构造[768]                  ✅
TestiBOTPatchLoss基础功能::test_构造[65536]                ✅
TestiBOTPatchLoss基础功能::test_前向传播_全部patch[768]    ✅
TestiBOTPatchLoss基础功能::test_前向传播_全部patch[65536]  ✅
TestiBOTPatchLoss基础功能::test_SinkhornKnopp概率和为1[768]   ✅
TestiBOTPatchLoss基础功能::test_SinkhornKnopp概率和为1[65536] ✅
TestiBOTPatchLoss基础功能::test_中心向量更新[768]          ✅
TestiBOTPatchLoss基础功能::test_中心向量更新[65536]        ✅
TestObjectLoss基础功能::test_构造[16]                      ✅
TestObjectLoss基础功能::test_构造[64]                      ✅
TestObjectLoss基础功能::test_计算分配矩阵[16]              ✅
TestObjectLoss基础功能::test_计算分配矩阵[64]              ✅
TestObjectLoss基础功能::test_前向传播_输出标量损失[16]     ✅
TestObjectLoss基础功能::test_前向传播_输出标量损失[64]     ✅
TestObjectLoss基础功能::test_反向传播_梯度有效[16]         ✅
TestObjectLoss基础功能::test_反向传播_梯度有效[64]         ✅
TestObjectLoss基础功能::test_SinkhornKnopp概率性质[16]     ✅
TestObjectLoss基础功能::test_SinkhornKnopp概率性质[64]     ✅
TestObjectLoss基础功能::test_中心向量更新[16]              ✅
TestObjectLoss基础功能::test_中心向量更新[64]              ✅
Test维度选择::test_DINO维度支持[768]                       ✅
Test维度选择::test_DINO维度支持[65536]                     ✅
Test维度选择::test_iBOT维度支持[768]                       ✅
Test维度选择::test_iBOT维度支持[65536]                     ✅
Test维度选择::test_两种维度损失值在合理范围                ✅
Test端到端梯度流::test_六种损失端到端梯度[True]            ✅
Test端到端梯度流::test_六种损失端到端梯度[False]           ✅
Test端到端梯度流::test_两种模式均无NaN梯度                 ✅
Test报告一致性::test_use_direct_ce_loss开关                ✅
Test报告一致性::test_总损失公式                            ✅
Test报告一致性::test_教师使用SinkhornKnopp                 ✅
Test边界情况::test_大批量无NaN                             ✅
Test边界情况::test_中心向量收敛                            ✅
Test边界情况::test_空patch掩码_正确处理                    ✅

总计: 42 passed, 0 failed
