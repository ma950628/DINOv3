# Olmoearth + DINOv3 多源遥感预训练 Pipeline 设计

> **状态**: v6 (教师/学生分支增强分离 + Mask 取消) | **日期**: 2026-05-14 | **关联文件**: `model.py`, `RS_vision_transformer.py`, `olmoearth_placeholder.py`, `augmentations.py`, `collate.py`

---

## 1. 数据增强：教师/学生分支分离 (v6 新增)

### 1.1 设计原则

| 分支 | 增强策略 | 特性 |
|------|----------|------|
| **教师** (`global_crops_teacher`) | **无增强**：仅 Resize → CenterCrop → Normalize | 确定性、可复现，目标一致稳定 |
| **学生** (`global_crops`) | **全部强增强**：RandomResizedCrop + ColorJitter + GaussianBlur + Solarize + RandomHorizontalFlip + RandomGrayscale | 强随机性，迫使学生学习不变性特征 |

### 1.2 增强流水线

```
输入图像 [H, W, 3]
    │
    ├──► 学生分支 (随机强增强)
    │    ├─ RandomResizedCrop(scale=[0.4,1.0])
    │    ├─ RandomHorizontalFlip(p=0.5)
    │    ├─ ColorJitter(brightness=0.4, contrast=0.4, saturation=0.2, hue=0.1, p=0.8)
    │    ├─ RandomGrayscale(p=0.2)
    │    ├─ GaussianBlur(p=1.0 view1 / p=0.1 view2)
    │    ├─ RandomSolarize(threshold=128, p=0.2, view2 only)
    │    └─ Normalize(mean, std)
    │    └──► global_crops: [2, 3, 224, 224]  (学生 2 views)
    │         local_crops: [N_local, 3, 96, 96]  (学生 N_local views)
    │
    └──► 教师分支 (确定性，无增强)
         ├─ Resize(global_crops_size)
         ├─ CenterCrop(global_crops_size)
         └─ Normalize(mean, std)
         └──► global_crops_teacher: [2, 3, 224, 224]  (教师 2 views，内容相同)
```

> **详见**: `teacher_student_augmentation_mask_report.md`

---

## 2. Mask 取消 (v6 新增)

**所有 mask 相关操作已全部取消**。`collate_data_and_cast()` 和 `get_batch_subset()` 返回的 mask 字段均为空/零值：

| 字段 | 值 |
|------|-----|
| `collated_masks` | `torch.zeros(B, N, dtype=torch.bool)` |
| `mask_indices_list` | `torch.tensor([], dtype=torch.int64)` |
| `masks_weight` | `torch.tensor([], dtype=torch.float32)` |
| `upperbound` | `0` |
| `n_masked_patches` | `torch.full((1,), fill_value=0)` |

**影响**：移除了原 DINOv3 中的 iBOT patch-level mask loss，仅保留 DINO image-level loss + pixel loss + fusion loss。

---

## 3. 数据流总览

```
                         +---------------- 输入 --------------------+
                         |                                          |
                HR Image (原始)                   H5 Data Dict
            [B, 3, H, W]                     {s2, s1, ls} 三源时序
                         |                                          |
                         v                                          |
            +-- 数据增强 (augmentations.py) --+                       |
            |                                |                       |
            v                                v                       |
    +-------+--------+           +-----------+----------+            |
    | 教师分支        |           | 学生分支             |            |
    | 无增强          |           | 全部强增强           |            |
    | Resize +        |           | RandCrop + ColorJit  |            |
    | CenterCrop +    |           | + Blur + Solarize    |            |
    | Normalize       |           | + Flip + Normalize   |            |
    +-------+--------+           +-----------+----------+            |
            |                                |                       |
     teacher_crops                  student_crops                   |
     [2B, 3, 224, 224]              [2B, 3, 224, 224]              |
            |                              + [N*B, 3, 96, 96]       |
            v                                v                       v
    +---------------+              +----------------+    +---------------------+
    |   ViT-1       |              |   ViT-1        |    |   Olmoearth          |
    | (Teacher)     |              | (Student)      |    |   (Frozen)           |
    | DinoVision    |              | DinoVision     |    | 一次调用处理三源       |
    | Transformer   |              | Transformer    |    +----------+----------+
    +-------+-------+              +-------+-------+               |
            |                                |                       |
     CLS [B,D]                    CLS [B,D]  | Patch [B,P,D]        | {s2,s1,ls}.features
            |                                |                       | [B, H_oe, W_oe, T_i, D]
         (teacher)                  (student)|                       v
            v                                |       +-------------------------------+
     Sinkhorn-Knopp                  DINO Head      |  将各源 OE 特征上采样           |
     中心化 -> teacher_cls_centered     |            |  到 HR patch 分辨率             |
            |                         |            |  [B, H_hr_patch, H_hr_patch,    |
            |                         |            |   T_i, D]                      |
            |                         +------------+---------------+---------------+
            |                                      |                            |
            |                      空间展平 + 时序拼接:
            |                      [B*P, T_sum, D]    (T_sum=T1+T2+T3)
            |                                      |
            |              +-----------------------+
            |              |
            v              v
    +--------------------------+
    |  HR Patch 直接作为         |
    |  空间 token 序列           |
    |  [B, P, D]                |
    |  -> [N_spatial, 1, D]      |  N_spatial = B * P
    +------------+-------------+
                 |
    +------------v-------------+
    |  拼接融合序列 (外部)       |
    |  [N_spatial, 1+T_sum, D]  |
    +------------+-------------+
                 |
    +------------v-------------+
    |   ViT-2 (Fusion)          |
    |  QHVisionTransformer      |
    |                           |
    |  ViT-2 内部自动 prepend    |
    |  CLS token ->             |
    |  [N_spatial, T_sum+2, D]  |  = B*(img_size/patch_size)^2 x (T1+T2+T3+1(HR)+1(CLS)) x D
    |                           |
    |  * 逐时间自注意力 *         |  <-- 对每个空间位置独立
    |    沿 seq=T_sum+2         |      沿时间维度做 self-attn
    |    维度做 self-attn        |
    +------------+-------------+
                 |
      取 CLS -> [N_spatial, D_fusion]
      mean over P -> [B, D_fusion]
                 |
                 v
        +------------------------------+
        |   Total Loss (3 losses)       |
        |   1) DINO Loss                |  <-- student_cls_after_head vs teacher_cls_centered
        |   2) Pixel Loss (CE)          |  <-- ViT-1 HR patch tokens CE 对齐 (学生 vs 教师)
        |   3) Fusion Loss (CE)         |  <-- ViT-2 CLS CE 对齐 (学生 vs 教师)
        |   ~~ Mask Loss 已移除 ~~       |
        +------------------------------+
```

**最终 Fusion ViT 输入/输出维度**:
- **ViT-2 外部拼接输入**: `[B*P, 1+T_sum, D]` = `[N_spatial, 1+T1+T2+T3, D]`
- **ViT-2 内部 (加 CLS 后)**: `[B*P, T1+T2+T3+1(HR)+1(CLS), D]` = `[B*P, T_sum+2, D]`
  = `[B × (img_size/patch_size)^2, T1+T2+T3+2, D(embed_dim)]`

**关键设计**:
- **OE 上采样到 HR patch 分辨率**: 将 OE 各源特征通过 interpolate 上采样到 HR patch 网格 (e.g. 16×16=256)
- **N_spatial = B × P** (P = patch 数, 如 256)，而非 B × H_oe × W_oe (如 16)
- **hr_patch_spatial**: 保留原生 HR 分辨率 `[B, D, H_hr_patch, H_hr_patch]` 用于 pixel loss
- **教师/学生分支分离 (v6)**: 教师无增强 → 目标稳定；学生全增强 → 不变性学习
- **Mask 取消 (v6)**: 移除 iBOT patch-level mask loss

---

## 4. 逐时间自注意力 (Per-Time-Step Self-Attention)

这是 Fusion ViT 最核心的设计：

| 特性 | 说明 |
|------|------|
| **ViT-2 外部拼接输入** | `[B*P, 1+T_sum, D]` — batch 维 = 空间位置数(=B×P)，seq 维 = HR(1) + OE(T_sum) |
| **ViT-2 内部序列** | `[B*P, T_sum+2, D]` — ViT-2 自动 prepend CLS token → seq = CLS(1) + HR(1) + OE(T_sum) |
| **注意力域** | 沿 seq 维度（时间方向），**非**空间方向 |
| **位置编码** | ViT-2 内部为正序列每个 token 添加位置编码 (CLS_pos=0, HR_pos=1, OE_t1=2, ..., OE_tN=T_sum+1) |
| **含义** | 对每个空间像素，HR 的 patch 特征与 OE 的多时相特征在**时间轴上交互**，让模型学习如何用多时相遥感信息增强高分辨率特征 |

```
示意图 — 一个空间位置的序列 (ViT-2 内部视角):

  CLS     HR_patch      OE_t1       OE_t2      ...    OE_tN     <-- ViT-2 内部加 CLS
   |         |            |           |                  |
   +---------+------------+-----------+------------------+
                    Self-Attention (时间方向)
   +------------------------------------------------------------+
   |  CLS  <--attends-->  HR  <--attends-->  OE_t1  <--attends--> ... |
   |  每个 token 可以看到序列中所有其他 token                        |
   +------------------------------------------------------------+
                            |
                    输出 CLS token -> 融合了 HR + 多时相 OE 的全局表示
```

**与常见空间的 ViT 的区别**: 常见的 ViT 在 patch tokens 空间做 attention（`[B, P, D]`），这里 ViT-2 在时间维度做 attention 而空间维度被展平到 batch 维中。

---

## 5. 维度流转

```
HR Image:              [B, 3, H_hr, W_hr]
H5 Data:               {"s2": [B,H_oe,W_oe,T1,C1], "s1": [B,H_oe,W_oe,T2,C2], "ls": [B,H_oe,W_oe,T3,C3]}

ViT-1 -> CLS:           [B, D]
ViT-1 -> Patch:         [B, P, D]                     (P = (H_hr/patch_size)^2)

Olmoearth(h5_data) ->   s2.features: [B, H_oe, W_oe, T1, D]
                        s1.features: [B, H_oe, W_oe, T2, D]
                        ls.features: [B, H_oe, W_oe, T3, D]

OE 上采样到 HR 分辨率:  s2_up: [B, H_hr_patch, H_hr_patch, T1, D]
                        s1_up: [B, H_hr_patch, H_hr_patch, T2, D]
                        ls_up: [B, H_hr_patch, H_hr_patch, T3, D]

空间展平 -> 时序拼接:    oe_seq: [B*P, T_sum, D]       (T_sum = T1+T2+T3)
+ HR spatial:          hr_tok: [B*P, 1, D]

Fusion Input (外部拼接):  [B*P, 1+T_sum, D]            = [N_spatial, 1+T1+T2+T3, D]
Fusion ViT 内部 +CLS:     [B*P, T_sum+2, D]            = [N_spatial, T1+T2+T3+2, D]

ViT-2 -> Fusion CLS:    [B*P, D_fusion]
       -> mean over P:  [B, D_fusion]

输出字典:
  "hr":                {"cls_pre_head": [B,D], "cls_after_head": [B,K], "cls_centered": [B,K], ...}
  "hr_patch_spatial":  [B, D, H_hr_patch, H_hr_patch]  <-- 用于 Pixel Loss (原生分辨率)
  "fusion_cls":        [B, D_fusion]                    <-- 用于 Fusion Image Loss
```

---

## 6. 子模块

| 模块 | 类 | 所属 | 用途 | 训练? |
|------|-----|------|------|-------|
| `hr_backbone` | `DinoVisionTransformer` | ViT-1 | HR RGB 编码 | Yes |
| `dino_head` | `DINOHead` | ViT-1 | CLS -> prototype 映射 | Yes |
| `olmoearth` | `Olmoearth` | -- | H5 字典 -> 三源多时相特征 | No Frozen |
| `fusion_backbone` | `QHVisionTransformer` | ViT-2 | 逐时间自注意力融合 | Yes |

---

## 7. 损失函数

| 序号 | 名称 | 来源 | 公式 | 权重 |
|------|------|------|------|------|
| 1 | Image Loss | ViT-1 CLS | `DINOLoss(student_cls_after_head, teacher_cls_centered)` | `cfg.dino.loss_weight` |
| 2 | Pixel Loss | ViT-1 Patch | `CE(student_hr_patch_spatial, teacher_hr_patch_spatial, temp=τ_p)` | `pixel_loss_weight` (0.1) |
| 3 | Fusion Image Loss | ViT-2 CLS | `CE(student_fusion_cls, teacher_fusion_cls, temp=τ_f)` | `fusion_image_loss_weight` (0.1) |

**Pixel Loss 和 Fusion Image Loss 均使用 CE (Cross-Entropy / KL-divergence)**：
- Teacher 特征经温度 τ 缩放后取 softmax 作为目标分布：`P_T = softmax(T / τ)`
- Student 特征经温度 τ 缩放后取 log-softmax：`logP_S = log_softmax(S / τ)`
- 损失：`L = -mean(sum(P_T * logP_S, dim=-1))`（沿特征维度 D 计算 KL 散度）

**温度参数**：
- `pixel_loss_temp`：Pixel Loss 的 softmax 温度，默认 0.1
- `fusion_loss_temp`：Fusion Image Loss 的 softmax 温度，默认 0.1

`Total = dino_w * ① + pixel_w * ② + fusion_w * ③`

---

## 8. get_teacher_output / get_student_output 输出

两方法对称，返回相同结构：

```python
{
    "hr": {
        "cls_pre_head":    Tensor[B, D],          # ViT-1 CLS (DINO head 前)
        "cls_after_head":  Tensor[B, K],          # DINO head 输出 (K=65536)
        "cls_centered":    Tensor[B, K],          # Sinkhorn-Knopp 中心化 (仅 teacher)
        "reg_pre_head":    Tensor[B, R, D],       # 寄存器 tokens
        "patch_pre_head":  Tensor[B, P, D],       # 原始 patch tokens
    },
    "hr_patch_spatial": Tensor[B, D, H_hr_patch, H_hr_patch],  # HR patch 原生分辨率 -> 2) Pixel Loss
    "fusion_cls":        Tensor[B, D_fusion],                   # ViT-2 CLS -> mean over P -> 3) Fusion Image Loss
}
```

**说明**:
- `hr_patch_spatial`: ViT-1 patch tokens reshape 为原始空间网格 `[B,D,H_hr_patch,H_hr_patch]`，**不经 interpolate**，用于 pixel loss
- `fusion_cls`: OE 特征**上采样到 HR patch 分辨率**后，与 HR token 拼接 -> ViT-2 逐时间自注意力 -> 取 CLS `[N_spatial,D_fusion]` -> mean over P -> `[B,D_fusion]`
- ViT-1 的 CLS token **不**传给 Fusion ViT

---

## 9. Olmoearth 占位类

```python
class Olmoearth(nn.Module):
    """H5 字典输入 -> 三源特征 (占位)"""
    def forward(self, h5_data: dict) -> dict:
        return {
            "s2": {"features": [B,H_oe,W_oe,T1,D], "cls_token": [B,T1,D]},
            "s1": {"features": [B,H_oe,W_oe,T2,D], "cls_token": [B,T2,D]},
            "ls": {"features": [B,H_oe,W_oe,T3,D], "cls_token": [B,T3,D]},
        }
```

---

## 10. 数据输入格式

```python
data = {
    "hr_image_student": Tensor[B, 3, H_hr, W_hr],
    "hr_image_teacher": Tensor[B, 3, H_hr, W_hr],
    "h5_data": {
        "s2": Tensor[B, H_oe, W_oe, T1, C1],
        "s1": Tensor[B, H_oe, W_oe, T2, C2],
        "ls": Tensor[B, H_oe, W_oe, T3, C3],
    },
}
```

---

## 11. v4 -> v5 变更摘要

| 项目 | v4 (旧) | v5 (新) |
|------|---------|---------|
| 空间对齐方向 | HR 下采样到 OE 分辨率 (interpolate HR -> 4x4) | OE 上采样到 HR 分辨率 (interpolate OE 各源 -> 16x16) |
| N_spatial | B x H_oe x W_oe = Bx16 | B x P = Bx256 |
| hr_patch_spatial 形状 | `[B, D, H_oe, W_oe]` | `[B, D, H_hr_patch, H_hr_patch]` |
| OE token 构建 | 直接从 `[B,H_oe,W_oe,T_i,D]` 展平 | 先 interpolate 到 HR 网格再展平 |
| fusion_cls 空间池化 | reshape->permute->adaptive_avg_pool2d | reshape->mean(dim=1) |
| pixel loss 监督信号 | 粗粒度 4x4 特征 | 细粒度 16x16 原生 patch 特征 |

---

## 12. 待办

- [ ] 替换 `Olmoearth` 占位类为真实推理模块
- [ ] `fusion_backbone` 确认支持变长序列
- [ ] data_loader 提供 `h5_data` 字典
- [ ] `teacher_temp` 改为可配置而非硬编码 0.04
- [ ] 清理 dead code (`compute_losses`, Gram 相关)

---

## 13. 相关文件

| 文件 | 说明 |
|------|------|
| `model.py` | `SSLMetaArch_QH2` 主模型 |
| `dinov3/models/RS_vision_transformer.py` | `QHVisionTransformer`, `build_model_from_cfg_QH` |
| `models/olmoearth_placeholder.py` | Olmoearth 占位类 |
| `configs/pretrain_skysensepp.yml` | 预训练配置 |
