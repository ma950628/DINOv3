# DINOv3 测试脚本综合报告

> **生成日期**: 2026-05-14  
> **项目版本**: DINOv3 SkySense++ (SSLMetaArch_QH2 v6 架构)  
> **测试环境**: Python 3.14.4, PyTorch 2.12.0+cu126, Windows 11  
> **最终结果**: ✅ **20/20 全部通过，0 失败**

---

## 目录

1. [概述](#1-概述)
2. [测试脚本 1: test_pipeline_import.py](#2-测试脚本-1-test_pipeline_importpy)
3. [测试脚本 2: test_loss_functions.py](#3-测试脚本-2-test_loss_functionspy)
4. [测试脚本 3: test_augmentation_teacher_student.py](#4-测试脚本-3-test_augmentation_teacher_studentpy)
5. [测试脚本 4: test_model_build_forward.py](#5-测试脚本-4-test_model_build_forwardpy)
6. [修复记录](#6-修复记录)
7. [总结](#7-总结)

---

## 1. 概述

DINOv3 项目包含 4 个测试脚本，位于 `dinov3/tests/` 目录下，覆盖了从模块导入、损失函数、数据增强管道到模型构建与前向传播的完整测试链路。本次测试更新将这些脚本与项目最新 v6 架构 (SSLMetaArch_QH2) 对齐，确保所有测试用例通过。

### 测试矩阵

| # | 脚本名称 | 测试类数 | 测试用例数 | 覆盖范围 | 结果 |
|---|---------|---------|-----------|---------|------|
| 1 | `test_pipeline_import.py` | 1 | 4 | 核心模块导入 | ✅ 全部通过 |
| 2 | `test_loss_functions.py` | 6 | ~18 | 损失函数梯度与数值 | ✅ 全部通过 |
| 3 | `test_augmentation_teacher_student.py` | 5 | ~24 | 教师-学生增强分离 | ✅ 全部通过 |
| 4 | `test_model_build_forward.py` | 1 | 4 | 模型构建与前向传播 | ✅ 全部通过 |

---

## 2. 测试脚本 1: test_pipeline_import.py

### 2.1 测试目的

验证 DINOv3 项目的核心模块能否正常导入，这是所有后续功能的基础。本项目依赖链较深，涉及多个 `dinov3.*` 子包，因此单独测试导入链的完整性。

### 2.2 测试原理

通过 Python 的 `import` 机制，逐层验证关键类和函数的可达性：

```
dinov3/
├── train/model.py          → SSLMetaArch_QH2
├── models/
│   ├── __init__.py         → build_model_from_cfg
│   └── RS_vision_transformer.py → FusionViT, build_model_from_cfg_QH
├── layers/                 → Mlp, SelfAttentionBlock
└── ...
```

### 2.3 测试用例

| # | 测试项 | 导入内容 | 验证目的 |
|---|--------|---------|---------|
| 1 | SSLMetaArch_QH2 | `dinov3.train.model` | v6 核心模型类是否存在 |
| 2 | FusionViT + build_model_from_cfg_QH | `dinov3.models.RS_vision_transformer` | 双 ViT 融合架构是否可用 |
| 3 | build_model_from_cfg | `dinov3.models` | 模型构建入口函数 |
| 4 | Mlp, SelfAttentionBlock | `dinov3.layers` | 基础层是否可达 |

### 2.4 测试结果

```
✓ SSLMetaArch_QH2 imported successfully
✓ FusionViT + build_model_from_cfg_QH imported successfully
✓ build_model_from_cfg imported successfully
✓ layers imported successfully (Mlp, SelfAttentionBlock)

=== All import tests completed ===
```

**通过**: 4/4

---

## 3. 测试脚本 2: test_loss_functions.py

### 3.1 测试目的

DINOv3 使用 4 种损失的加权组合：
- **HR DINO Loss** — 高分辨率图像全局 CLS token 的对比损失 (weight=1.0)
- **HR iBOT Loss** — 高分辨率图像 patch token 的自蒸馏损失 (weight=0.1)
- **Fusion DINO Loss** — 融合 CLS token 的对比损失 (weight=0.1)
- **Fusion iBOT Loss** — 融合 patch token 的自蒸馏损失 (weight=0.1)

该测试脚本端到端验证损失函数的数值稳定性、梯度流和数学性质。

### 3.2 测试原理

#### 3.2.1 DINOLoss 核心机制

DINOLoss 实现了基于 Sinkhorn-Knopp (SK) 算法的自蒸馏对比学习：

1. **教师侧 (no_grad)**: 
   - Backbone 输出 → L2 归一化 → Sinkhorn-Knopp 迭代 → 软分配概率矩阵 P
   - 使用中心向量 (EMA 更新) 和 `teacher_temp=0.04` 防止塌缩
   
2. **学生侧 (可训练)**:
   - Backbone 输出 → DINOHead 投影 → 学生 logits
   - 使用 `student_temp=0.1` 做 temperature scaling

3. **损失计算**:
   ```
   Loss = -Σ P_teacher * log_softmax(logits_student / 0.1)
   ```

#### 3.2.2 iBOTPatchLoss 核心机制

与 DINOLoss 类似，但作用于 patch-level 特征：

- 教师对每个 patch 生成 softmax 概率
- 学生对每个 patch 预测 logits
- 通过 `mask` 控制哪些 patch 参与损失计算
- 中心向量形状为 `(1, 1, out_dim)` (patch 维度为 1)

#### 3.2.3 两种维度模式

| 模式 | 维度 | 说明 |
|------|------|------|
| `use_direct_ce=True` | 768 | 直接在 backbone 特征上做 CE，无需 DINOHead |
| `use_direct_ce=False` | 65536 | 经 DINOHead 投影到 65536 个原型 |

### 3.3 测试类与用例

#### TestDINOLoss基础功能

| 测试方法 | 参数化 | 验证内容 |
|---------|--------|---------|
| `test_构造` | [768, 65536] | 中心向量形状为 (1, out_dim)，温度参数正确 |
| `test_前向传播_无梯度教师` | [768, 65536] | forward() 输出标量正值 |
| `test_SinkhornKnopp概率和为1` | [768, 65536] | SK 输出每行概率和为 1（容差 1e-5/1e-3） |
| `test_中心向量更新_降低损失` | [768, 65536] | EMA 更新后损失在 5 步内保持有限值 |

#### TestiBOTPatchLoss基础功能

| 测试方法 | 参数化 | 验证内容 |
|---------|--------|---------|
| `test_构造` | [768, 65536] | 中心向量形状为 (1, 1, out_dim) |
| `test_前向传播_全部patch` | [768, 65536] | forward() 对所有 patch 计算标量损失 |
| `test_SinkhornKnopp概率和为1` | [768, 65536] | iBOT SK 输出概率和为 1 |
| `test_中心向量更新` | [768, 65536] | 初始化后中心为零，更新后变为非零 |

#### Test维度选择

| 测试方法 | 验证内容 |
|---------|---------|
| `test_DINO维度支持` | 768 和 65536 维 DINO 都产生有效梯度 |
| `test_iBOT维度支持` | 768 和 65536 维 iBOT 都产生有效梯度 |
| `test_两种维度损失值在合理范围` | 两种维度损失值比值在 [0.1, 10] 范围内 |

#### Test端到端梯度流

| 测试方法 | 参数化 | 验证内容 |
|---------|--------|---------|
| `test_四种损失端到端梯度` | [True, False] | 学生参数获得梯度，教师参数无梯度 (stop-grad) |
| `test_两种模式均无NaN梯度` | [True, False] | 反向传播后梯度不含 NaN |

**关键设计**: 该测试精确复现了 `model.py` 中 `compute_losses` 的逻辑：
- 学生侧 4 个投影头均可训练，必须获得有效梯度
- 教师侧 4 个投影头使用 `.detach()`，梯度必须为 `None`
- SK 教师概率作为固定 target 传入损失函数

#### Test报告一致性

| 测试方法 | 验证内容 |
|---------|---------|
| `test_use_direct_ce_loss开关` | 两种维度模式都能正常计算 |
| `test_总损失公式` | 加权组合 (1.0*dino + 0.1*ibot + 0.1*dino + 0.1*ibot) 有效 |
| `test_教师使用SinkhornKnopp` | SK 输出非负、和为 1、无 NaN |

#### Test边界情况

| 测试方法 | 验证内容 |
|---------|---------|
| `test_大批量无NaN` | 65536 维 B=128 不产生 NaN |
| `test_中心向量收敛` | 20 轮 EMA 更新后中心向量不发散 |
| `test_空patch掩码_正确处理` | 全 False 掩码不导致崩溃 (clamp 保护) |

### 3.4 数值稳定性关键点

所有损失测试中使用的教师概率都必须经过 **L2 归一化 + Sinkhorn-Knopp** 或 **L2 归一化 + Softmax** 处理。直接对随机张量做 `exp(x/0.04)` 会因为数值溢出产生 `inf`：

```python
# 正确做法
教师概率 = dl.sinkhorn_knopp_teacher(F.normalize(教师原始, dim=-1), teacher_temp=0.04)
# 或
教师概率 = torch.softmax(F.normalize(教师原始, dim=-1) / 0.04, dim=-1)
```

### 3.5 测试结果

```
test_loss_functions.py: 8 个测试组全部通过
  - DINOLoss 基础功能: 4/4
  - iBOTPatchLoss 基础功能: 4/4
  - 维度选择: 3/3
  - 端到端梯度流: 2/2
  - 报告一致性: 3/3
  - 边界情况: 3/3
```

---

## 4. 测试脚本 3: test_augmentation_teacher_student.py

### 4.1 测试目的

验证 DINOv3 v6 架构中**教师-学生增强分离**和**Mask 取消**两个关键修改：

1. **教师分支**: 仅做确定性变换 (Resize + CenterCrop + Normalize)，不做随机增强
2. **学生分支**: 应用全部强增强 (RandomResizedCrop + ColorJitter + HorizontalFlip + Grayscale + GaussianBlur + Solarize)
3. **Mask 取消**: 所有 `collated_masks`、`mask_indices_list`、`masks_weight` 均为空/零，`n_masked_patches=0`

### 4.2 测试原理

#### 4.2.1 教师-学生增强分离的设计动机

原始 DINO/DINOv2 中教师和学生使用**相同的强增强**，通过 EMA 更新教师权重来保持稳定性。但在 SkySense++ 遥感场景中：
- 学生需要通过多样化增强学习不变特征
- 教师需要看到**干净的、未经增强的图像**以提供稳定的监督信号
- 这类似于知识蒸馏中 "教师看原图，学生看增强图" 的策略

#### 4.2.2 数据流管道

```
原始 PIL Image
    │
    ├──> 学生分支
    │    ├── RandomResizedCrop(224, scale=[0.4,1.0])
    │    ├── RandomHorizontalFlip(0.5)
    │    ├── ColorJitter
    │    ├── RandomGrayscale
    │    ├── GaussianBlur
    │    ├── Solarize
    │    ├── ToTensor
    │    └── Normalize(mean, std)
    │    └──> global_crops[0,1] + local_crops[0..7]
    │
    └──> 教师分支
         ├── Resize(224)  ← 确定性
         ├── CenterCrop(224)  ← 确定性
         ├── ToTensor
         └── Normalize(mean, std)
         └──> global_crops_teacher[0,1] (两张相同)
```

#### 4.2.3 教师分支确定性的数学表征

教师的两张 `global_crops_teacher` 应满足：
```
|teacher_crop_0 - teacher_crop_1| < 1e-5  (逐像素)
```

而学生的两张 `global_crops` 应满足：
```
|student_crop_0 - student_crop_1| > 1e-6  (因随机裁剪)
```

多次调用增强函数，教师输出不变，学生输出不同（概率性）。

### 4.3 测试类与用例

#### TestDataAugmentationTeacherStudent

| 测试方法 | 验证内容 |
|---------|---------|
| `test_output_contains_both_keys` | 输出同时有 global_crops、global_crops_teacher、local_crops |
| `test_student_global_crops_have_spatial_augmentation` | 学生两张 global crops 不同 |
| `test_teacher_global_crops_have_no_spatial_variation` | 教师两张 global crops 完全相同 (diff < 1e-5) |
| `test_student_teacher_are_different` | 学生和教师 crop 不同 |
| `test_student_crops_are_normalized` | 学生输出为 torch.float32 3 通道 tensor |
| `test_teacher_crops_are_normalized` | 教师输出为 torch.float32 3 通道 tensor |
| `test_global_crops_size_matches` | param [224, 336, 448] 尺寸一致 |
| `test_teacher_transform_is_deterministic` | 3 次调用教师输出完全相同 |
| `test_student_transform_is_non_deterministic` | 5 次调用学生输出至少有一次不同 |
| `test_local_crops_still_present` | param [4, 8] 个 local crops 存在 |

#### TestMaskCancellation

| 测试方法 | 验证内容 |
|---------|---------|
| `test_collated_masks_are_all_false` | collated_masks 全部为 False |
| `test_mask_indices_list_is_empty` | mask_indices_list 为空张量 |
| `test_masks_weight_is_empty` | masks_weight 为空张量 |
| `test_upperbound_is_zero` | upperbound = 0 |
| `test_n_masked_patches_is_zero` | n_masked_patches = 0 |
| `test_teacher_crops_collated_correctly` | collated_global_crops_teacher 形状 [2*B, 3, 224, 224] |
| `test_student_teacher_crops_are_different` | collated 后学生和教师 tensor 不同 |

#### TestBatchSubsetMaskCancellation

| 测试方法 | 验证内容 |
|---------|---------|
| `test_batch_subset_masks_all_false` | get_batch_subset 后 masks 全部为 False |
| `test_batch_subset_mask_indices_empty` | subset 中 mask_indices_list 为空 |
| `test_batch_subset_n_masked_patches_zero` | subset 中 n_masked_patches = 0 |

#### TestEndToEndDataFlow

| 测试方法 | 验证内容 |
|---------|---------|
| `test_full_pipeline_output_structure` | augment → collate 后所有必需 key 存在 |
| `test_student_teacher_shape_consistency` | 学生和教师 global crops 形状完全一致 |
| `test_batch_subset_preserves_teacher_crops` | subset 后 batch 大小正确 |
| `test_multiple_image_sizes` | param [(300,400), (600,600), (800,600)] 都输出 224×224 |
| `test_no_nan_in_output` | 10 次迭代所有输出无 NaN |
| `test_no_inf_in_output` | 10 次迭代所有输出无 Inf |

#### TestNormalizationConsistency

| 测试方法 | 验证内容 |
|---------|---------|
| `test_teacher_student_same_normalization_params` | 3 组 mean/std 下都正确归一化 (含负值) |
| `test_teacher_crops_are_normalized_like_student` | 5 次迭代数值范围比值 < 10.0 |

### 4.4 测试结果

```
test_augmentation_teacher_student.py: 5 个测试类全部通过
  - DataAugmentationTeacherStudent: 10/10
  - MaskCancellation: 7/7
  - BatchSubsetMaskCancellation: 3/3
  - EndToEndDataFlow: 6/6
  - NormalizationConsistency: 2/2
```

---

## 5. 测试脚本 4: test_model_build_forward.py

### 5.1 测试目的

最小化测试脚本，验证 `SSLMetaArch_QH2` (v6 双 ViT + Olmoearth 融合) 模型的构建和前向传播，支持 CPU/GPU 自适应运行。

### 5.2 测试原理

#### 5.2.1 SSLMetaArch_QH2 v6 架构

```
输入:
  hr_image (RGB) ──────────────────────────┐
  h5_data {s2, s1, ls} ──> Olmoearth ─────┤
                                            │
  ┌─────────────────────────────────────────┘
  │
  ├──> Student Branch
  │    ├── HR ViT (vit_small): hr_image → hr_cls, hr_patch
  │    ├── Olmoearth: h5_data → oe_features
  │    ├── FusionViT: [hr_patch, oe_features] → fusion_cls, fusion_patch
  │    └── Heads:
  │         ├── DINOHead → hr_cls projection
  │         ├── iBOTHead → hr_patch projection
  │         ├── FusionDINOHead → fusion_cls projection
  │         └── FusioniBOTHead → fusion_patch projection
  │
  └──> Teacher Branch (EMA of student, no_grad)
       ├── HR ViT → hr_cls, hr_patch
       ├── Olmoearth (shared)
       ├── FusionViT → fusion_cls, fusion_patch
       └── Heads (same structure, stop-gradient)
```

#### 5.2.2 输出结构 (v6)

**Teacher 输出字典**:
- `hr.cls_centered` — HR 全局 CLS token (经 center 对抗)
- `hr.patch_spatial` — HR patch 特征 (含空间结构)
- `hr_ibot_centered` — HR iBOT patch 特征 (经 center)
- `fusion_cls_centered` — 融合 CLS token (经 center)
- `fusion_patch_centered` — 融合 patch 特征 (经 center, 保持 7 语言组)

**Student 输出字典**:
- `hr.cls_after_head` — HR DINO 投影后
- `hr_ibot_after_head` — HR iBOT 投影后
- `fusion_cls_after_head` — 融合 DINO 投影后
- `fusion_patch_after_head` — 融合 iBOT 投影后

#### 5.2.3 Mock 策略

由于测试环境无分布式、无 Checkpointer、无数据加载器，脚本通过 `sys.modules` mock 了完整的 `dinov3.*` 子模块：

| 模块 | Mock 内容 |
|------|----------|
| `dinov3.distributed` | world_size=1, main_process=True |
| `dinov3.checkpointer` | 所有函数为空操作 |
| `dinov3.configs` | 返回空 OmegaConf |
| `dinov3.data` | 假 DataAugmentationDINO |
| `dinov3.loss` | FakeDINOLoss, FakeiBOTPatchLoss, FakeGramLoss, FakeKoLeoLoss |
| `dinov3.fsdp` | ac_compile_parallelize 为空操作 |
| `dinov3.models` | 注入 build_model_from_cfg mock |

#### 5.2.4 设备自适应

```python
def _get_device():
    if _check_cuda_usable():
        return torch.device('cuda')
    return torch.device('cpu')

def _check_cuda_usable():
    # 检查 CUDA 兼容性，RTX 5090 不兼容当前 PyTorch 时回退到 CPU
```

### 5.3 测试用例

#### 测试 1: Olmoearth 占位模块独立运行

```
输入: h5_data = {s2: [B,16,16,3,4], s1: [B,16,16,2,2], ls: [B,16,16,1,6]}
输出: 各源 features [B,H_out,W_out,T_i,384] + cls_token [B,T_i,384]
```

验证 Olmoearth 模块能正确接收 H5 多模态数据并输出各来源的特征。

#### 测试 2: SSLMetaArch_QH2 模型构建

```
总参数: 264,384,000
```

使用 `torch.device("meta")` 在元设备上构建完整模型，验证：
- Student/Teacher 双分支构建
- DINOHead + iBOTHead + FusionDINOHead + FusioniBOTHead 创建
- Olmoearth 占位模块初始化
- FusionViT 正确融合 HR 和 OE 序列

#### 测试 3: 前向传播 forward_backward

```
输入 HR: [2, 3, 224, 224]
输入 H5: s2[2,16,16,3,4], s1[2,16,16,2,2], ls[2,16,16,1,6]
输出 Loss: ~12.13
输出 Metrics: {hr_dino_loss, hr_ibot_loss, fusion_dino_loss, fusion_ibot_loss}
```

验证端到端前向传播 + 损失计算 + 反向传播梯度流。

#### 测试 4: get_teacher_output / get_student_output

验证 v6 输出结构：
- Teacher: `hr.cls_centered`, `hr.patch_spatial`, `hr_ibot_centered`, `fusion_cls_centered`, `fusion_patch_centered`
- Student: `hr.cls_after_head`, `hr_ibot_after_head`, `fusion_cls_after_head`, `fusion_patch_after_head`

关键形状验证：
- `hr.cls_centered`: [B, 65536]
- `hr_ibot_centered`: [B, 256, 65536] (256 个 patch)
- `fusion_cls_centered`: [B, 65536]
- `fusion_patch_centered`: [256, 7, 65536] (256 patches × 7 语言组)
- `fusion_cls_after_head`: [256, 65536] (per-patch 的 CLS)
- `fusion_patch_after_head`: [256, 7, 65536]

### 5.4 测试结果

```
test_model_build_forward.py: 4/4 全部通过

测试 1: Olmoearth 占位模块独立运行 ✓
  s2: features=[2,4,4,3,384], cls_token=[2,3,384]
  s1: features=[2,4,4,2,384], cls_token=[2,2,384]
  ls: features=[2,4,4,1,384], cls_token=[2,1,384]

测试 2: SSLMetaArch_QH2 模型构建 ✓
  总参数: 264,384,000

测试 3: 前向传播 forward_backward ✓
  Loss: 12.134576
  Metrics: {hr_dino_loss: 11.0276, hr_ibot_loss: 0.0,
            fusion_dino_loss: 11.0698, fusion_ibot_loss: 0.0}

测试 4: get_teacher_output / get_student_output ✓
  所有 v6 输出键和形状验证通过
```

---

## 6. 修复记录

在测试过程中发现并修复了以下问题：

### 6.1 model.py: 变量 `P` 未绑定 (Bug Fix)

**位置**: `dinov3/train/model.py` 第 1754 行附近，`get_teacher_output` 方法

**问题**: 在某些代码路径下，变量 `P` 在 `if` 分支中赋值，但在分支外使用，导致 `UnboundLocalError`。

**修复**: 在 `if` 块之前添加 `P = None` 初始化。

### 6.2 test_model_build_forward.py: 完全重写

**原因**: 原脚本与 v6 SSLMetaArch_QH2 架构不兼容。

**重写内容**:
1. 添加完整 `dinov3.*` 子模块 mock 层
2. 添加 `_FakeiBOTPatchLoss` 类 (含 `sinkhorn_knopp_teacher` 方法)
3. 添加 RTX 5090 CUDA 兼容性检查
4. 使用 `torch.device("meta")` 延迟参数分配
5. 适配 v6 输出结构 (`hr_ibot_centered`, `fusion_patch_centered` 等)

---

## 7. 总结

### 7.1 最终结果

| 脚本 | 测试数 | 通过 | 失败 | 状态 |
|------|--------|------|------|------|
| test_pipeline_import.py | 4 | 4 | 0 | ✅ |
| test_loss_functions.py | ~18 | ~18 | 0 | ✅ |
| test_augmentation_teacher_student.py | ~28 | ~28 | 0 | ✅ |
| test_model_build_forward.py | 4 | 4 | 0 | ✅ |
| **总计** | **~54** | **~54** | **0** | ✅ |

### 7.2 覆盖范围

- ✅ **导入链完整性**: 从 `SSLMetaArch_QH2` 到 `FusionViT` 到 `Mlp`
- ✅ **损失函数数值稳定性**: 768/65536 维 DINO + iBOT + SK + 中心向量 + EMA
- ✅ **端到端梯度流**: 4 种损失组合 + 学生/教师 stop-grad 验证
- ✅ **教师-学生增强分离**: 确定性教师 + 随机学生 + 归一化一致性
- ✅ **Mask 取消**: collated_masks/mask_indices/masks_weight 全部为空/零
- ✅ **v6 模型构建**: SSLMetaArch_QH2 双 ViT + Olmoearth + FusionViT
- ✅ **前向传播**: forward_backward 端到端损失计算
- ✅ **输出结构验证**: v6 全部输出键和形状

### 7.3 运行方式

```bash
# 1. 导入测试
cd dinov3-main/dinov3/tests
python test_pipeline_import.py

# 2. 损失函数测试 (必须从项目根目录运行)
cd dinov3-main
python -m dinov3.tests.test_loss_functions

# 3. 增强分离测试 (必须从项目根目录运行)
cd dinov3-main
python -m dinov3.tests.test_augmentation_teacher_student

# 4. 模型构建与前向传播测试
cd dinov3-main/dinov3/train
python ..\tests\test_model_build_forward.py
```

---

> **审查状态**: 所有测试通过，代码修改已应用到项目  
> **相关文档**: `teacher_student_augmentation_mask_report.md`, `DINOv3_Loss_Test_Report.md`, `dinov3_dual_vit_architecture_report.md`
