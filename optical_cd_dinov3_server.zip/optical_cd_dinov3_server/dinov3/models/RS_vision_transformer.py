"""
RS_vision_transformer — 遥感多模态融合编码器

为 SSLMetaArch_QH2 (model.py) 提供以下组件:
  1. UPHead        — 特征上采样头 (复用自 skysense++/lib/models/heads/up_head.py)
  2. FusionViT     — 多模态特征融合 Vision Transformer (基于 DINOv3 DinoVisionTransformer)
  3. build_model_from_cfg_QH — 构建 student / teacher 融合模型

状态说明:
  - UPHead: ✅ 已实现 (PixelShuffle 上采样, 用于对齐 OlmoEarth 与 HR ViT 的特征维度)
  - FusionViT: ✅ 已实现 (标准 ViT encoder, 将来自 HR + OlmoEarth 的序列化特征进行融合)
  - build_model_from_cfg_QH: ✅ 已实现
"""

import logging
from collections import OrderedDict
from functools import partial

import torch
import torch.nn as nn

from dinov3.layers import (
    LayerScale,
    Mlp,
    PatchEmbed,
    RMSNorm,
    RopePositionEmbedding,
    SelfAttentionBlock,
    SwiGLUFFN,
)
from dinov3.utils import named_apply
from dinov3.models.vision_transformer import (
    DinoVisionTransformer,
    ffn_layer_dict,
    norm_layer_dict,
    dtype_dict,
    init_weights_vit,
    vit_small,
    vit_base,
    vit_large,
    vit_so400m,
    vit_huge2,
    vit_giant2,
    vit_7b,
)

logger = logging.getLogger("dinov3")


# ==============================================================================
# 1. UPHead — 直接从 skysense++ 复用
# ==============================================================================

class UPHead(nn.Module):
    """
    特征上采样头，使用 PixelShuffle 实现无插值伪影的上采样。

    原始位置: skysense++/lib/models/heads/up_head.py

    IOD 接口:
      I: Tensor [B, in_dim, H, W]
      O: Tensor [B, out_dim, H * up_scale, W * up_scale]
      D: 无占位行为 — 该模块已完整实现

    用途: 将 OlmoEarth 输出的特征 (embed_dim=768) 上采样到 HR ViT 的 embed_dim，
          保证后续 fusion encoder 可以拼接两个模态的特征。
    """

    def __init__(self, in_dim: int, out_dim: int, up_scale: int = 4, init_cfg=None):
        super().__init__()
        self.decoder = nn.Sequential(
            nn.Conv2d(
                in_channels=in_dim,
                out_channels=up_scale**2 * out_dim,
                kernel_size=1,
            ),
            nn.PixelShuffle(up_scale),
        )
        self.init_cfg = init_cfg
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.trunc_normal_(m.weight, std=0.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in')
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.decoder(x)


# ==============================================================================
# 2. FusionViT — 多模态融合 Vision Transformer
# ==============================================================================

class FusionViT(DinoVisionTransformer):
    """
    多模态特征融合 Vision Transformer。

    继承自 DINOv3 的 DinoVisionTransformer，在 forward_features 层面
    接收来自 HR ViT 和 OlmoEarth 的序列化特征，拼接后通过标准 ViT encoder
    进行跨模态自注意力融合。

    数据流:
      HR ViT output (patch tokens)  → [B, N_hr, D_hr]         (空间 token 序列)
      OlmoEarth output  → UPHead  → [B, N_oe, D_hr]           (对齐到相同维度)
      拼接 → [B, N_hr + N_oe, D_hr]
      + CLS token + storage tokens → [B, 1 + R + N_total, D_hr]
      → 24 层 SelfAttentionBlock → CLS token → 融合特征 [B, D_hr]

    IOD 接口:
      I: hr_features: Tensor [B, N, D]   — HR ViT 的 patch token 序列
         oe_features: Tensor [B, N', D]  — OlmoEarth 上采样后的 patch token 序列
      O: dict with 'x_norm_clstoken', 'x_norm_patchtokens', ...
         (与 DinoVisionTransformer.forward_features 输出格式一致)
    """

    def __init__(
        self,
        *,
        hr_seq_len: int = 256,      # HR 模态的序列长度 (16×16)
        oe_seq_len: int = 256,      # OlmoEarth 模态的序列长度
        img_size: int = 224,
        patch_size: int = 16,
        in_chans: int = 3,
        embed_dim: int = 1024,
        depth: int = 12,
        num_heads: int = 16,
        **kwargs,
    ):
        """
        Args:
            hr_seq_len: HR ViT 输出 patch token 数量 (默认 256 = 16×16)
            oe_seq_len: OlmoEarth 特征上采样后的 patch token 数量
            其他参数: 同 DinoVisionTransformer
        """
        # 调用父类初始化 (包含 patch_embed, rope_embed, blocks, norm 等)
        super().__init__(
            img_size=img_size,
            patch_size=patch_size,
            in_chans=in_chans,
            embed_dim=embed_dim,
            depth=depth,
            num_heads=num_heads,
            **kwargs,
        )

        self.hr_seq_len = hr_seq_len
        self.oe_seq_len = oe_seq_len
        self.total_seq_len = hr_seq_len + oe_seq_len

        logger.info(
            f"FusionViT initialized: hr_seq_len={hr_seq_len}, oe_seq_len={oe_seq_len}, "
            f"total_seq_len={self.total_seq_len}, embed_dim={embed_dim}, depth={depth}"
        )

    def forward_features(
        self,
        x: torch.Tensor | list[torch.Tensor],
        masks=None,
    ) -> dict:
        """
        重写 forward_features 以支持融合输入。

        x 可以是:
          - 单个 4D Tensor [B,C,H,W]: 正常 ViT 图像路径 (patch_embed → blocks)
          - 单个 3D Tensor [N, S, D]: 预序列化 token 路径 (跳过 patch_embed，直接进 blocks)
          - list of [hr_tokens, oe_tokens]: 两路拼接融合路径

        Args:
            x: 输入特征
            masks: 掩码 (未使用，保留接口兼容)

        Returns:
            与 DinoVisionTransformer.forward_features 相同格式的 dict
        """
        if isinstance(x, list):
            # ─── 路径 A: 两路列表拼接 ───
            assert len(x) == 2, f"FusionViT expects list of 2 tensors, got {len(x)}"
            hr_tokens, oe_tokens = x  # [B, N_hr, D], [B, N_oe, D]
            B = hr_tokens.shape[0]
            combined = torch.cat([hr_tokens, oe_tokens], dim=1)
            cls_token = self.cls_token.expand(B, -1, -1)
            if self.n_storage_tokens > 0:
                storage_tokens = self.storage_tokens.expand(B, -1, -1)
            else:
                storage_tokens = torch.empty(B, 0, cls_token.shape[-1], dtype=cls_token.dtype, device=cls_token.device)
            x_seq = torch.cat([cls_token, storage_tokens, combined], dim=1)
            seq_len = combined.shape[1]
        elif x.dim() == 3:
            # ─── 路径 B: 单 3D tensor [N, S, D] 直接作为 token 序列 ───
            B, S, D = x.shape
            cls_token = self.cls_token.expand(B, -1, -1)
            if self.n_storage_tokens > 0:
                storage_tokens = self.storage_tokens.expand(B, -1, -1)
            else:
                storage_tokens = torch.empty(B, 0, cls_token.shape[-1], dtype=cls_token.dtype, device=cls_token.device)
            x_seq = torch.cat([cls_token, storage_tokens, x], dim=1)
            seq_len = S
        else:
            # ─── 路径 C: 4D 图像 tensor [B,C,H,W] ───
            return super().forward_features(x, masks)

        # 公共路径: token 序列通过 Transformer blocks
        total_tokens = seq_len + self.n_storage_tokens + 1
        for blk in self.blocks:
            if self.rope_embed is not None:
                rope_sincos = self.rope_embed(H=1, W=total_tokens)
            else:
                rope_sincos = None
            x_seq = blk([x_seq], [rope_sincos])[0]

        # 提取 CLS token 和 patch tokens
        if self.untie_cls_and_patch_norms:
            x_norm_cls_reg = self.cls_norm(x_seq[:, : self.n_storage_tokens + 1])
            x_norm_patch = self.norm(x_seq[:, self.n_storage_tokens + 1 :])
        else:
            x_norm = self.norm(x_seq)
            x_norm_cls_reg = x_norm[:, : self.n_storage_tokens + 1]
            x_norm_patch = x_norm[:, self.n_storage_tokens + 1 :]

        return {
            "x_norm_clstoken": x_norm_cls_reg[:, 0],
            "x_storage_tokens": x_norm_cls_reg[:, 1:],
            "x_norm_patchtokens": x_norm_patch,
            "x_prenorm": x_seq,
            "masks": masks,
        }

    def forward(self, *args, is_training: bool = False, **kwargs) -> dict | torch.Tensor:
        ret = self.forward_features(*args, **kwargs)
        if is_training:
            return ret
        else:
            return self.head(ret["x_norm_clstoken"])


# ==============================================================================
# 3. 模型注册表 & 工厂函数
# ==============================================================================

# 复用的 ViT 变体注册 (与 vision_transformer.py 一致)
_vit_registry = {
    'vit_small': vit_small,
    'vit_base': vit_base,
    'vit_large': vit_large,
    'vit_so400m': vit_so400m,
    'vit_huge2': vit_huge2,
    'vit_giant2': vit_giant2,
    'vit_7b': vit_7b,
}


def build_fusion_model(cfg, only_teacher: bool = False):
    """
    构建 FusionViT 模型。

    cfg.student 应包含以下关键字段:
      - arch: 基础 ViT 架构名 (如 'vit_large')
      - embed_dim: 嵌入维度
      - depth: 层数
      - patch_size: (用于 rope 计算)
      - hr_seq_len / oe_seq_len: 各模态的序列长度

    如果 cfg 中未指定 hr_seq_len / oe_seq_len，默认均为 256 (16×16)。
    """
    arch_name = getattr(cfg.student, 'arch', 'vit_large')

    fusion_kwargs = dict(
        img_size=518,
        patch_size=getattr(cfg.student, 'patch_size', 14),
        pos_embed_rope_base=getattr(cfg.student, 'pos_embed_rope_base', 100.0),
        pos_embed_rope_min_period=getattr(cfg.student, 'pos_embed_rope_min_period', None),
        pos_embed_rope_max_period=getattr(cfg.student, 'pos_embed_rope_max_period', None),
        pos_embed_rope_normalize_coords=getattr(cfg.student, 'pos_embed_rope_normalize_coords', 'separate'),
        pos_embed_rope_shift_coords=getattr(cfg.student, 'pos_embed_rope_shift_coords', None),
        pos_embed_rope_jitter_coords=getattr(cfg.student, 'pos_embed_rope_jitter_coords', None),
        pos_embed_rope_rescale_coords=getattr(cfg.student, 'pos_embed_rope_rescale_coords', None),
        pos_embed_rope_dtype=getattr(cfg.student, 'pos_embed_rope_dtype', 'bf16'),
        embed_dim=getattr(cfg.student, 'embed_dim', 1024),
        depth=getattr(cfg.student, 'depth', 12),
        num_heads=getattr(cfg.student, 'num_heads', 16),
        qkv_bias=getattr(cfg.student, 'qkv_bias', True),
        layerscale_init=getattr(cfg.student, 'layerscale', None),
        norm_layer=getattr(cfg.student, 'norm_layer', 'layernorm'),
        ffn_layer=getattr(cfg.student, 'ffn_layer', 'mlp'),
        ffn_bias=getattr(cfg.student, 'ffn_bias', True),
        proj_bias=getattr(cfg.student, 'proj_bias', True),
        n_storage_tokens=getattr(cfg.student, 'n_storage_tokens', 0),
        mask_k_bias=getattr(cfg.student, 'mask_k_bias', False),
        untie_cls_and_patch_norms=getattr(cfg.student, 'untie_cls_and_patch_norms', False),
        untie_global_and_local_cls_norm=getattr(cfg.student, 'untie_global_and_local_cls_norm', False),
        # Fusion-specific
        hr_seq_len=getattr(cfg.student, 'hr_seq_len', 256),
        oe_seq_len=getattr(cfg.student, 'oe_seq_len', 256),
        device='meta',
    )

    teacher = FusionViT(**fusion_kwargs)
    if only_teacher:
        return teacher, teacher.embed_dim

    student = FusionViT(
        **fusion_kwargs,
        drop_path_rate=getattr(cfg.student, 'drop_path_rate', 0.0),
    )
    embed_dim = student.embed_dim
    return student, teacher, embed_dim


def build_model_from_cfg_QH(cfg, only_teacher: bool = False):
    """
    构建 FusionViT 的 student / teacher 模型对。

    用法 (在 model.py 中):
        fusion_student, fusion_teacher, fusion_embed_dim = build_model_from_cfg_QH(cfg)

    Args:
        cfg: OmegaConf 配置对象，包含 cfg.student (ViT 参数) 和 cfg.crops
        only_teacher: 若为 True 则只返回 teacher 模型

    Returns:
        - student, teacher, embed_dim  (only_teacher=False)
        - teacher, embed_dim           (only_teacher=True)
    """
    return build_fusion_model(cfg, only_teacher=only_teacher)
