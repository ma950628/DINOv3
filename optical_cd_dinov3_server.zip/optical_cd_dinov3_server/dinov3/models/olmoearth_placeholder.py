"""
Olmoearth 占位模块

状态：🔴 待实现
该模块在 model.py 的 SSLMetaArch_QH2 中被冻结使用 (requires_grad=False)。

当完整实现后，Olmoearth 将作为预训练的遥感基础模型，
接收一个统一的 H5 数据字典（包含 Sentinel-2 / Sentinel-1 / Landsat 数据），
内部处理多源时序遥感数据，输出各源的特征张量，
供后续跨模态空间序列融合使用。

占位版本对各源独立做 patch 投影 + 简单 CNN，确保 pipeline 能端到端运行。

I (Input):
  h5_data: dict with keys "s2", "s1", "ls" (或 file path str)
    h5_data["s2"]: Tensor [B, H, W, T1, C1]  (Sentinel-2)
    h5_data["s1"]: Tensor [B, H, W, T2, C2]  (Sentinel-1)
    h5_data["ls"]: Tensor [B, H, W, T3, C3]  (Landsat)
    B  = batch size
    H, W = 空间尺寸（中低分辨率）
    T_i = 该数据源的时间步数
    C_i = 通道数

O (Output):
  dict with:
    's2': {'features': [B, H_out, W_out, T1, embed_dim], 'cls_token': [B, T1, embed_dim]}
    's1': {'features': [B, H_out, W_out, T2, embed_dim], 'cls_token': [B, T2, embed_dim]}
    'ls': {'features': [B, H_out, W_out, T3, embed_dim], 'cls_token': [B, T3, embed_dim]}
"""

import torch
import torch.nn as nn


class Olmoearth(nn.Module):
    """
    Olmoearth 占位类 — 模拟多模态遥感预训练推理模型。

    接收统一的 H5 数据字典，内部处理 S2/S1/LS 三源数据，
    各自独立编码，保持空间维度输出。
    """

    def __init__(self, embed_dim: int = 768, patch_size: int = 4):
        """
        Args:
            embed_dim: 输出 embedding 维度，默认 768。
            patch_size: 空间下采样倍率，输出 H_out = H // patch_size,
                       W_out = W // patch_size。
        """
        super().__init__()
        self.embed_dim = embed_dim
        self.patch_size = patch_size

        # 占位用的 patch 投影层（按实际 C 动态适配）
        self.patch_proj = nn.Conv2d(
            1, embed_dim,
            kernel_size=patch_size, stride=patch_size, bias=False,
        )

        # LayerNorm 稳定输出范围，防止后续 FusionViT 出现 NaN
        self.patch_norm = nn.LayerNorm(embed_dim)
        nn.init.ones_(self.patch_norm.weight)
        nn.init.zeros_(self.patch_norm.bias)

        self._is_placeholder = True

        import logging
        logger = logging.getLogger("model")
        logger.warning(
            "Olmoearth 当前为占位版本（🔴 待实现）。接收 H5 数据字典 "
            "{\"s2\": ..., \"s1\": ..., \"ls\": ...}，"
            "输出各源特征 [B,H_out,W_out,T_i,embed_dim]。"
        )

    def forward(self, h5_data: dict) -> dict:
        """
        Args:
            h5_data: dict, 包含:
                "s2": Tensor [B, H, W, T1, C1]
                "s1": Tensor [B, H, W, T2, C2]
                "ls": Tensor [B, H, W, T3, C3]

        Returns:
            dict: 对各源的编码结果:
                {
                    "s2": {"features": [B, H_out, W_out, T1, D], "cls_token": [B, T1, D]},
                    "s1": {"features": [B, H_out, W_out, T2, D], "cls_token": [B, T2, D]},
                    "ls": {"features": [B, H_out, W_out, T3, D], "cls_token": [B, T3, D]},
                }
        """
        output = {}
        for src_name in ["s2", "s1", "ls"]:
            data = h5_data[src_name]  # [B, H, W, T_i, C_i]
            B, H, W, T, C = data.shape

            # ---------- 占位逻辑 ----------
            # 对每个时间步独立做 patch 投影
            # [B, H, W, T, C] → [B*T, C, H, W]
            x = data.permute(0, 3, 4, 1, 2).reshape(B * T, C, H, W).float()

            # 动态适配通道数
            if C != self.patch_proj.in_channels:
                device = data.device
                adaptive_proj = nn.Conv2d(
                    C, self.embed_dim,
                    kernel_size=self.patch_size, stride=self.patch_size, bias=False,
                ).to(device)
                nn.init.xavier_uniform_(adaptive_proj.weight)
                x = adaptive_proj(x)
            else:
                x = self.patch_proj(x)

            # x: [B*T, embed_dim, H_out, W_out]
            H_out, W_out = x.shape[2], x.shape[3]

            # LayerNorm 稳定输出范围 (防止后续 FusionViT NaN)
            # [B*T, embed_dim, H_out, W_out] → [B*T, N, D] → LN → [B*T, D, N] → [B*T, embed_dim, H_out, W_out]
            x_flat = x.reshape(B * T, self.embed_dim, -1).transpose(1, 2)  # [B*T, N, D]
            x_flat = self.patch_norm(x_flat)
            x = x_flat.transpose(1, 2).reshape(B * T, self.embed_dim, H_out, W_out)

            # [B*T, embed_dim, H_out, W_out] → [B, H_out, W_out, T, embed_dim]
            features = (
                x.view(B, T, self.embed_dim, H_out, W_out)
                .permute(0, 3, 4, 1, 2)
                .contiguous()
            )

            # 占位 CLS token
            cls_token = torch.zeros(
                B, T, self.embed_dim,
                device=features.device, dtype=features.dtype,
            )

            output[src_name] = {
                'features': features,        # [B, H_out, W_out, T, embed_dim]
                'cls_token': cls_token,      # [B, T, embed_dim]
            }

        return output
