# optical_cd_dinov3 — 服务器多卡版

纯光学变化检测，支持单卡 / 多卡（DDP）自适应。

---

## 快速开始

### 1. 修改训练参数

编辑 `train.py` 顶部的 `CONFIG` 字典：

```python
CONFIG = {
    'data_root':   '/data/datasets/SYSU-CD',    # ← 改成你的数据集路径
    'dataset':     'sysu',                       # levir / bright / sysu
    'num_classes': 2,
    'arch':        'dinov3_vitl',                # vit_base / vit_large / dinov3_vitl
    'batch_size':  2,                            # 每张卡的 batch
    'epochs':      100,
    ...
}
```

### 2. 启动训练（命令永远不变）

```bash
# 单卡
python train.py

# 4 卡
torchrun --nproc_per_node=4 train.py

# 8 卡
torchrun --nproc_per_node=8 train.py

# 只用 0-3 号卡
CUDA_VISIBLE_DEVICES=0,1,2,3 torchrun --nproc_per_node=4 train.py
```

多卡时**有效 batch = batch_size × GPU 数量**。4 卡 batch_size=2 → 有效 batch=8。

### 3. 断点续跑

```bash
python train.py --resume ./outputs/2026-06-15_10-30-00
```

---

## 三架构切换

```python
'arch': 'vit_base'       # DINOv2 ViT-B/14 (86M)
'arch': 'vit_large'      # DINOv2 ViT-L/14 (342M)  
'arch': 'dinov3_vitl'    # DINOv3 ViT-L/16 SAT (342M)
```

---

## 环境依赖

```
pip install torch torchvision tqdm albumentations opencv-python pillow numpy
```

---

## 自包含说明

本项目内嵌 `dinov3/` 源码 + 预训练权重，复制到任何服务器直接可跑，零外部依赖。
