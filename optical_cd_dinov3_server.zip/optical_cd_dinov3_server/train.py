"""
纯光学变化检测 — 单卡/多卡自适应训练脚本
==========================================

启动方式（永远不变）：
    单卡:  python train.py
    多卡:  torchrun --nproc_per_node=4 train.py

修改训练参数：编辑下方 CONFIG 字典即可。
如需临时覆盖某个参数：python train.py --data-root /new/path
"""

import os, sys, argparse, logging
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from torch.nn.parallel import DistributedDataParallel as DDP
from tqdm import tqdm

torch.backends.cudnn.benchmark = True

from models.dinov3_optical_cd import build_optical_cd_model
from tools.metrics import CDMetrics


# ====================================================================
#  ⚙️  训练配置 —— 改这里就行！
# ====================================================================

CONFIG = {
    # ── 数据集 ──
    'data_root':   '/data/datasets/SYSU-CD',    # 数据集根目录
    'dataset':     'sysu',                       # levir / bright / sysu
    'num_classes': 2,                            # 分类数（SYSU-CD=2, BRIGHT=4）

    # ── 模型 ──
    'arch':                'dinov3_vitl',        # vit_base / vit_large / dinov3_vitl
    'finetune_backbone':   True,                 # 全参微调
    'gradient_checkpointing': True,              # ViT-L 省显存（推荐开启）
    'img_size':            448,                  # 输入尺寸（需为 patch_size 的倍数）

    # ── 训练超参 ──
    'batch_size':   2,                           # 每张卡的 batch size（DDP 下自动叠加）
    'epochs':       100,
    'lr':           1e-4,
    'class_weight': [1.0, 3.0],                  # None=均衡, [1,3]=变化类×3
    'max_samples':  None,                        # 每轮随机抽 N 张（None=全量）

    # ── 性能 ──
    'num_workers':  4,                           # DataLoader 线程（0=主线程）
    'no_amp':       False,                       # True=禁用混合精度
}

# ====================================================================
#  命令行参数（可覆盖 CONFIG 中的值）
# ====================================================================


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-root', default=CONFIG['data_root'])
    parser.add_argument('--dataset', default=CONFIG['dataset'], choices=['levir', 'bright', 'sysu'])
    parser.add_argument('--num-classes', type=int, default=CONFIG['num_classes'])
    parser.add_argument('--batch-size', type=int, default=CONFIG['batch_size'])
    parser.add_argument('--epochs', type=int, default=CONFIG['epochs'])
    parser.add_argument('--img-size', type=int, default=CONFIG['img_size'])
    parser.add_argument('--arch', default=CONFIG['arch'],
                        choices=['vit_base', 'vit_large', 'dinov3_vitl'])
    parser.add_argument('--finetune-backbone', action='store_true', default=CONFIG['finetune_backbone'])
    parser.add_argument('--gradient-checkpointing', action='store_true', default=CONFIG['gradient_checkpointing'])
    parser.add_argument('--class-weight', type=float, nargs='+', default=CONFIG['class_weight'])
    parser.add_argument('--lr', type=float, default=CONFIG['lr'])
    parser.add_argument('--max-samples', type=int, default=CONFIG['max_samples'])
    parser.add_argument('--num-workers', type=int, default=CONFIG['num_workers'])
    parser.add_argument('--no-amp', action='store_true', default=CONFIG['no_amp'])
    parser.add_argument('--resume', default=None, help='Resume from output dir')
    return parser.parse_args()


# ====================================================================
#  日志
# ====================================================================

def setup_logging(log_dir):
    os.makedirs(log_dir, exist_ok=True)
    logger = logging.getLogger('optical_cd')
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if logger.handlers:
        return logger
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%H:%M:%S'))
    logger.addHandler(ch)
    fh = logging.FileHandler(os.path.join(log_dir, 'train.log'), mode='w', encoding='utf-8')
    fh.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
    logger.addHandler(fh)
    return logger


# ====================================================================
#  数据集
# ====================================================================

class LEVIROpticalDataset(torch.utils.data.Dataset):
    """LEVIR-CD / SYSU-CD 数据集（纯光学，双时相 RGB）。"""

    def __init__(self, root_dir, split='train', img_size=224, is_train=True, no_crop=False, max_samples=None):
        import cv2
        import numpy as np
        import albumentations as A
        from albumentations.pytorch import ToTensorV2

        self.root = os.path.join(root_dir, split)
        self.img_size = img_size
        self.is_train = is_train
        self._all_images = sorted(os.listdir(os.path.join(self.root, 'A')))
        self._max_samples = max_samples
        self._resample()

        if is_train:
            if no_crop:
                self.transform = A.Compose([
                    A.Resize(img_size, img_size),
                    A.HorizontalFlip(p=0.5),
                    A.VerticalFlip(p=0.5),
                    A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                    ToTensorV2(),
                ], additional_targets={'image_post': 'image'})
            else:
                self.transform = A.Compose([
                    A.RandomCrop(img_size, img_size),
                    A.HorizontalFlip(p=0.5),
                    A.VerticalFlip(p=0.5),
                    A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                    ToTensorV2(),
                ], additional_targets={'image_post': 'image'})
        else:
            self.transform = A.Compose([
                A.Resize(img_size, img_size),
                A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                ToTensorV2(),
            ], additional_targets={'image_post': 'image'})

        self._cv2 = cv2
        self._np = np

    def _resample(self):
        import random
        if self._max_samples and len(self._all_images) > self._max_samples:
            self.img_list = random.sample(self._all_images, self._max_samples)
        else:
            self.img_list = self._all_images[:]

    def resample(self):
        self._resample()

    def __getitem__(self, idx):
        name = self.img_list[idx]
        pre = self._cv2.imread(os.path.join(self.root, 'A', name))
        pre = self._cv2.cvtColor(pre, self._cv2.COLOR_BGR2RGB)
        post = self._cv2.imread(os.path.join(self.root, 'B', name))
        post = self._cv2.cvtColor(post, self._cv2.COLOR_BGR2RGB)
        label = self._cv2.imread(os.path.join(self.root, 'label', name), 0)
        label = (label == 255).astype(self._np.int64)

        aug = self.transform(image=pre, image_post=post, mask=label)
        return aug['image'], aug['image_post'], aug['mask'].long()

    def __len__(self):
        return len(self.img_list)


class BrightOpticalDataset(torch.utils.data.Dataset):
    """BRIGHT 纯光学版（仅用 pre-event 光学）。"""

    def __init__(self, root_dir, split='train', img_size=224, is_train=True):
        import numpy as np
        import albumentations as A
        from albumentations.pytorch import ToTensorV2

        with open(os.path.join(root_dir, 'splits', f'{split}.txt'), 'r') as f:
            self.pairs = [line.strip() for line in f if line.strip()]

        self.root = root_dir
        self.img_size = img_size
        self.is_train = is_train

        if is_train:
            self.transform = A.Compose([
                A.RandomCrop(img_size, img_size),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.5),
                A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                ToTensorV2(),
            ])
        else:
            self.transform = A.Compose([
                A.Resize(img_size, img_size),
                A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                ToTensorV2(),
            ])
        self._np = np

    def _load_tiff_rgb(self, path):
        import cv2
        from PIL import Image
        try:
            img = Image.open(path)
            arr = self._np.array(img)
            if len(arr.shape) == 2:
                arr = cv2.cvtColor(arr, cv2.COLOR_GRAY2RGB)
            elif arr.shape[2] == 1:
                arr = cv2.cvtColor(arr.squeeze(2), cv2.COLOR_GRAY2RGB)
            elif arr.shape[2] == 4:
                arr = arr[:, :, :3]
            return arr
        except Exception:
            arr = cv2.imread(path)
            return cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)

    def __getitem__(self, idx):
        pre_name, target_name = self.pairs[idx]
        pre_path = os.path.join(self.root, 'pre-event', pre_name)
        target_path = os.path.join(self.root, 'target', target_name)
        from PIL import Image
        pre = self._load_tiff_rgb(pre_path)
        label = self._np.array(Image.open(target_path))
        label[label == 255] = 4
        label = label.astype(self._np.int64)
        aug = self.transform(image=pre, mask=label)
        return aug['image'], aug['image'].clone(), aug['mask'].long()

    def __len__(self):
        return len(self.pairs)


def create_dataset(root_dir, split, dataset, img_size, is_train, max_samples=None):
    """创建数据集（返回原始 Dataset，不包 DataLoader）。"""
    if dataset in ('levir', 'sysu'):
        return LEVIROpticalDataset(root_dir, split, img_size, is_train,
                                   no_crop=(dataset == 'sysu'), max_samples=max_samples)
    elif dataset == 'bright':
        return BrightOpticalDataset(root_dir, split, img_size, is_train)
    else:
        raise ValueError(f"Unknown dataset: {dataset}")


# ====================================================================
#  训练 / 验证
# ====================================================================

def train_epoch(model, loader, criterion, optimizer, device, use_amp=True, scaler=None):
    model.train()
    total_loss = 0
    pbar = tqdm(loader, desc='Train', leave=False)
    for pre_img, post_img, label in pbar:
        pre_img = pre_img.to(device)
        post_img = post_img.to(device)
        label = label.to(device).long()

        optimizer.zero_grad()
        if use_amp and scaler is not None:
            with torch.amp.autocast('cuda'):
                out = model(pre_img, post_img)
                loss = criterion(out, label)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            out = model(pre_img, post_img)
            loss = criterion(out, label)
            loss.backward()
            optimizer.step()

        total_loss += loss.item()
        pbar.set_postfix(loss=f'{loss.item():.4f}')
    return total_loss / len(loader)


@torch.no_grad()
def validate(model, loader, device, num_classes, use_amp=True):
    model.eval()
    metrics = CDMetrics(num_classes=num_classes)
    pbar = tqdm(loader, desc='Val', leave=False)
    for pre_img, post_img, label in pbar:
        pre_img = pre_img.to(device)
        post_img = post_img.to(device)
        with torch.amp.autocast('cuda', enabled=use_amp):
            out = model(pre_img, post_img)
        pred = out.argmax(dim=1)
        metrics.update(pred, label.to(device).long())
    return metrics.compute()


# ====================================================================
#  主函数
# ====================================================================

def main():
    args = get_args()

    # ── DDP 初始化（自动检测） ──
    local_rank = int(os.environ.get('LOCAL_RANK', -1))
    distributed = local_rank != -1

    if distributed:
        torch.cuda.set_device(local_rank)
        torch.distributed.init_process_group(backend='nccl')
        rank = torch.distributed.get_rank()
        world_size = torch.distributed.get_world_size()
        device = torch.device(f'cuda:{local_rank}')
    else:
        rank = 0
        world_size = 1
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # ── 时间戳目录 ──
    from datetime import datetime
    if args.resume:
        out_dir = args.resume
        log_dir = args.resume.replace('outputs', 'logs', 1)
        if not os.path.exists(out_dir):
            raise FileNotFoundError(f"Resume dir not found: {out_dir}")
    else:
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        out_dir = os.path.join('./outputs', timestamp)
        log_dir = os.path.join('./logs', timestamp)

    os.makedirs(out_dir, exist_ok=True)
    logger = setup_logging(log_dir) if rank == 0 else None

    def log(msg):
        """只在 rank 0 打印日志。"""
        if logger is not None:
            logger.info(msg)

    # ── 架构解析 ──
    arch_defaults = {
        'vit_base':     ('vit_base', 14, 0),
        'vit_large':    ('vit_large', 14, 0),
        'dinov3_vitl':  ('vit_large', 16, 4),
    }
    if args.arch in arch_defaults:
        arch_name, patch_size, n_storage = arch_defaults[args.arch]
    else:
        arch_name = args.arch
        patch_size = 14
        n_storage = 0

    log(f"== {args.dataset} | {arch_name} | {args.epochs} ep | BS {args.batch_size}×{world_size} | img {args.img_size}")
    log(f"   DDP: {distributed} | Rank: {rank}/{world_size} | Device: {device}")

    # ── 数据集 ──
    train_ds = create_dataset(args.data_root, 'train', args.dataset, args.img_size, True, args.max_samples)

    if distributed:
        train_sampler = DistributedSampler(train_ds, num_replicas=world_size, rank=rank, shuffle=True)
        train_loader = DataLoader(train_ds, batch_size=args.batch_size, sampler=train_sampler,
                                  num_workers=args.num_workers, pin_memory=True, drop_last=True)
    else:
        train_sampler = None
        train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                                  num_workers=args.num_workers, pin_memory=True, drop_last=True)

    # 验证集只在 rank 0 加载（不用 DistributedSampler）
    if rank == 0:
        val_ds = create_dataset(args.data_root, 'val', args.dataset, args.img_size, False)
        val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                                num_workers=args.num_workers, pin_memory=True)
    else:
        val_loader = None

    # ── 模型 ──
    model = build_optical_cd_model(
        num_classes=args.num_classes, img_size=args.img_size,
        arch=arch_name, finetune_backbone=args.finetune_backbone,
        patch_size=patch_size, n_storage_tokens=n_storage)
    model = model.to(device)

    if args.gradient_checkpointing and hasattr(model, 'backbone'):
        try:
            model.backbone.gradient_checkpointing = True
            log("Gradient checkpointing: ON")
        except Exception:
            pass

    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    log(f"Params: {trainable:,}/{total:,} ({100*trainable/total:.1f}%)")

    if distributed:
        model = DDP(model, device_ids=[local_rank], find_unused_parameters=False)

    # ── 损失函数 / 优化器 / 调度器 ──
    if args.class_weight is not None:
        class_weight = torch.tensor(args.class_weight, dtype=torch.float32).to(device)
        log(f"Class weights: {args.class_weight}")
    else:
        class_weight = None
    criterion = nn.CrossEntropyLoss(weight=class_weight, ignore_index=255)
    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

    use_amp = not args.no_amp and device.type == 'cuda'
    scaler = torch.amp.GradScaler('cuda') if use_amp else None
    log(f"AMP: {'ON' if use_amp else 'OFF'}")

    # ── 断点续跑 ──
    best_f1 = 0
    start_epoch = 0
    ckpt_path = os.path.join(out_dir, 'checkpoint.pth')
    if args.resume and os.path.exists(ckpt_path):
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
        base_model = model.module if distributed else model
        base_model.load_state_dict(ckpt['model'])
        optimizer.load_state_dict(ckpt['optimizer'])
        scheduler.load_state_dict(ckpt['scheduler'])
        start_epoch = ckpt['epoch'] + 1
        best_f1 = ckpt.get('best_f1', 0)
        if scaler is not None and 'scaler' in ckpt:
            scaler.load_state_dict(ckpt['scaler'])
        log(f"Resumed from epoch {ckpt['epoch']}, best_f1={best_f1:.4f}")

    # ── 训练循环 ──
    for epoch in range(start_epoch, args.epochs):
        if distributed:
            train_sampler.set_epoch(epoch)

        if hasattr(train_loader.dataset, 'resample'):
            train_loader.dataset.resample()

        train_loss = train_epoch(model, train_loader, criterion, optimizer, device,
                                  use_amp=use_amp, scaler=scaler)

        if rank == 0:
            if use_amp:
                torch.cuda.empty_cache()

            # 验证（用 DDP 的底层模型）
            base_model = model.module if distributed else model
            result = validate(base_model, val_loader, device, args.num_classes, use_amp=use_amp)
            scheduler.step()

            log(f"Epoch {epoch:3d} | Train Loss {train_loss:.4f} | "
                f"Val F1 {result['f1']:.4f} | Val IoU {result['iou']:.4f} | "
                f"Val P {result['precision']:.4f} | Val R {result['recall']:.4f}")

            # 记录 metrics
            with open(os.path.join(log_dir, 'metrics.txt'), 'a') as f:
                f.write(f"{epoch} {train_loss:.6f} {result['f1']:.6f} "
                        f"{result['iou']:.6f} {result['precision']:.6f} {result['recall']:.6f}\n")

            # 保存最佳模型
            if result['f1'] > best_f1:
                best_f1 = result['f1']
                torch.save(base_model.state_dict(), os.path.join(out_dir, 'best_model.pth'))
                log(f"  -> Best F1: {best_f1:.4f} [saved]")

            # 保存断点续跑状态
            ckpt_state = {
                'model': base_model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'scheduler': scheduler.state_dict(),
                'epoch': epoch,
                'best_f1': best_f1,
            }
            if scaler is not None:
                ckpt_state['scaler'] = scaler.state_dict()
            torch.save(ckpt_state, ckpt_path)

            if (epoch + 1) % 10 == 0:
                torch.save(base_model.state_dict(),
                           os.path.join(out_dir, f'checkpoint_epoch_{epoch+1}.pth'))

    # ── 测试 & 出图（仅 rank 0） ──
    if rank == 0:
        log("=== Testing with best model ===")
        base_model = model.module if distributed else model
        base_model.load_state_dict(torch.load(os.path.join(out_dir, 'best_model.pth')))
        test_ds = create_dataset(args.data_root, 'test', args.dataset, args.img_size, False)
        test_loader = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False,
                                 num_workers=args.num_workers, pin_memory=True)
        test_result = validate(base_model, test_loader, device, args.num_classes, use_amp=use_amp)
        log(f"Test F1 {test_result['f1']:.4f} | IoU {test_result['iou']:.4f} | "
            f"P {test_result['precision']:.4f} | R {test_result['recall']:.4f}")

        # 自动出图
        log("Generating curves & predictions...")
        figures_dir = os.path.join(out_dir, 'figures')
        metrics_path = os.path.join(log_dir, 'metrics.txt')
        from tools.plot_curves import plot_from_metrics
        from tools.plot_results import visualize_predictions
        plot_from_metrics(metrics_path, figures_dir)
        visualize_predictions(base_model, args.data_root, figures_dir, device=device,
                              num_samples=8, img_size=args.img_size)
        log(f"Done. Best Val F1: {best_f1:.4f}")

    if distributed:
        torch.distributed.destroy_process_group()


if __name__ == '__main__':
    main()
